<?php

/**
 * @author WePresta
 * @copyright 2024-2025 WePresta
 * @license MIT
 */

declare(strict_types=1);
header('HTTP/1.0 403 Forbidden');

exit;
