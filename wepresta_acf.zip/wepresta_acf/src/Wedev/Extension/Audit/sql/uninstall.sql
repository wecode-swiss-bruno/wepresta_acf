-- Extension Audit - Suppression de la table
-- Exécuté lors de la désinstallation du module

DROP TABLE IF EXISTS `PREFIX_wedev_audit`;

