#!/usr/bin/env python3

import os
import re
import glob

# Liste des fichiers à modifier
files_to_process = [
    "src/Application/Config/EntityHooksConfig.php",
    "src/Application/FieldType/RelationField.php",
    "src/Application/FieldType/CheckboxField.php",
    "src/Application/FieldType/ImageField.php",
    "src/Application/FieldType/RadioField.php",
    "src/Application/FieldType/DatetimeField.php",
    "src/Application/FieldType/BooleanField.php",
    "src/Application/FieldType/SelectField.php",
    "src/Application/FieldType/TextField.php",
    "src/Application/FieldType/AbstractFieldType.php",
    "src/Application/FieldType/FileField.php",
    "src/Application/FieldType/DateField.php",
    "src/Application/FieldType/GalleryField.php",
    "src/Application/FieldType/StarRatingField.php",
    "src/Application/FieldType/UrlField.php",
    "src/Application/FieldType/RichTextField.php",
    "src/Application/FieldType/TextareaField.php",
    "src/Application/FieldType/FilesField.php",
    "src/Application/FieldType/ListField.php",
    "src/Application/FieldType/NumberField.php",
    "src/Application/FieldType/RepeaterField.php",
    "src/Application/FieldType/EmailField.php",
    "src/Application/FieldType/VideoField.php",
    "src/Application/FieldType/ColorField.php",
    "src/Application/FieldType/TimeField.php",
    "src/Application/Form/Type/AcfContainerType.php",
    "src/Application/Form/SyncType.php",
    "src/Application/Form/ConfigurationType.php",
    "src/Application/Helper/AcfHelper.php",
    "src/Application/Hook/EntityFieldHooksTrait.php",
    "src/Application/Installer/ModuleInstaller.php",
    "src/Application/Installer/ModuleUninstaller.php",
    "src/Application/Provider/EntityField/CountryEntityFieldProvider.php",
    "src/Application/Provider/EntityField/BrandEntityFieldProvider.php",
    "src/Application/Provider/EntityField/ZoneEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CurrencyEntityFieldProvider.php",
    "src/Application/Provider/EntityField/OrderEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CustomerAddressEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CustomerEntityFieldProvider.php",
    "src/Application/Provider/EntityField/SupplierEntityFieldProvider.php",
    "src/Application/Provider/EntityField/StateEntityFieldProvider.php",
    "src/Application/Provider/EntityField/LanguageEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CmsPageEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CustomerGroupEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CartEntityFieldProvider.php",
    "src/Application/Provider/EntityField/ProductEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CmsCategoryEntityFieldProvider.php",
    "src/Application/Provider/EntityField/CategoryEntityFieldProvider.php",
    "src/Application/Provider/LocationProviderInterface.php",
    "src/Application/Provider/LocationProviderRegistry.php",
    "src/Application/Provider/CoreLocationProvider.php",
    "src/Application/Service/FormModifierService.php",
    "src/Application/Service/EntityFieldService.php",
    "src/Application/Service/AutoSyncService.php",
    "src/Application/Service/SyncService.php",
    "src/Application/Service/FileUploadService.php",
    "src/Application/Service/SyncStatusResolver.php",
    "src/Application/Service/FieldTypeRegistry.php",
    "src/Application/Service/FieldTypeLoader.php",
    "src/Application/Service/ValueProvider.php",
    "src/Application/Service/AcfServiceContainer.php",
    "src/Application/Service/SlugGenerator.php",
    "src/Application/Service/EntityContextDetector.php",
    "src/Application/Service/ExportImportService.php",
    "src/Application/Service/ShortcodeParser.php",
    "src/Application/Service/AcfFrontService.php",
    "src/Application/Service/ValueHandler.php",
    "src/Application/Service/FieldRenderer.php",
    "src/Application/Smarty/function.acf_group.php",
    "src/Application/Smarty/function.acf_render.php",
    "src/Application/Smarty/function.acf_field.php",
    "src/Application/Smarty/AcfSmartyWrapper.php",
    "src/Application/Smarty/block.acf_foreach.php",
    "src/Application/Template/ImportResult.php",
    "src/Application/Template/FieldGroupExporter.php",
    "src/Application/Template/FieldGroupImporter.php",
    "src/Application/Twig/AcfTwigExtension.php",
    "src/Domain/Entity/AcfGroup.php",
    "src/Domain/Entity/AcfFieldValue.php",
    "src/Domain/Entity/AcfField.php",
    "src/Domain/Event/GroupDeletedEvent.php",
    "src/Domain/Event/FieldValueSavedEvent.php",
    "src/Domain/Event/GroupUpdatedEvent.php",
    "src/Domain/Event/FieldValueDeletedEvent.php",
    "src/Domain/Event/GroupCreatedEvent.php",
    "src/Domain/Repository/AcfFieldValueRepositoryInterface.php",
    "src/Domain/Repository/AcfGroupRepositoryInterface.php",
    "src/Domain/Repository/AcfFieldRepositoryInterface.php",
    "src/Infrastructure/Api/Controller/UtilityApiController.php",
    "src/Infrastructure/Api/Request/CreateFieldRequest.php",
    "src/Infrastructure/Api/Request/CreateGroupRequest.php",
    "src/Infrastructure/Api/Request/UpdateGroupRequest.php",
    "src/Infrastructure/Api/Request/UpdateFieldRequest.php",
    "src/Infrastructure/Api/Request/SaveValuesRequest.php",
    "src/Infrastructure/Api/Response/FieldResponse.php",
    "src/Infrastructure/Api/Response/GroupResponse.php",
    "src/Infrastructure/Api/Service/FieldMutationService.php",
    "src/Infrastructure/Api/Service/GroupMutationService.php",
    "src/Infrastructure/Api/Transformer/GroupTransformer.php",
    "src/Infrastructure/Api/Transformer/FieldTransformer.php",
    "src/Infrastructure/Api/Validator/SlugValidator.php",
    "src/Infrastructure/Api/RelationApiController.php",
    "src/Infrastructure/Api/FieldApiController.php",
    "src/Infrastructure/Api/FieldTypeApiController.php",
    "src/Infrastructure/Api/ValueApiController.php",
    "src/Infrastructure/Api/AbstractApiController.php",
    "src/Infrastructure/Api/SyncApiController.php",
    "src/Infrastructure/Api/GroupApiController.php",
    "src/Infrastructure/Repository/AcfFieldRepository.php",
    "src/Infrastructure/Repository/AcfFieldValueRepository.php",
    "src/Infrastructure/Repository/AcfGroupRepository.php",
    "src/Presentation/Controller/Admin/BuilderController.php",
    "src/Presentation/Controller/Admin/ConfigurationController.php",
    "src/Presentation/Controller/Admin/SyncController.php",
    "src/Wedev/Core/Adapter/ShopAdapter.php",
    "src/Wedev/Core/Adapter/ConfigurationAdapter.php",
    "src/Wedev/Core/Adapter/ContextAdapter.php",
    "src/Wedev/Core/Contract/RepositoryInterface.php",
    "src/Wedev/Core/Contract/ServiceInterface.php",
    "src/Wedev/Core/Contract/PluginInterface.php",
    "src/Wedev/Core/Contract/SubPluginInterface.php",
    "src/Wedev/Core/Contract/ExtensionInterface.php",
    "src/Wedev/Core/Contract/ConfigurableInterface.php",
    "src/Wedev/Core/Contract/InstallableInterface.php",
    "src/Wedev/Core/Contract/AssetProviderInterface.php",
    "src/Wedev/Core/Exception/DependencyException.php",
    "src/Wedev/Core/Exception/EntityNotFoundException.php",
    "src/Wedev/Core/Exception/ConfigurationException.php",
    "src/Wedev/Core/Exception/ValidationException.php",
    "src/Wedev/Core/Exception/ModuleException.php",
    "src/Wedev/Core/Extension/ExtensionLoader.php",
    "src/Wedev/Core/Plugin/PluginRegistry.php",
    "src/Wedev/Core/Plugin/PluginInfo.php",
    "src/Wedev/Core/Plugin/PluginDiscovery.php",
    "src/Wedev/Core/Repository/AbstractRepository.php",
    "src/Wedev/Core/Security/InputValidator.php",
    "src/Wedev/Core/Service/CacheService.php",
    "src/Wedev/Core/Trait/LoggerTrait.php",
    "src/Wedev/Core/Trait/ModuleAwareTrait.php",
    "src/Wedev/Core/Trait/TranslatorTrait.php",
    "src/Wedev/Core/Trait/MultiShopTrait.php",
    "src/Wedev/Core/Util/FileHelper.php",
    "src/Wedev/Core/Util/UrlHelper.php",
    "src/Wedev/Extension/EntityFields/EntityFieldContext.php",
    "src/Wedev/Extension/EntityFields/EntityFieldProviderInterface.php",
    "src/Wedev/Extension/EntityFields/EntityFieldRegistry.php",
    "src/Wedev/Extension/EntityFields/EntityFieldExtension.php",
    "src/Wedev/Extension/Events/Generic/EntityDeletedEvent.php",
    "src/Wedev/Extension/Events/Generic/EntityCreatedEvent.php",
    "src/Wedev/Extension/Events/Generic/EntityUpdatedEvent.php",
    "src/Wedev/Extension/Events/AbstractDomainEvent.php",
    "src/Wedev/Extension/Events/EventSubscriberInterface.php",
    "src/Wedev/Extension/Events/DomainEventDispatcher.php",
    "src/Wedev/Extension/UI/Smarty/function.wedev_button.php",
    "src/Wedev/Extension/UI/Smarty/function.wedev_icon.php",
    "src/Wedev/Extension/UI/Smarty/function.wedev_alert.php",
    "src/Wedev/Extension/UI/Smarty/function.wedev_badge.php",
    "src/Wedev/Extension/UI/Twig/UiExtension.php",
    "autoload.php"
]

# Code à ajouter
ps_check_code = """

if (!defined('_PS_VERSION_')) {
    exit;
}
"""

def process_file(filepath):
    """Traite un fichier PHP pour ajouter la vérification PrestaShop."""
    if not os.path.exists(filepath):
        print(f"✗ File not found: {filepath}")
        return

    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # Vérifier si la vérification PS existe déjà
    if 'if (!defined(\'_PS_VERSION_\'))' in content:
        print(f"- Already has PS check: {filepath}")
        return

    # Trouver la ligne namespace et ajouter le code après
    lines = content.split('\n')
    for i, line in enumerate(lines):
        if line.strip().startswith('namespace '):
            # Insérer le code PS check après la ligne namespace
            lines.insert(i + 1, ps_check_code.rstrip())
            break

    # Écrire le fichier modifié
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    print(f"✓ Added PS version check to {filepath}")

def main():
    """Fonction principale."""
    print("Adding PrestaShop version checks to PHP files...")

    for filepath in files_to_process:
        process_file(filepath)

    print("Done!")

if __name__ == "__main__":
    main()