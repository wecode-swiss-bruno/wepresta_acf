/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

// Accessibility fixes loader
document.addEventListener('DOMContentLoaded', function() {
    const fixesElement = document.getElementById('wepresta-eaa-fixes');
    if (!fixesElement) return;

    const config = fixesElement.dataset.fixesConfig;
    if (!config) return;

    try {
        const fixesConfig = JSON.parse(config);

        // Apply accessibility fixes based on configuration
        if (fixesConfig.skipLinks) {
            applySkipLinks(fixesConfig.skipLinks);
        }

        if (fixesConfig.autoFixes) {
            applyAutoFixes(fixesConfig.autoFixes);
        }

    } catch (error) {
        console.warn('Wepresta EAA: Error parsing accessibility fixes configuration', error);
    }
});

function applySkipLinks(config) {
    // Skip links functionality
    if (config.enabled) {
        // Add keyboard navigation enhancements
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                document.body.classList.add('wepresta-eaa-keyboard-navigation');
            }
        });

        document.addEventListener('mousedown', function() {
            document.body.classList.remove('wepresta-eaa-keyboard-navigation');
        });
    }
}

function applyAutoFixes(config) {
    // Apply various accessibility auto-fixes
    if (config.missingAlt) {
        fixMissingAltTags();
    }

    if (config.contrast) {
        enhanceContrast();
    }

    if (config.focus) {
        improveFocusIndicators();
    }
}

function fixMissingAltTags() {
    const images = document.querySelectorAll('img:not([alt])');
    images.forEach(img => {
        // Add a generic alt text for images without alt
        if (!img.hasAttribute('alt')) {
            img.setAttribute('alt', 'Image');
            img.setAttribute('data-wepresta-eaa-auto-alt', 'true');
        }
    });
}

function enhanceContrast() {
    // Add high contrast class if needed
    const html = document.documentElement;
    if (window.matchMedia && window.matchMedia('(prefers-contrast: high)').matches) {
        html.classList.add('wepresta-eaa-high-contrast');
    }
}

function improveFocusIndicators() {
    // Ensure focus indicators are visible
    const style = document.createElement('style');
    style.textContent = `
        .wepresta-eaa-keyboard-navigation *:focus {
            outline: 2px solid #007cba !important;
            outline-offset: 2px !important;
        }
    `;
    document.head.appendChild(style);
}
