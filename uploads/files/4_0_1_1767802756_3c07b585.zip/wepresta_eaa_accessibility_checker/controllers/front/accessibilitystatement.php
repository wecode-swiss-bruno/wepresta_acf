<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

class wepresta_eaa_accessibility_checkeraccessibilitystatementModuleFrontController extends ModuleFrontController
{
    public function init()
    {
        parent::init();

        // Allow access without being logged in
        $this->auth = false;
        $this->ssl = true;
    }

    public function initContent()
    {
        parent::initContent();

        // Get statement for current shop and language
        $id_shop = $this->context->shop->id;
        $id_lang = $this->context->language->id;

        // Simple database query to get the statement
        // Note: getRow() automatically adds LIMIT 1, so we don't add it here
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'wepresta_eaa_statements
                WHERE id_shop = ' . (int)$id_shop . ' AND id_lang = ' . (int)$id_lang . '
                ORDER BY generated_at DESC';
        $statement = Db::getInstance()->getRow($sql);

        if (!$statement || !$statement['published']) {
            // Statement not found or not published
            $this->errors[] = $this->trans('Accessibility statement not available.', [], 'ModulesWeprestaeaaaccessibilitycheckerFront');
            $this->setTemplate('errors/404.tpl');
            return;
        }

        // Set page metadata
        $this->context->smarty->assign([
            'page_name' => 'accessibility-statement',
            'page_title' => $this->trans('Accessibility Statement', [], 'ModulesWeprestaeaaaccessibilitycheckerFront'),
            'meta_title' => $this->trans('Accessibility Statement', [], 'ModulesWeprestaeaaaccessibilitycheckerFront'),
            'meta_description' => $this->trans('European Accessibility Act compliance statement', [], 'ModulesWeprestaeaaaccessibilitycheckerFront'),
        ]);

        // Assign template variables
        // Note: Don't override 'language' or 'shop' as PrestaShop already sets these
        $this->context->smarty->assign([
            'statement' => $statement,
        ]);

        // Set the template
        $this->setTemplate('module:wepresta_eaa_accessibility_checker/views/templates/front/accessibility_statement.tpl');
    }
}
