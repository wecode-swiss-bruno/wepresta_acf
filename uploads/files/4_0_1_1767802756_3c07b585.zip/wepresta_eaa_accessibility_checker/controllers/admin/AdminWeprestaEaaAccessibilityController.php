<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
/**
 * Admin controller for EAA Accessibility module dashboard.
 *
 * This is a LEGACY controller that PrestaShop uses when accessing via Tab.
 * It delegates rendering to the Symfony dashboard controller when available.
 * Also handles AJAX requests for operations like reset.
 *
 * @author    WePresta <contact@wepresta.com>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShop\PrestaShop\Adapter\SymfonyContainer;

class AdminWeprestaEaaAccessibilityController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        $this->meta_title = $this->trans('EAA Accessibility Dashboard', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin');
    }

    /**
     * Handle AJAX requests
     */
    public function postProcess()
    {
        if (Tools::getValue('ajax') && Tools::getValue('action')) {
            $action = Tools::getValue('action');
            
            switch ($action) {
                case 'resetAllData':
                    $this->ajaxProcessResetAllData();
                    break;
            }
        }
        
        return parent::postProcess();
    }

    /**
     * AJAX: Reset all accessibility data
     */
    public function ajaxProcessResetAllData()
    {
        header('Content-Type: application/json');
        
        try {
            $container = SymfonyContainer::getInstance();
            if (!$container) {
                throw new \Exception('Symfony container not available');
            }

            $dashboardService = $container->get('Wepresta\EaaAccessibilityChecker\Service\DashboardService');
            $shopId = (int) $this->context->shop->id;
            
            $dashboardService->resetAllData($shopId);

            die(json_encode([
                'success' => true,
                'message' => $this->trans('All accessibility data has been reset successfully.', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
            ]));
        } catch (\Throwable $e) {
            die(json_encode([
                'success' => false,
                'error' => $e->getMessage(),
            ]));
        }
    }

    public function initContent()
    {
        // Try to use Symfony controller if available
        if ($this->renderSymfonyController()) {
            return;
        }

        // Fallback: display a simple message
        parent::initContent();
        $this->content = $this->renderFallbackContent();
        $this->context->smarty->assign('content', $this->content);
    }

    /**
     * Try to render using Symfony controller
     */
    private function renderSymfonyController(): bool
    {
        try {
            $container = SymfonyContainer::getInstance();
            if (!$container instanceof \Symfony\Component\DependencyInjection\ContainerInterface) {
                return false;
            }

            if (!$container->has('router')) {
                return false;
            }

            $router = $container->get('router');
            
            // Check if route exists before trying to redirect
            $routes = $router->getRouteCollection();
            if (!$routes->get('wepresta_eaa_dashboard')) {
                return false;
            }

            $url = $router->generate('wepresta_eaa_dashboard');
            Tools::redirectAdmin($url);
            exit;
        } catch (\Throwable $e) {
            return false;
        }
    }

    /**
     * Fallback content when Symfony is not available
     */
    private function renderFallbackContent(): string
    {
        return '
        <div class="panel">
            <div class="panel-heading">
                <i class="icon-cogs"></i> ' . $this->trans('EAA Accessibility Checker', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin') . '
            </div>
            <div class="panel-body">
                <div class="alert alert-info">
                    <p><strong>' . $this->trans('Cache refresh required', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin') . '</strong></p>
                    <p>' . $this->trans('The module dashboard page requires a cache refresh.', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin') . '</p>
                    <p>' . $this->trans('Please go to Advanced Parameters > Performance and click "Clear cache".', [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin') . '</p>
                    <p>
                        <a href="' . $this->context->link->getAdminLink('AdminPerformance') . '" class="btn btn-primary">
                            <i class="icon-trash"></i> ' . $this->trans('Clear Cache', [], 'Admin.Actions') . '
                        </a>
                        <a href="javascript:location.reload();" class="btn btn-default">
                            <i class="icon-refresh"></i> ' . $this->trans('Refresh Page', [], 'Admin.Actions') . '
                        </a>
                    </p>
                </div>
            </div>
        </div>';
    }
}

