<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * EAA Accessibility Checker - Auto-Scan CRON Job
 *
 * This script should be called regularly (e.g., daily) by a CRON job.
 * Example CRON configuration:
 * 0 3 * * * /usr/bin/php /path/to/prestashop/modules/wepresta_eaa_accessibility_checker/cron.php
 *
 * This will run the auto-scan every day at 3:00 AM.
 */

// Define constants for PrestaShop
if (!defined('_PS_VERSION_')) {
    define('_PS_VERSION_', '1.7.0.0');
}

// Bootstrap PrestaShop
require_once dirname(__FILE__, 3) . '/config/config.inc.php';

use Wepresta\EaaAccessibilityChecker\Service\ConfigService;
use Wepresta\EaaAccessibilityChecker\Service\ScanService;
use Wepresta\EaaAccessibilityChecker\Service\DashboardService;

class EaaAutoScanCron
{
    private ConfigService $configService;
    private ScanService $scanService;
    private DashboardService $dashboardService;

    public function __construct()
    {
        /** @var ConfigService $configService */
        $this->configService = \PrestaShop\PrestaShop\Adapter\ServiceLocator::get(ConfigService::class);

        /** @var ScanService $scanService */
        $this->scanService = \PrestaShop\PrestaShop\Adapter\ServiceLocator::get(ScanService::class);

        /** @var DashboardService $dashboardService */
        $this->dashboardService = \PrestaShop\PrestaShop\Adapter\ServiceLocator::get(DashboardService::class);
    }

    public function executeQuery(): void
    {
        try {
            // Check if auto-scan is enabled
            $config = $this->configService->getAutoScanConfiguration();

            if (!$config['enabled']) {
                $this->log('Auto-scan is disabled, skipping execution');
                return;
            }

            // Check if it's the right time to run
            if (!$this->shouldRunScan($config)) {
                $this->log('Not the scheduled time for auto-scan, skipping');
                return;
            }

            $this->log('Starting auto-scan execution');

            // Get all scannable pages
            $pages = $this->getScannablePages();

            if (empty($pages)) {
                $this->log('No pages to scan');
                return;
            }

            // Start scan session (creates a new snapshot)
            $snapshotId = $this->scanService->startNewScanSession('Auto-scan ' . date('Y-m-d H:i:s'));

            $completed = 0;
            $failed = 0;

            // Scan each page
            foreach ($pages as $page) {
                try {
                    $this->log("Scanning: {$page['url']}");
                    $scanResult = $this->scanService->scanUrl($page['url'], $page['type']);

                    if (isset($scanResult['id_scan'])) {
                        $completed++;
                    } else {
                        $failed++;
                        $this->log("Failed to scan: {$page['url']} - Unknown error");
                    }
                } catch (\Exception $e) {
                    $failed++;
                    $this->log("Error scanning {$page['url']}: " . $e->getMessage());
                }
            }

            // Finish scan session
            $this->scanService->finishScanSession();

            $this->log("Auto-scan completed: {$completed} successful, {$failed} failed");

            // Send email notification if enabled
            if ($config['notificationsEnabled'] && !empty($config['email'])) {
                $this->sendNotificationEmail($config, $completed, $failed);
            }

        } catch (\Exception $e) {
            $this->log('Auto-scan execution failed: ' . $e->getMessage());
            error_log('EAA Auto-Scan CRON Error: ' . $e->getMessage());
        }
    }

    private function shouldRunScan(array $config): bool
    {
        $now = new \DateTime();
        $currentHour = (int) $now->format('H');
        $currentDayOfWeek = (int) $now->format('w'); // 0 = Sunday, 1 = Monday, etc.
        $currentDayOfMonth = (int) $now->format('j');

        // Check hour
        if ($currentHour !== $config['hour']) {
            return false;
        }

        // Check frequency
        switch ($config['frequency']) {
            case 'daily':
                return true;

            case 'weekly':
                return $currentDayOfWeek === $config['dayOfWeek'];

            case 'monthly':
                return $currentDayOfMonth === $config['dayOfMonth'];

            default:
                return false;
        }
    }

    private function getScannablePages(): array
    {
        $context = \Context::getContext();
        $link = $context->link;

        $pages = [];

        // Add some key pages to scan
        // Home page
        $pages[] = [
            'url' => $link->getPageLink('index'),
            'type' => 'home',
        ];

        // Cart page
        $pages[] = [
            'url' => $link->getPageLink('cart'),
            'type' => 'checkout',
        ];

        // Contact page
        $pages[] = [
            'url' => $link->getPageLink('contact'),
            'type' => 'cms',
        ];

        // Get a few products
        $products = \Product::getProducts($context->language->id, 0, 3, 'id_product', 'ASC', false, true);
        foreach ($products as $product) {
            $pages[] = [
                'url' => $link->getProductLink((int) $product['id_product']),
                'type' => 'product',
            ];
        }

        // Get a few categories
        $categories = \Category::getCategories($context->language->id, true, false);
        $catCount = 0;
        foreach ($categories as $category) {
            if ($catCount >= 2) break;
            if ((int) $category['id_category'] <= 2) continue; // Skip root and home
            $pages[] = [
                'url' => $link->getCategoryLink((int) $category['id_category']),
                'type' => 'category',
            ];
            $catCount++;
        }

        return $pages;
    }

    private function sendNotificationEmail(array $config, int $completed, int $failed): void
    {
        try {
            $context = \Context::getContext();
            $shopName = \Configuration::get('PS_SHOP_NAME');
            $shopId = (int) $context->shop->id;

            // Get current compliance score
            $complianceScore = $this->dashboardService->getCompliancePercentage($shopId);

            // Get issues count from the latest scan
            $latestScan = $this->scanService->getLatestScans(1);
            $issuesDetected = $latestScan[0]['issues_count'] ?? 0;

            $subject = sprintf('[%s] Accessibility Scan Report - %s', $shopName, date('M j, Y'));

            $body = sprintf(
                "Your scheduled accessibility scan has completed.\n\n" .
                "Results:\n" .
                "- Compliance score: %.1f%%\n" .
                "- New issues detected: %d\n" .
                "- Pages scanned successfully: %d\n" .
                "- Pages failed to scan: %d\n\n" .
                "View full report: %s\n\n" .
                "---\n" .
                "This is an automated email from EAA Accessibility Checker.\n" .
                "To change notification settings, visit your PrestaShop admin.",
                $complianceScore,
                $issuesDetected,
                $completed,
                $failed,
                $context->link->getAdminLink('AdminWeprestaEaaAccessibility')
            );

            // Use PrestaShop's Mail class for better email handling
            $mailSent = \Mail::Send(
                (int) $context->language->id,
                'autoscan_report', // Template name
                $subject,
                [
                    '{shop_name}' => $shopName,
                    '{compliance_score}' => sprintf('%.1f%%', $complianceScore),
                    '{issues_detected}' => $issuesDetected,
                    '{pages_completed}' => $completed,
                    '{pages_failed}' => $failed,
                    '{report_url}' => $context->link->getAdminLink('AdminWeprestaEaaAccessibility'),
                    '{date}' => date('M j, Y'),
                ],
                $config['email'],
                null, // Customer name
                \Configuration::get('PS_SHOP_EMAIL'),
                \Configuration::get('PS_SHOP_NAME'),
                null, // Attachment
                null, // SMTP options
                dirname(__FILE__) . '/mails/' // Custom mail template directory
            );

            if ($mailSent) {
                $this->log('Notification email sent successfully to ' . $config['email']);
            } else {
                $this->log('Failed to send notification email to ' . $config['email']);
            }

        } catch (\Exception $e) {
            $this->log('Error sending notification email: ' . $e->getMessage());
        }
    }

    private function log(string $message): void
    {
        $logFile = dirname(__FILE__) . '/logs/cron.log';
        $logDir = dirname($logFile);

        if (!is_dir($logDir)) {
            mkdir($logDir, 0755, true);
        }

        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[{$timestamp}] {$message}\n";

        file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);
    }
}

// executeQuery the cron job
try {
    $cron = new EaaAutoScanCron();
    $cron->executeQuery();
    echo "Auto-scan cron executed successfully\n";
} catch (\Exception $e) {
    error_log('EAA Auto-Scan CRON Fatal Error: ' . $e->getMessage());
    echo "Auto-scan cron failed: " . $e->getMessage() . "\n";
    exit(1);
}
