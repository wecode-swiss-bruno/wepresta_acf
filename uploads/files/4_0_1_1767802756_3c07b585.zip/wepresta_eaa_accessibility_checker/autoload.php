<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
/**
 * Module autoloader
 * 
 * This file registers the module's PSR-4 autoloader.
 * PrestaShop will use this to find the module's classes.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

// Use Composer autoloader if available
$composerAutoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($composerAutoload)) {
    require_once $composerAutoload;
    return;
}

// Fallback: Manual PSR-4 autoloader
spl_autoload_register(function ($class) {
    $prefix = 'Wepresta\\EaaAccessibilityChecker\\';
    $baseDir = __DIR__ . '/src/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relativeClass = substr($class, $len);
    $file = $baseDir . str_replace('\\', '/', $relativeClass) . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
});

