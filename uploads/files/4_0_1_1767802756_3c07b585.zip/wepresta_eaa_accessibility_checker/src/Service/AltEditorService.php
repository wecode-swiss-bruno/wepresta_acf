<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use Db;
use DbQuery;
use Image;
use Language;
use pSQL;

class AltEditorService
{
    /**
     * Get images with alt text status
     */
    public function getImages(
        int $langId,
        string $type = 'products',
        string $status = 'all',
        string $search = '',
        int $page = 1,
        int $perPage = 20
    ): array {
        $offset = ($page - 1) * $perPage;

        // Get product images only
        $productImages = $this->getProductImages($langId, $status, $search, 0, 0); // Get all first for accurate pagination

        // Apply search and status filters
        $filteredImages = $this->filterProductImages($productImages, $status, $search);

        // Sort results
        usort($filteredImages, function($a, $b) {
            return strcmp($a['entity_name'], $b['entity_name']);
        });

        // Apply pagination
        $totalItems = count($filteredImages);
        $images = array_slice($filteredImages, $offset, $perPage);

        return [
            'images' => $images,
            'pagination' => [
                'current_page' => $page,
                'per_page' => $perPage,
                'total_items' => $totalItems,
                'total_pages' => ceil($totalItems / $perPage),
            ],
        ];
    }

    /**
     * Get all product images
     */
    private function getProductImages(int $langId): array
    {
        $sql = new DbQuery();
        $sql->select('i.id_image, i.id_product, i.position, i.cover');
        $sql->select('pl.name as product_name');
        $sql->select('pl.link_rewrite as product_link_rewrite');
        $sql->select('COALESCE(il.legend, \'\') as alt_text');
        $sql->select('CASE WHEN il.legend IS NULL OR il.legend = \'\' THEN 0 ELSE 1 END as has_alt');
        $sql->from('image', 'i');
        $sql->innerJoin('product_lang', 'pl', 'pl.id_product = i.id_product AND pl.id_lang = ' . (int) $langId);
        $sql->leftJoin('image_lang', 'il', 'il.id_image = i.id_image AND il.id_lang = ' . (int) $langId);
        $sql->orderBy('i.id_product, i.position');

        $results = Db::getInstance()->executeS($sql);

        return array_map(function ($row) use ($langId) {
            return [
                'id' => (int) $row['id_image'],
                'type' => 'product',
                'entity_id' => (int) $row['id_product'],
                'entity_name' => $row['product_name'],
                'image_url' => $this->getProductImageUrl((string) $row['product_link_rewrite'], (int) $row['id_image'], 'small_default'),
                'image_url_large' => $this->getProductImageUrl((string) $row['product_link_rewrite'], (int) $row['id_image'], 'large_default'),
                'position' => (int) $row['position'],
                'is_cover' => (bool) $row['cover'],
                'alt_text' => $row['alt_text'],
                'has_alt' => (bool) $row['has_alt'],
            ];
        }, $results ?: []);
    }

    /**
     * Filter product images by status and search
     */
    private function filterProductImages(array $images, string $status, string $search): array
    {
        return array_filter($images, function ($image) use ($status, $search) {
            // Filter by status
            if ($status === 'missing' && $image['has_alt']) {
                return false;
            }
            if ($status === 'completed' && !$image['has_alt']) {
                return false;
            }

            // Filter by search
            if ($search && stripos($image['entity_name'], $search) === false) {
                return false;
            }

            return true;
        });
    }


    /**
     * Save alt text for a single image
     */
    public function saveAltText(string $type, int $id, int $langId, string $altText): bool
    {
        if ($type === 'product') {
            return $this->saveProductImageAlt($id, $langId, $altText);
        }

        return false;
    }

    /**
     * Save alt text for product image
     */
    private function saveProductImageAlt(int $imageId, int $langId, string $altText): bool
    {
        // Check if entry exists
        $exists = Db::getInstance()->getValue(
            'SELECT 1 FROM ' . _DB_PREFIX_ . 'image_lang
             WHERE id_image = ' . (int) $imageId . ' AND id_lang = ' . (int) $langId
        );

        if ($exists) {
            return Db::getInstance()->update(
                'image_lang',
                ['legend' => pSQL($altText)],
                'id_image = ' . (int) $imageId . ' AND id_lang = ' . (int) $langId
            );
        }

        return Db::getInstance()->insert('image_lang', [
            'id_image' => (int) $imageId,
            'id_lang' => (int) $langId,
            'legend' => pSQL($altText),
        ]);
    }

    /**
     * Bulk save alt texts
     */
    public function bulkSaveAltText(array $items, int $langId, string $action, string $altText = ''): int
    {
        $updatedCount = 0;

        foreach ($items as $item) {
            $type = $item['type'];
            $id = (int) $item['id'];

            if ($type === 'product') {
                if ($action === 'use_name') {
                    // Get product name and use it as alt
                    $name = $this->getEntityName($type, $id, $langId);
                    $textToSave = $name;
                } else {
                    $textToSave = $altText;
                }

                if ($this->saveAltText($type, $id, $langId, $textToSave)) {
                    $updatedCount++;
                }
            }
        }

        return $updatedCount;
    }

    /**
     * Get stats for alt texts (products only)
     */
    public function getStats(int $langId): array
    {
        $productStats = $this->getProductImageStats($langId);

        return [
            'missing' => $productStats['missing'],
            'completed' => $productStats['completed'],
            'total' => $productStats['total'],
        ];
    }

    /**
     * Get product image stats
     */
    private function getProductImageStats(int $langId): array
    {
        // Total product images
        $total = (int) Db::getInstance()->getValue('SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'image');

        // Missing alt texts
        $missing = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM ' . _DB_PREFIX_ . 'image i
             LEFT JOIN ' . _DB_PREFIX_ . 'image_lang il ON il.id_image = i.id_image AND il.id_lang = ' . (int) $langId . '
             WHERE il.legend IS NULL OR il.legend = \'\''
        );

        return [
            'missing' => $missing,
            'completed' => $total - $missing,
            'total' => $total,
        ];
    }


    /**
     * Get entity name for use as alt text
     */
    private function getEntityName(string $type, int $id, int $langId): string
    {
        if ($type === 'product') {
            return (string) Db::getInstance()->getValue(
                'SELECT name FROM ' . _DB_PREFIX_ . 'product_lang
                 WHERE id_product = ' . (int) $id . ' AND id_lang = ' . (int) $langId
            );
        }

        return '';
    }

    /**
     * Get product image URL
     */
    private function getProductImageUrl(string $linkRewrite, int $imageId, string $imageType): string
    {
        $context = Context::getContext();
        return (string) $context->link->getImageLink($linkRewrite, (string) $imageId, $imageType);
    }

}
