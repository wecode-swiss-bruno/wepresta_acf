<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Configuration;
use Context;
use DateTime;
use Db;
use Tools;
use Wepresta\EaaAccessibilityChecker\Service\DashboardService;

class AccessibilityStatementService
{
    private const CONFIG_PREFIX = 'WEPRESTA_EAA_STATEMENT_';

    public function __construct(
        private readonly DashboardService $dashboardService
    ) {}

    public function generateStatement(int $shopId, int $langId = null): array
    {
        $context = Context::getContext();
        $shop = $context->shop;
        $language = $langId ? new \Language($langId) : $context->language;

        // Récupérer les données d'accessibilité
        $compliance = $this->dashboardService->getCompliancePercentage($shopId);
        $lastScanDate = $this->dashboardService->getLastScanDate();
        $totalIssues = $this->dashboardService->getTotalIssueCount();

        // Générer le contenu de la déclaration
        $statement = [
            'shop_id' => $shopId,
            'lang_id' => $language->id,
            'shop_name' => $shop->name,
            'shop_url' => $this->getShopUrl(),
            'generated_at' => date('Y-m-d H:i:s'),
            'compliance_score' => $compliance,
            'last_audit_date' => $lastScanDate,
            'total_issues' => $totalIssues,
            'contact_email' => Configuration::get('PS_SHOP_EMAIL'),
            'contact_phone' => Configuration::get('PS_SHOP_PHONE'),
            'published' => true,
            'content' => $this->generateContent($shop, $compliance, $lastScanDate, $totalIssues, $language),
        ];

        // Sauvegarder en base de données
        $this->saveStatement($statement);

        return $statement;
    }

    public function getStatement(int $shopId, int $langId = null): ?array
    {
        $langCondition = $langId ? ' AND id_lang = ' . (int)$langId : '';
        $sql = 'SELECT * FROM ' . _DB_PREFIX_ . 'wepresta_eaa_statements WHERE id_shop = ' . (int)$shopId . $langCondition . ' ORDER BY generated_at DESC';
        $result = Db::getInstance()->getRow($sql);

        return $result ? $this->formatStatement($result, $langId) : null;
    }

    public function getAllStatements(int $shopId): array
    {
        $sql = 'SELECT s.*, l.name as language_name, l.iso_code
                FROM ' . _DB_PREFIX_ . 'wepresta_eaa_statements s
                LEFT JOIN ' . _DB_PREFIX_ . 'lang l ON s.id_lang = l.id_lang
                WHERE s.id_shop = ' . (int)$shopId . '
                ORDER BY s.generated_at DESC';
        $results = Db::getInstance()->executeS($sql);

        return array_map(function($result) {
            return $this->formatStatement($result, $result['id_lang']);
        }, $results);
    }

    private function generateContent(\Shop $shop, float $compliance, ?string $lastScanDate, int $totalIssues, \Language $language): string
    {
        // Utiliser les traductions de PrestaShop pour le contenu de base
        $translator = Context::getContext()->getTranslator();

        $content = [];

        // Introduction
        $content[] = '<h2>' . $translator->trans('Accessibility Statement', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h2>';
        $content[] = '<p>' . $translator->trans('%shop_name% is committed to making its website accessible in accordance with Article 47 of Law No. 2005-102 of February 11, 2005.', ['%shop_name%' => $shop->name], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';

        // État de conformité
        $content[] = '<h3>' . $translator->trans('Compliance Status', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';

        $complianceLevel = $compliance >= 90 ? 'compliant' : ($compliance >= 70 ? 'partially compliant' : 'not compliant');
        $content[] = '<p>' . $translator->trans('The %shop_name% website is %compliance_level% with WCAG 2.1 AA accessibility standards.', ['%shop_name%' => $shop->name, '%compliance_level%' => $translator->trans(ucfirst($complianceLevel), [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code)], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';

        $content[] = '<p><strong>' . $translator->trans('Accessibility Score:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</strong> ' . number_format($compliance, 1) . '%</p>';

        if ($lastScanDate) {
            $content[] = '<p><strong>' . $translator->trans('Last Audit:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</strong> ' . date('d/m/Y', strtotime($lastScanDate)) . '</p>';
        }

        // Résultats de l'audit
        $content[] = '<h3>' . $translator->trans('Audit Results', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';
        $content[] = '<p>' . $translator->trans('Our latest automated audit identified %count% accessibility issue(s).', ['%count%' => $totalIssues], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';

        // Mesures prises
        $content[] = '<h3>' . $translator->trans('Accessibility Measures', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';
        $content[] = '<p>' . $translator->trans('%shop_name% has taken the following measures for website accessibility:', ['%shop_name%' => $shop->name], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';
        $content[] = '<ul>';
        $content[] = '<li>' . $translator->trans('Use of automated accessibility checker', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '<li>' . $translator->trans('Automatic corrections of detected issues', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '<li>' . $translator->trans('Ongoing technical team training', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '<li>' . $translator->trans('Regular manual testing', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '</ul>';

        // Contenu non accessible
        $content[] = '<h3>' . $translator->trans('Non-Accessible Content', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';
        $content[] = '<p>' . $translator->trans('Despite our efforts, some content may not be fully accessible:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';
        $content[] = '<ul>';
        $content[] = '<li>' . $translator->trans('Some older multimedia content may not have subtitles', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '<li>' . $translator->trans('Some PDF documents may not be fully accessible', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '<li>' . $translator->trans('Some interactive elements may require improved keyboard navigation', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</li>';
        $content[] = '</ul>';

        // Contact
        $content[] = '<h3>' . $translator->trans('Report an Accessibility Issue', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';
        $content[] = '<p>' . $translator->trans('If you encounter an accessibility issue on this website, please contact us:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';
        $content[] = '<ul>';
        $content[] = '<li><strong>' . $translator->trans('Email:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</strong> ' . Configuration::get('PS_SHOP_EMAIL') . '</li>';
        if (Configuration::get('PS_SHOP_PHONE')) {
            $content[] = '<li><strong>' . $translator->trans('Phone:', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</strong> ' . Configuration::get('PS_SHOP_PHONE') . '</li>';
        }
        $content[] = '</ul>';

        // Défense
        $content[] = '<h3>' . $translator->trans('Defense', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</h3>';
        $content[] = '<p>' . $translator->trans('If you find an accessibility defect preventing you from accessing content or functionality on this site, please contact us so we can find a suitable solution.', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';
        $content[] = '<p>' . $translator->trans('If our response does not satisfy you, you can contact the Défenseur des droits.', [], 'ModulesWeprestaeaaaccessibilitycheckerFront', $language->language_code) . '</p>';

        return implode("\n", $content);
    }

    public function saveCustomTranslation(int $shopId, int $langId, array $translations): void
    {
        $data = [
            'id_shop' => $shopId,
            'id_lang' => $langId,
            'translations' => json_encode($translations),
            'updated_at' => date('Y-m-d H:i:s'),
        ];

        // Supprimer l'ancienne traduction
        Db::getInstance()->delete('wepresta_eaa_statement_translations',
            'id_shop = ' . (int)$shopId . ' AND id_lang = ' . (int)$langId);

        Db::getInstance()->insert('wepresta_eaa_statement_translations', $data);
    }

    public function getCustomTranslation(int $shopId, int $langId): array
    {
        $sql = 'SELECT translations FROM ' . _DB_PREFIX_ . 'wepresta_eaa_statement_translations
                WHERE id_shop = ' . (int)$shopId . ' AND id_lang = ' . (int)$langId;
        $result = Db::getInstance()->getValue($sql);

        return $result ? json_decode($result, true) : [];
    }

    private function saveStatement(array $statement): void
    {
        $data = [
            'id_shop' => $statement['shop_id'],
            'id_lang' => $statement['lang_id'],
            'shop_name' => pSQL($statement['shop_name']),
            'shop_url' => pSQL($statement['shop_url']),
            'generated_at' => pSQL($statement['generated_at']),
            'compliance_score' => (float) $statement['compliance_score'],
            'last_audit_date' => pSQL($statement['last_audit_date']),
            'total_issues' => (int) $statement['total_issues'],
            'contact_email' => pSQL($statement['contact_email']),
            'contact_phone' => pSQL($statement['contact_phone']),
            'content' => pSQL($statement['content'], true),
            'published' => (int) $statement['published'],
        ];

        Db::getInstance()->insert('wepresta_eaa_statements', $data);
    }

    private function formatStatement(array $result, int $langId = null): array
    {
        return [
            'id' => $result['id'],
            'lang_id' => $result['id_lang'],
            'shop_name' => $result['shop_name'],
            'shop_url' => $result['shop_url'],
            'generated_at' => $result['generated_at'],
            'compliance_score' => (float) $result['compliance_score'],
            'last_audit_date' => $result['last_audit_date'],
            'total_issues' => (int) $result['total_issues'],
            'contact_email' => $result['contact_email'],
            'contact_phone' => $result['contact_phone'],
            'content' => $result['content'],
            'published' => (bool) $result['published'],
            'url' => $this->getStatementUrl($langId),
            'language_name' => $result['language_name'] ?? '',
            'language_iso' => $result['iso_code'] ?? '',
        ];
    }

    private function getShopUrl(): string
    {
        return Tools::getShopDomainSsl(true, true) . '/';
    }

    private function getStatementUrl(int $langId = null): string
    {
        $context = Context::getContext();

        if ($langId !== null && $langId !== (int)$context->language->id) {
            // Pour générer l'URL dans une autre langue, on doit temporairement changer la langue du contexte
            $originalLanguage = $context->language;
            $targetLanguage = new \Language($langId);

            if ($targetLanguage->id) {
                // Sauvegarder la langue actuelle
                $context->language = $targetLanguage;

                // Générer l'URL avec la langue cible
                $url = $context->link->getModuleLink('wepresta_eaa_accessibility_checker', 'accessibilitystatement', [], true);

                // Restaurer la langue originale
                $context->language = $originalLanguage;

                return $url;
            }
        }

        // Pour la langue actuelle ou si pas de langue spécifiée
        return $context->link->getModuleLink('wepresta_eaa_accessibility_checker', 'accessibilitystatement', [], true);
    }

    public function togglePublished(int $shopId, int $langId, bool $published): void
    {
        Db::getInstance()->update(
            'wepresta_eaa_statements',
            ['published' => (int) $published],
            'id_shop = ' . (int) $shopId . ' AND id_lang = ' . (int) $langId
        );
    }

    public function deleteStatement(int $shopId, int $langId): void
    {
        Db::getInstance()->delete(
            'wepresta_eaa_statements',
            'id_shop = ' . (int) $shopId . ' AND id_lang = ' . (int) $langId
        );
    }
}
