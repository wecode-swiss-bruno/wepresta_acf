<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;

/**
 * Service for managing and grouping accessibility issues
 * Provides data for the 3-level Issues navigation
 */
class IssuesService
{
    private string $issuesTable;
    private string $scansTable;
    private string $snapshotsTable;

    /**
     * Issue type definitions with metadata
     */
    private const ISSUE_TYPES = [
        'image-alt' => [
            'label' => 'Images without alternative text',
            'wcag' => '1.1.1',
            'severity' => 'critical',
            'auto_fixable' => false,
            'action_type' => 'alt_editor',
            'tip' => 'Use the Alt Text Editor to fix all images in one place.',
        ],
        'link-name' => [
            'label' => 'Links with non-descriptive text',
            'wcag' => '2.4.4',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'label' => [
            'label' => 'Form inputs without labels',
            'wcag' => '3.3.2',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'You can automatically add ARIA labels to fix most of these issues.',
        ],
        'color-contrast' => [
            'label' => 'Insufficient color contrast',
            'wcag' => '1.4.3',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'html-has-lang' => [
            'label' => 'Missing document language',
            'wcag' => '3.1.1',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'This can be automatically fixed by configuring the language in PrestaShop settings.',
        ],
        'html-lang-valid' => [
            'label' => 'Invalid document language',
            'wcag' => '3.1.1',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => null,
        ],
        'document-title' => [
            'label' => 'Missing page titles',
            'wcag' => '2.4.2',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'skip-link' => [
            'label' => 'Missing skip links',
            'wcag' => '2.4.1',
            'severity' => 'moderate',
            'auto_fixable' => true,
            'action_type' => 'settings',
            'tip' => 'Enable skip links in the module settings to fix this automatically.',
        ],
        'bypass' => [
            'label' => 'No way to bypass blocks',
            'wcag' => '2.4.1',
            'severity' => 'moderate',
            'auto_fixable' => true,
            'action_type' => 'settings',
            'tip' => 'Enable skip links in the module settings to fix this automatically.',
        ],
        'aria-valid-attr' => [
            'label' => 'Invalid ARIA attributes',
            'wcag' => '4.1.2',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'aria-valid-attr-value' => [
            'label' => 'Invalid ARIA attribute values',
            'wcag' => '4.1.2',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'button-name' => [
            'label' => 'Buttons without accessible names',
            'wcag' => '4.1.2',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'You can automatically add ARIA labels to fix most of these issues.',
        ],
        'duplicate-id' => [
            'label' => 'Duplicate element IDs',
            'wcag' => '4.1.1',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'duplicate-id-active' => [
            'label' => 'Duplicate IDs on interactive elements',
            'wcag' => '4.1.1',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'duplicate-id-aria' => [
            'label' => 'Duplicate ARIA IDs',
            'wcag' => '4.1.1',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'page-has-heading-one' => [
            'label' => 'Missing heading structure',
            'wcag' => '1.3.1',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'meta-viewport' => [
            'label' => 'Viewport prevents zooming',
            'wcag' => '1.4.4',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'tabindex' => [
            'label' => 'Incorrect tabindex values',
            'wcag' => '2.1.1',
            'severity' => 'minor',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'focus-order-semantics' => [
            'label' => 'Focus order issues',
            'wcag' => '2.1.1',
            'severity' => 'minor',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
        ],
        'input-button-name' => [
            'label' => 'Input buttons without names',
            'wcag' => '3.3.2',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => null,
        ],
    ];

    /**
     * Severity order for sorting (higher = more severe)
     */
    private const SEVERITY_WEIGHTS = [
        'critical' => 4,
        'serious' => 3,
        'moderate' => 2,
        'minor' => 1,
    ];

    public function __construct(
        private readonly Connection $connection,
        string $dbPrefix
    ) {
        $this->issuesTable = $dbPrefix . 'wepresta_eaa_issues';
        $this->scansTable = $dbPrefix . 'wepresta_eaa_scans';
        $this->snapshotsTable = $dbPrefix . 'wepresta_eaa_snapshots';
    }

    /**
     * Get the active snapshot ID
     */
    private function getActiveSnapshotId(): ?int
    {
        $result = $this->connection->createQueryBuilder()
            ->select('id_snapshot')
            ->from($this->snapshotsTable)
            ->where('is_active = 1')
            ->execute()
            ->fetchOne();

        return $result ? (int) $result : null;
    }

    /**
     * Get issues summary for Level 1 (overview by type)
     * Returns issues grouped by type with counts and metadata
     */
    public function getIssuesSummary(
        ?string $severityFilter = null,
        ?string $pageTypeFilter = null,
        string $statusFilter = 'open'
    ): array {
        try {
            // Only get issues from active snapshot
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return [
                    'categories' => [],
                    'total_issues' => 0,
                    'total_pages' => 0,
                ];
            }

            $qb = $this->connection->createQueryBuilder()
                ->select(
                    'i.rule_id',
                    'i.severity',
                    'COUNT(DISTINCT i.id_issue) as count',
                    'COUNT(DISTINCT s.id_scan) as pages_affected'
                )
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->setParameter('snapshot', $snapshotId)
                ->groupBy('i.rule_id, i.severity')
                ->orderBy('count', 'DESC');

            // Status filter
            if ($statusFilter === 'open') {
                $qb->andWhere('i.fixed = 0')
                   ->andWhere('i.ignored = 0');
            } elseif ($statusFilter === 'fixed') {
                $qb->andWhere('i.fixed = 1');
            } elseif ($statusFilter === 'ignored') {
                $qb->andWhere('i.ignored = 1');
            }

            // Severity filter
            if ($severityFilter && $severityFilter !== 'all') {
                $qb->andWhere('i.severity = :severity')
                    ->setParameter('severity', $severityFilter);
            }

            // Page type filter
            if ($pageTypeFilter && $pageTypeFilter !== 'all') {
                $qb->andWhere('s.page_type = :pageType')
                    ->setParameter('pageType', $pageTypeFilter);
            }

            $results = $qb->execute()->fetchAllAssociative();

            // Aggregate by rule_id (combine different severities)
            $categories = [];
            $totalIssues = 0;
            $pagesSet = [];

            foreach ($results as $row) {
                $ruleId = $row['rule_id'];
                $count = (int) $row['count'];
                $pagesAffected = (int) $row['pages_affected'];
                $totalIssues += $count;

                if (!isset($categories[$ruleId])) {
                    $typeInfo = self::ISSUE_TYPES[$ruleId] ?? [
                        'label' => $this->humanizeRuleId($ruleId),
                        'wcag' => null,
                        'severity' => $row['severity'],
                        'auto_fixable' => false,
                        'action_type' => 'view_details',
                        'tip' => null,
                    ];

                    $categories[$ruleId] = [
                        'type' => $ruleId,
                        'label' => $typeInfo['label'],
                        'wcag' => $typeInfo['wcag'],
                        'severity' => $typeInfo['severity'],
                        'count' => 0,
                        'pages_affected' => 0,
                        'auto_fixable' => $typeInfo['auto_fixable'],
                        'action_type' => $typeInfo['action_type'],
                        'tip' => $typeInfo['tip'],
                    ];
                }

                $categories[$ruleId]['count'] += $count;
                $categories[$ruleId]['pages_affected'] = max(
                    $categories[$ruleId]['pages_affected'],
                    $pagesAffected
                );
            }

            // Sort by count descending, then by severity
            uasort($categories, function ($a, $b) {
                $severityA = self::SEVERITY_WEIGHTS[$a['severity']] ?? 0;
                $severityB = self::SEVERITY_WEIGHTS[$b['severity']] ?? 0;
                
                // First by severity (descending)
                if ($severityA !== $severityB) {
                    return $severityB <=> $severityA;
                }
                
                // Then by count (descending)
                return $b['count'] <=> $a['count'];
            });

            // Get total pages affected
            $totalPagesAffected = $this->getTotalPagesAffected($statusFilter);

            // Get fixed count
            $fixedCount = $this->getFixedCount();
            $totalCount = $this->getTotalCount();

            return [
                'total_issues' => $totalIssues,
                'total_pages_affected' => $totalPagesAffected,
                'fixed_count' => $fixedCount,
                'total_count' => $totalCount,
                'categories' => array_values($categories),
            ];

        } catch (\Exception $e) {
            return [
                'total_issues' => 0,
                'total_pages_affected' => 0,
                'fixed_count' => 0,
                'total_count' => 0,
                'categories' => [],
            ];
        }
    }

    /**
     * Get issues for a specific type (Level 2)
     * Returns issues grouped by page type
     */
    public function getIssuesByType(
        string $type,
        string $groupBy = 'page_type',
        int $page = 1,
        int $perPage = 20,
        string $statusFilter = 'open'
    ): array {
        try {
            $typeInfo = self::ISSUE_TYPES[$type] ?? [
                'label' => $this->humanizeRuleId($type),
                'wcag' => null,
                'severity' => 'moderate',
                'auto_fixable' => false,
                'action_type' => 'view_details',
                'tip' => null,
            ];

            // Get total count for this type
            $totalCount = $this->getCountByType($type, $statusFilter);

            // Build base query
            $fixedCondition = $statusFilter === 'open' ? 0 : ($statusFilter === 'fixed' ? 1 : null);

            if ($groupBy === 'page_type') {
                $groups = $this->getIssuesGroupedByPageType($type, $fixedCondition, $page, $perPage);
            } elseif ($groupBy === 'page_url') {
                $groups = $this->getIssuesGroupedByPageUrl($type, $fixedCondition, $page, $perPage);
            } else {
                $groups = $this->getIssuesFlatList($type, $fixedCondition, $page, $perPage);
            }

            return [
                'type' => $type,
                'label' => $typeInfo['label'],
                'wcag' => $typeInfo['wcag'],
                'severity' => $typeInfo['severity'],
                'auto_fixable' => $typeInfo['auto_fixable'],
                'action_type' => $typeInfo['action_type'],
                'tip' => $typeInfo['tip'],
                'total' => $totalCount,
                'groups' => $groups,
                'pagination' => [
                    'current_page' => $page,
                    'per_page' => $perPage,
                    'total_pages' => (int) ceil($totalCount / $perPage),
                ],
            ];

        } catch (\Exception $e) {
            return [
                'type' => $type,
                'label' => $type,
                'wcag' => null,
                'severity' => 'moderate',
                'auto_fixable' => false,
                'action_type' => 'view_details',
                'tip' => null,
                'total' => 0,
                'groups' => [],
                'pagination' => [
                    'current_page' => 1,
                    'per_page' => $perPage,
                    'total_pages' => 0,
                ],
            ];
        }
    }

    /**
     * Get issues grouped by page type
     */
    private function getIssuesGroupedByPageType(string $type, ?int $fixedCondition, int $page, int $perPage): array
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return [];
        }

        // First get counts by page type
        $qb = $this->connection->createQueryBuilder()
            ->select('s.page_type', 'COUNT(*) as count')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('i.rule_id = :type')
            ->andWhere('s.id_snapshot = :snapshot')
            ->setParameter('type', $type)
            ->setParameter('snapshot', $snapshotId)
            ->groupBy('s.page_type')
            ->orderBy('count', 'DESC');

        if ($fixedCondition !== null) {
            $qb->andWhere('i.fixed = :fixed')
                ->setParameter('fixed', $fixedCondition);
        }

        $pageTypeCounts = $qb->execute()->fetchAllAssociative();

        $groups = [];
        foreach ($pageTypeCounts as $row) {
            $pageType = $row['page_type'];
            
            // Get issues for this page type (limited)
            $issues = $this->getIssuesForGroup($type, 'page_type', $pageType, $fixedCondition, $perPage);

            $groups[] = [
                'group_type' => 'page_type',
                'group_value' => $pageType,
                'label' => $this->getPageTypeLabel($pageType),
                'count' => (int) $row['count'],
                'issues' => $issues,
            ];
        }

        return $groups;
    }

    /**
     * Get issues grouped by page URL
     */
    private function getIssuesGroupedByPageUrl(string $type, ?int $fixedCondition, int $page, int $perPage): array
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return [];
        }

        $qb = $this->connection->createQueryBuilder()
            ->select('s.page_url', 's.page_type', 'COUNT(*) as count')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('i.rule_id = :type')
            ->andWhere('s.id_snapshot = :snapshot')
            ->setParameter('type', $type)
            ->setParameter('snapshot', $snapshotId)
            ->groupBy('s.page_url, s.page_type')
            ->orderBy('count', 'DESC');

        if ($fixedCondition !== null) {
            $qb->andWhere('i.fixed = :fixed')
                ->setParameter('fixed', $fixedCondition);
        }

        $urlCounts = $qb->execute()->fetchAllAssociative();

        $groups = [];
        foreach ($urlCounts as $row) {
            $pageUrl = $row['page_url'];
            
            $issues = $this->getIssuesForGroup($type, 'page_url', $pageUrl, $fixedCondition, $perPage);

            $groups[] = [
                'group_type' => 'page_url',
                'group_value' => $pageUrl,
                'label' => $this->getUrlPath($pageUrl),
                'page_type' => $row['page_type'],
                'count' => (int) $row['count'],
                'issues' => $issues,
            ];
        }

        return $groups;
    }

    /**
     * Get issues as flat list
     */
    private function getIssuesFlatList(string $type, ?int $fixedCondition, int $page, int $perPage): array
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return [];
        }

        $offset = ($page - 1) * $perPage;

        $qb = $this->connection->createQueryBuilder()
            ->select(
                'i.id_issue',
                'i.rule_id',
                'i.severity',
                'i.selector',
                'i.message',
                'i.fixed',
                'i.date_add',
                's.page_url',
                's.page_type'
            )
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('i.rule_id = :type')
            ->andWhere('s.id_snapshot = :snapshot')
            ->setParameter('type', $type)
            ->setParameter('snapshot', $snapshotId)
            ->orderBy('i.severity', 'ASC')
            ->addOrderBy('i.date_add', 'DESC')
            ->setFirstResult($offset)
            ->setMaxResults($perPage);

        if ($fixedCondition !== null) {
            $qb->andWhere('i.fixed = :fixed')
                ->setParameter('fixed', $fixedCondition);
        }

        $issues = $qb->execute()->fetchAllAssociative();

        return [[
            'group_type' => 'all',
            'group_value' => 'all',
            'label' => 'All Issues',
            'count' => count($issues),
            'issues' => $this->formatIssues($issues),
        ]];
    }

    /**
     * Get issues for a specific group
     */
    private function getIssuesForGroup(
        string $type,
        string $groupBy,
        string $groupValue,
        ?int $fixedCondition,
        int $limit = 20
    ): array {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return [];
        }

        $qb = $this->connection->createQueryBuilder()
            ->select(
                'i.id_issue',
                'i.rule_id',
                'i.severity',
                'i.selector',
                'i.message',
                'i.fixed',
                'i.date_add',
                's.page_url',
                's.page_type'
            )
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('i.rule_id = :type')
            ->andWhere('s.id_snapshot = :snapshot')
            ->setParameter('type', $type)
            ->setParameter('snapshot', $snapshotId)
            ->orderBy('i.severity', 'ASC')
            ->addOrderBy('i.date_add', 'DESC')
            ->setMaxResults($limit);

        if ($groupBy === 'page_type') {
            $qb->andWhere('s.page_type = :groupValue')
                ->setParameter('groupValue', $groupValue);
        } elseif ($groupBy === 'page_url') {
            $qb->andWhere('s.page_url = :groupValue')
                ->setParameter('groupValue', $groupValue);
        }

        if ($fixedCondition !== null) {
            $qb->andWhere('i.fixed = :fixed')
                ->setParameter('fixed', $fixedCondition);
        }

        $issues = $qb->execute()->fetchAllAssociative();

        return $this->formatIssues($issues);
    }

    /**
     * Format issues for API response
     */
    private function formatIssues(array $issues): array
    {
        return array_map(function ($issue) {
            // Extract HTML element from selector if possible
            $htmlSnippet = $this->extractHtmlSnippet($issue['selector'] ?? '');

            return [
                'id' => (int) $issue['id_issue'],
                'rule_id' => $issue['rule_id'],
                'severity' => $issue['severity'],
                'selector' => $issue['selector'],
                'html_snippet' => $htmlSnippet,
                'message' => $issue['message'],
                'page_url' => $issue['page_url'],
                'page_type' => $issue['page_type'],
                'fixed' => (bool) $issue['fixed'],
                'date_add' => $issue['date_add'],
            ];
        }, $issues);
    }

    /**
     * Bulk update issue status
     */
    public function bulkUpdateStatus(array $issueIds, string $action): array
    {
        if (empty($issueIds)) {
            return ['success' => false, 'count' => 0, 'message' => 'No issues provided'];
        }

        $validActions = ['fixed', 'ignored', 'open'];
        if (!in_array($action, $validActions)) {
            return ['success' => false, 'count' => 0, 'message' => 'Invalid action'];
        }

        try {
            $fixed = $action === 'open' ? 0 : 1;

            $placeholders = [];
            $params = ['fixed' => $fixed];
            
            foreach ($issueIds as $index => $id) {
                $placeholders[] = ':id' . $index;
                $params['id' . $index] = (int) $id;
            }

            $sql = sprintf(
                'UPDATE %s SET fixed = :fixed WHERE id_issue IN (%s)',
                $this->issuesTable,
                implode(', ', $placeholders)
            );

            $stmt = $this->connection->prepare($sql);
            foreach ($params as $key => $value) {
                $stmt->bindValue($key, $value);
            }
            $stmt->execute();
            $count = $stmt->rowCount();

            return [
                'success' => true,
                'count' => $count,
                'message' => sprintf('%d issue(s) marked as %s', $count, $action),
            ];

        } catch (\Exception $e) {
            return [
                'success' => false,
                'count' => 0,
                'message' => 'Error updating issues: ' . $e->getMessage(),
            ];
        }
    }

    /**
     * Get count of issues by type
     */
    private function getCountByType(string $type, string $statusFilter): int
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return 0;
        }

        $qb = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('i.rule_id = :type')
            ->andWhere('s.id_snapshot = :snapshot')
            ->setParameter('type', $type)
            ->setParameter('snapshot', $snapshotId);

        if ($statusFilter === 'open') {
            $qb->andWhere('i.fixed = 0')->andWhere('i.ignored = 0');
        } elseif ($statusFilter === 'fixed') {
            $qb->andWhere('i.fixed = 1');
        } elseif ($statusFilter === 'ignored') {
            $qb->andWhere('i.ignored = 1');
        }

        return (int) $qb->execute()->fetchOne();
    }

    /**
     * Get total pages affected
     */
    private function getTotalPagesAffected(string $statusFilter): int
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return 0;
        }

        $qb = $this->connection->createQueryBuilder()
            ->select('COUNT(DISTINCT s.id_scan)')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('s.id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId);

        if ($statusFilter === 'open') {
            $qb->andWhere('i.fixed = 0')->andWhere('i.ignored = 0');
        } elseif ($statusFilter === 'fixed') {
            $qb->andWhere('i.fixed = 1');
        } elseif ($statusFilter === 'ignored') {
            $qb->andWhere('i.ignored = 1');
        }

        return (int) $qb->execute()->fetchOne();
    }

    /**
     * Get count of fixed issues
     */
    private function getFixedCount(): int
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return 0;
        }

        return (int) $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('s.id_snapshot = :snapshot')
            ->andWhere('i.fixed = 1')
            ->setParameter('snapshot', $snapshotId)
            ->execute()
            ->fetchOne();
    }

    /**
     * Get total issue count
     */
    private function getTotalCount(): int
    {
        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return 0;
        }

        return (int) $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('s.id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->execute()
            ->fetchOne();
    }

    /**
     * Get page type label
     */
    private function getPageTypeLabel(string $pageType): string
    {
        $labels = [
            'home' => 'Home page',
            'product' => 'Product pages',
            'category' => 'Category pages',
            'cms' => 'CMS pages',
            'checkout' => 'Checkout pages',
            'other' => 'Other pages',
        ];

        return $labels[$pageType] ?? ucfirst($pageType) . ' pages';
    }

    /**
     * Extract URL path from full URL
     */
    private function getUrlPath(string $url): string
    {
        $parsed = parse_url($url);
        $path = $parsed['path'] ?? '/';
        
        // Truncate if too long
        if (strlen($path) > 50) {
            $path = substr($path, 0, 47) . '...';
        }

        return $path;
    }

    /**
     * Convert rule_id to human-readable label
     */
    private function humanizeRuleId(string $ruleId): string
    {
        return ucfirst(str_replace(['-', '_'], ' ', $ruleId));
    }

    /**
     * Extract a displayable HTML snippet from selector
     */
    private function extractHtmlSnippet(?string $selector): string
    {
        if (!$selector) {
            return '';
        }

        // If selector looks like HTML, truncate it
        if (strpos($selector, '<') !== false) {
            $snippet = htmlspecialchars($selector);
            if (strlen($snippet) > 200) {
                $snippet = substr($snippet, 0, 197) . '...';
            }
            return $snippet;
        }

        // Otherwise, format selector as element reference
        return htmlspecialchars($selector);
    }

    /**
     * Get issue type metadata
     */
    public function getIssueTypeMetadata(string $type): ?array
    {
        return self::ISSUE_TYPES[$type] ?? null;
    }

    /**
     * Get all issue type definitions
     */
    public function getAllIssueTypes(): array
    {
        return self::ISSUE_TYPES;
    }
}
