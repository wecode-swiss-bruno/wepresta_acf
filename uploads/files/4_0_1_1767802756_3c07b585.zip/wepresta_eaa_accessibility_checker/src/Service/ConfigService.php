<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Configuration;

class ConfigService
{
    private const PREFIX = 'WEPRESTA_EAA_';

    public function getConfiguration(): array
    {
        return [
            'enabled' => (bool) Configuration::get(self::PREFIX . 'ENABLED'),
            'auto_fix_enabled' => (bool) Configuration::get(self::PREFIX . 'AUTO_FIX_ENABLED'),
            'auto_fix_enabled_at' => Configuration::get(self::PREFIX . 'AUTO_FIX_ENABLED_AT'),
        ];
    }

    public function getAutoScanConfiguration(): array
    {
        return [
            'enabled' => (bool) Configuration::get(self::PREFIX . 'AUTOSCAN_ENABLED'),
            'frequency' => (string) Configuration::get(self::PREFIX . 'AUTOSCAN_FREQUENCY', 'weekly'),
            'dayOfWeek' => (int) Configuration::get(self::PREFIX . 'AUTOSCAN_DAY_OF_WEEK', 1), // Monday
            'dayOfMonth' => (int) Configuration::get(self::PREFIX . 'AUTOSCAN_DAY_OF_MONTH', 1),
            'hour' => (int) Configuration::get(self::PREFIX . 'AUTOSCAN_HOUR', 3), // 3:00 AM
            'notificationsEnabled' => (bool) Configuration::get(self::PREFIX . 'AUTOSCAN_NOTIFY'),
            'email' => (string) Configuration::get(self::PREFIX . 'AUTOSCAN_EMAIL', ''),
        ];
    }

    public function saveConfiguration(array $data): void
    {
        Configuration::updateValue(self::PREFIX . 'ENABLED', (bool) ($data['enabled'] ?? false));
        Configuration::updateValue(self::PREFIX . 'AUTO_FIX_ENABLED', (bool) ($data['auto_fix_enabled'] ?? false));
        Configuration::updateValue(self::PREFIX . 'AUTO_FIX_ENABLED_AT', $data['auto_fix_enabled_at'] ?? null);
    }

    public function saveAutoScanConfiguration(array $data): void
    {
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_ENABLED', (bool) ($data['enabled'] ?? false));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_FREQUENCY', (string) ($data['frequency'] ?? 'weekly'));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_DAY_OF_WEEK', (int) ($data['dayOfWeek'] ?? 1));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_DAY_OF_MONTH', (int) ($data['dayOfMonth'] ?? 1));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_HOUR', (int) ($data['hour'] ?? 3));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_NOTIFY', (bool) ($data['notificationsEnabled'] ?? false));
        Configuration::updateValue(self::PREFIX . 'AUTOSCAN_EMAIL', (string) ($data['email'] ?? ''));
    }

    public function deleteConfiguration(): void
    {
        Configuration::deleteByName(self::PREFIX . 'ENABLED');
        Configuration::deleteByName(self::PREFIX . 'AUTO_FIX_ENABLED');
    }

    public function get(string $key): mixed
    {
        return Configuration::get(self::PREFIX . strtoupper($key));
    }
}
