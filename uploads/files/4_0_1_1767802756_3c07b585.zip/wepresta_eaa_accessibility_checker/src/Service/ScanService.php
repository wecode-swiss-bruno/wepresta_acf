<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Wepresta\EaaAccessibilityChecker\Repository\IssueRepository;
use Wepresta\EaaAccessibilityChecker\Repository\ScanRepository;
use Wepresta\EaaAccessibilityChecker\Repository\SnapshotRepository;
use Wepresta\EaaAccessibilityChecker\Scanner\DomScanner;
use Wepresta\EaaAccessibilityChecker\Service\ConfigService;

class ScanService
{
    private const FETCH_TIMEOUT_SECONDS = 30;
    private const FETCH_CONNECT_TIMEOUT_SECONDS = 10;
    private const FETCH_MAX_REDIRECTS = 10;
    private const FETCH_USER_AGENT = 'WeprestaEaaAccessibilityChecker/1.0 (+https://wepresta.shop)';

    /**
     * Current scan session snapshot ID
     */
    private ?int $currentSnapshotId = null;

    public function __construct(
        private readonly ScanRepository $scanRepository,
        private readonly IssueRepository $issueRepository,
        private readonly SnapshotRepository $snapshotRepository,
        private readonly DomScanner $domScanner,
        private readonly ConfigService $configService
    ) {
    }

    /**
     * Start a new scan session (creates a new snapshot)
     * Call this before scanning multiple pages
     */
    public function startNewScanSession(?string $label = null): int
    {
        $this->currentSnapshotId = $this->snapshotRepository->createNew($label);
        return $this->currentSnapshotId;
    }

    /**
     * Finish the current scan session (updates snapshot stats)
     * Call this after scanning all pages
     */
    public function finishScanSession(): void
    {
        // Get the active snapshot from DB (since currentSnapshotId may be null in a new request)
        $activeSnapshot = $this->snapshotRepository->getActive();
        
        if ($activeSnapshot) {
            $this->snapshotRepository->updateStats((int) $activeSnapshot['id_snapshot']);
        }
        
        $this->currentSnapshotId = null;
    }

    /**
     * Get or create the current snapshot for scanning
     */
    private function ensureSnapshot(): int
    {
        if ($this->currentSnapshotId !== null) {
            return $this->currentSnapshotId;
        }

        // Check if there's an active snapshot
        $active = $this->snapshotRepository->getActive();
        if ($active) {
            $this->currentSnapshotId = (int) $active['id_snapshot'];
            return $this->currentSnapshotId;
        }

        // Create a new one
        return $this->startNewScanSession();
    }

    /**
     * Scan a URL and save results to current snapshot
     */
    public function scanUrl(string $url, string $pageType = 'other'): array
    {
        $html = $this->fetchHtml($url);

        return $this->scanHtml($html, $url, $pageType);
    }

    /**
     * Fetch HTML from an URL in a hosting-friendly way.
     *
     * Some production hosts disable allow_url_fopen, block outgoing HTTP,
     * or require a proper User-Agent / redirect handling. Prefer cURL when available.
     */
    private function fetchHtml(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            throw new \InvalidArgumentException('URL is required');
        }

        // Keep it simple: only allow http(s) for now.
        $parsed = parse_url($url);
        $scheme = is_array($parsed) ? strtolower((string) ($parsed['scheme'] ?? '')) : '';
        if (!in_array($scheme, ['http', 'https'], true)) {
            throw new \InvalidArgumentException('Invalid URL scheme (only http/https are supported)');
        }

        if (function_exists('curl_init')) {
            return $this->fetchHtmlWithCurl($url);
        }

        $allowUrlFopen = filter_var((string) ini_get('allow_url_fopen'), FILTER_VALIDATE_BOOLEAN);
        if (!$allowUrlFopen) {
            throw new \RuntimeException(
                'Cannot fetch remote URLs: PHP setting "allow_url_fopen" is disabled and cURL extension is not available. ' .
                'Enable allow_url_fopen or install/enable ext-curl.'
            );
        }

        $headers = [
            'User-Agent: ' . self::FETCH_USER_AGENT,
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Encoding: identity',
        ];

        $context = stream_context_create([
            'http' => [
                'method' => 'GET',
                'header' => implode("\r\n", $headers),
                'timeout' => self::FETCH_TIMEOUT_SECONDS,
                'follow_location' => 1,
                'max_redirects' => self::FETCH_MAX_REDIRECTS,
                // We want the response body even when HTTP status is 4xx/5xx so we can report meaningful errors
                'ignore_errors' => true,
            ],
            'ssl' => [
                'verify_peer' => true,
                'verify_peer_name' => true,
            ],
        ]);

        // Suppress warnings to avoid breaking JSON responses, we re-surface errors with context below.
        $html = @file_get_contents($url, false, $context);
        $responseHeaders = $http_response_header ?? [];
        $status = $this->extractHttpStatusCode($responseHeaders);

        if ($html === false) {
            $err = error_get_last();
            $message = is_array($err) ? (string) ($err['message'] ?? '') : '';
            $statusText = $status ? "HTTP {$status}" : 'HTTP (unknown)';
            throw new \RuntimeException(sprintf('Could not fetch URL: %s (%s). %s', $url, $statusText, $message));
        }

        // file_get_contents can return content even on error codes when ignore_errors=true
        if ($status !== null && $status >= 400) {
            throw new \RuntimeException(sprintf('HTTP %d when fetching URL: %s', $status, $url));
        }

        return (string) $html;
    }

    /**
     * @param array<int, string> $headers
     */
    private function extractHttpStatusCode(array $headers): ?int
    {
        if (empty($headers) || !isset($headers[0])) {
            return null;
        }

        // Example: HTTP/2 200
        if (preg_match('#^HTTP/\d+(?:\.\d+)?\s+(\d{3})\b#i', (string) $headers[0], $m)) {
            return (int) $m[1];
        }

        // Example: HTTP/2 200 (some servers omit the slash)
        if (preg_match('#^HTTP\s+(\d{3})\b#i', (string) $headers[0], $m)) {
            return (int) $m[1];
        }

        return null;
    }

    private function fetchHtmlWithCurl(string $url): string
    {
        // Retry strategy:
        // - default resolver first
        // - if SSL host mismatch occurs (cURL 60), retry forcing IPv4 (common with broken IPv6 stacks)
        $attempts = [
            ['ipresolve' => null],
            // Retry forcing IPv4 (common with broken IPv6 stacks)
            ['ipresolve' => defined('CURL_IPRESOLVE_V4') ? CURL_IPRESOLVE_V4 : 1],
        ];

        $lastErrno = 0;
        $lastError = '';
        $lastHttpCode = 0;

        foreach ($attempts as $idx => $attempt) {
            $ipResolve = $attempt['ipresolve'] ?? null;

            $ch = curl_init();
            if ($ch === false) {
                throw new \RuntimeException('Could not initialize cURL');
            }

            $options = [
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_MAXREDIRS => self::FETCH_MAX_REDIRECTS,
                CURLOPT_CONNECTTIMEOUT => self::FETCH_CONNECT_TIMEOUT_SECONDS,
                CURLOPT_TIMEOUT => self::FETCH_TIMEOUT_SECONDS,
                CURLOPT_USERAGENT => self::FETCH_USER_AGENT,
                CURLOPT_HTTPHEADER => [
                    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                ],
                // Enable decoding (gzip/deflate) transparently
                CURLOPT_ENCODING => '',
                // TLS verification (recommended for production)
                CURLOPT_SSL_VERIFYPEER => true,
                CURLOPT_SSL_VERIFYHOST => 2,
            ];

            if ($ipResolve !== null) {
                $options[CURLOPT_IPRESOLVE] = (int) $ipResolve;
            }

            curl_setopt_array($ch, $options);

            $body = curl_exec($ch);
            $errno = curl_errno($ch);
            $error = curl_error($ch);
            $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($body !== false && $httpCode < 400) {
                return (string) $body;
            }

            $lastErrno = $errno;
            $lastError = $error;
            $lastHttpCode = $httpCode;

            // If this is the first attempt and we hit a certificate error, retry with IPv4.
            if ($idx === 0 && $errno === 60 && count($attempts) > 1) {
                continue;
            }

            // HTTP errors (4xx/5xx) should not be retried.
            if ($httpCode >= 400) {
                throw new \RuntimeException(sprintf('HTTP %d when fetching URL: %s', $httpCode, $url));
            }

            // cURL transport/SSL errors
            $msg = $error !== '' ? $error : 'unknown error';
            throw new \RuntimeException(sprintf('Could not fetch URL: %s (cURL error %d: %s)', $url, $errno, $msg));
        }

        $msg = $lastError !== '' ? $lastError : 'unknown error';
        throw new \RuntimeException(sprintf('Could not fetch URL: %s (cURL error %d: %s)', $url, $lastErrno, $msg));
    }

    /**
     * Scan HTML content and save results to current snapshot
     */
    public function scanHtml(string $html, string $url, string $pageType = 'other'): array
    {
        $snapshotId = $this->ensureSnapshot();

        // Configure scanner to ignore auto-fixed elements if auto-fix is enabled
        $autoFixEnabled = (bool) $this->configService->get('auto_fix_enabled');
        $this->domScanner->setIgnoreAutoFixed($autoFixEnabled);

        $issues = $this->domScanner->scanHtml($html);
        $score = $this->calculateScore($issues);

        $scanId = $this->scanRepository->save([
            'id_snapshot' => $snapshotId,
            'page_url' => $url,
            'page_type' => $pageType,
            'score' => $score,
            'issues_count' => count($issues),
        ]);

        $this->issueRepository->saveBatch($scanId, $issues);

        return [
            'id_scan' => $scanId,
            'id_snapshot' => $snapshotId,
            'url' => $url,
            'page_type' => $pageType,
            'score' => $score,
            'issues_count' => count($issues),
            'issues' => $issues,
        ];
    }

    /**
     * Process Axe-core scan results
     */
    public function processAxeResults(array $axeResults, string $url, string $pageType = 'other'): array
    {
        $snapshotId = $this->ensureSnapshot();
        $issues = [];

        foreach ($axeResults['violations'] ?? [] as $violation) {
            foreach ($violation['nodes'] ?? [] as $node) {
                $issues[] = [
                    'rule_id' => $violation['id'],
                    'severity' => $violation['impact'] ?? 'moderate',
                    'selector' => $node['target'][0] ?? null,
                    'message' => $violation['description'] ?? $violation['help'],
                ];
            }
        }

        $score = $axeResults['score'] ?? $this->calculateScore($issues);

        $scanId = $this->scanRepository->save([
            'id_snapshot' => $snapshotId,
            'page_url' => $url,
            'page_type' => $pageType,
            'score' => $score,
            'issues_count' => count($issues),
        ]);

        $this->issueRepository->saveBatch($scanId, $issues);

        return [
            'id_scan' => $scanId,
            'id_snapshot' => $snapshotId,
            'url' => $url,
            'page_type' => $pageType,
            'score' => $score,
            'issues_count' => count($issues),
        ];
    }

    /**
     * Calculate accessibility score based on issues
     */
    public function calculateScore(array $issues): int
    {
        $weights = [
            'critical' => 10,
            'serious' => 5,
            'moderate' => 2,
            'minor' => 1,
        ];

        $penalty = 0;
        foreach ($issues as $issue) {
            $severity = $issue['severity'] ?? 'moderate';
            $penalty += $weights[$severity] ?? 2;
        }

        return max(0, 100 - $penalty);
    }

    /**
     * Get the active snapshot
     */
    public function getActiveSnapshot(): ?array
    {
        return $this->snapshotRepository->getActive();
    }

    /**
     * Get snapshot history for chart/comparison
     */
    public function getSnapshotHistory(int $limit = 10): array
    {
        return $this->snapshotRepository->getScoreHistory(1, $limit);
    }

    /**
     * Get comparison between current and previous snapshot
     */
    public function getSnapshotComparison(): ?array
    {
        return $this->snapshotRepository->getComparison();
    }

    /**
     * Get latest scans from active snapshot
     */
    public function getLatestScans(int $limit = 10): array
    {
        $snapshot = $this->snapshotRepository->getActive();
        if (!$snapshot) {
            return [];
        }
        return $this->scanRepository->findBySnapshot((int) $snapshot['id_snapshot'], $limit);
    }

    /**
     * Get paginated scans from active snapshot
     */
    public function getPaginatedScans(int $page = 1, int $perPage = 10): array
    {
        $snapshot = $this->snapshotRepository->getActive();
        if (!$snapshot) {
            return [
                'scans' => [],
                'total_count' => 0,
                'total_pages' => 0,
                'current_page' => $page,
            ];
        }

        $snapshotId = (int) $snapshot['id_snapshot'];
        $offset = ($page - 1) * $perPage;
        $scans = $this->scanRepository->findBySnapshot($snapshotId, $perPage, $offset);
        $totalCount = $this->scanRepository->countBySnapshot($snapshotId);
        $totalPages = (int) ceil($totalCount / $perPage);

        return [
            'scans' => $scans,
            'total_count' => $totalCount,
            'total_pages' => $totalPages,
            'current_page' => $page,
        ];
    }

    /**
     * Get scan count from active snapshot
     */
    public function getScanCount(): int
    {
        $snapshot = $this->snapshotRepository->getActive();
        if (!$snapshot) {
            return 0;
        }
        return $this->scanRepository->countBySnapshot((int) $snapshot['id_snapshot']);
    }

    /**
     * Get scan details
     */
    public function getScanDetails(int $scanId): ?array
    {
        $scan = $this->scanRepository->findById($scanId);

        if (!$scan) {
            return null;
        }

        $scan['issues'] = $this->issueRepository->findByScanId($scanId);

        return $scan;
    }

    /**
     * Get dashboard statistics from active snapshot
     */
    public function getDashboardStats(): array
    {
        $snapshot = $this->snapshotRepository->getActive();
        
        if (!$snapshot) {
            return [
                'average_score' => 0,
                'scores_by_page_type' => [],
                'issues_by_severity' => [],
                'score_history' => [],
            ];
        }

        $snapshotId = (int) $snapshot['id_snapshot'];

        return [
            'average_score' => round($this->scanRepository->getAverageScoreBySnapshot($snapshotId), 1),
            'scores_by_page_type' => $this->scanRepository->getScoresByPageTypeAndSnapshot($snapshotId),
            'issues_by_severity' => $this->issueRepository->countBySeverityAndSnapshot($snapshotId),
            'score_history' => $this->snapshotRepository->getScoreHistory(1, 10),
        ];
    }

    /**
     * Clear all scans and snapshots
     */
    public function clearAllScans(): int
    {
        $this->currentSnapshotId = null;
        // Deleting snapshots will cascade delete scans and issues
        return $this->snapshotRepository->deleteAll();
    }

    /**
     * Delete a specific scan
     */
    public function deleteScan(int $scanId): bool
    {
        // Delete issues for this scan first (cascade should handle this)
        $this->issueRepository->deleteByScanId($scanId);

        // Then delete the scan
        return $this->scanRepository->deleteById($scanId);
    }

    /**
     * Check if there are any scans
     */
    public function hasScans(): bool
    {
        return $this->snapshotRepository->hasActive();
    }
}
