<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;
use Configuration;
use Context;

class DashboardService
{
    private string $manualCheckTable;
    private string $issuesTable;
    private string $scansTable;
    private string $snapshotsTable;
    private string $imageTable;
    private string $imageLangTable;
    private string $langTable;

    /**
     * Automated WCAG criteria - can be verified by the scanner
     * Maps scanner rule_id to WCAG criterion
     */
    private const AUTOMATED_CRITERIA = [
        '1.1.1' => [
            'name' => 'Non-text Content',
            'description' => 'All non-text content has text alternatives',
            'scanner_checks' => 'Images without alt, empty alt, alt="image"',
            'scanner_rules' => ['image-alt'],
        ],
        '1.3.1' => [
            'name' => 'Info and Relationships',
            'description' => 'Information and relationships conveyed through presentation can be programmatically determined',
            'scanner_checks' => 'Heading structure (h1-h6), form labels, ARIA landmarks',
            'scanner_rules' => ['label', 'page-has-heading-one'],
        ],
        '1.4.3' => [
            'name' => 'Contrast (Minimum)',
            'description' => 'Text has contrast ratio of at least 4.5:1',
            'scanner_checks' => 'Text/background contrast ratio >= 4.5:1',
            'scanner_rules' => ['color-contrast'],
        ],
        '1.4.4' => [
            'name' => 'Resize Text',
            'description' => 'Text can be resized up to 200% without loss of functionality',
            'scanner_checks' => 'Relative units (em, rem, %) vs fixed (px)',
            'scanner_rules' => ['meta-viewport'],
        ],
        '2.1.1' => [
            'name' => 'Keyboard',
            'description' => 'All functionality available via keyboard',
            'scanner_checks' => 'Interactive elements with tabindex, focus visible',
            'scanner_rules' => ['tabindex', 'focus-order-semantics'],
        ],
        '2.4.1' => [
            'name' => 'Bypass Blocks',
            'description' => 'Skip navigation mechanism available',
            'scanner_checks' => 'Presence of skip links',
            'scanner_rules' => ['skip-link', 'bypass'],
        ],
        '2.4.2' => [
            'name' => 'Page Titled',
            'description' => 'Pages have descriptive titles',
            'scanner_checks' => '<title> tag present and relevant',
            'scanner_rules' => ['document-title'],
        ],
        '2.4.4' => [
            'name' => 'Link Purpose (In Context)',
            'description' => 'Link purpose can be determined from link text or context',
            'scanner_checks' => 'Links with explicit text (not "click here")',
            'scanner_rules' => ['link-name'],
        ],
        '3.1.1' => [
            'name' => 'Language of Page',
            'description' => 'Page language is programmatically determined',
            'scanner_checks' => 'lang attribute on <html>',
            'scanner_rules' => ['html-has-lang', 'html-lang-valid'],
        ],
        '3.3.2' => [
            'name' => 'Labels or Instructions',
            'description' => 'Labels or instructions provided for user input',
            'scanner_checks' => 'Labels associated with inputs',
            'scanner_rules' => ['label', 'input-button-name'],
        ],
        '4.1.1' => [
            'name' => 'Parsing',
            'description' => 'No major HTML parsing errors',
            'scanner_checks' => 'HTML validity, unique IDs',
            'scanner_rules' => ['duplicate-id', 'duplicate-id-active', 'duplicate-id-aria'],
        ],
        '4.1.2' => [
            'name' => 'Name, Role, Value',
            'description' => 'UI components have accessible names and roles',
            'scanner_checks' => 'Correct ARIA attributes',
            'scanner_rules' => ['button-name', 'aria-valid-attr', 'aria-valid-attr-value'],
        ],
    ];

    /**
     * Manual WCAG criteria - require human verification
     */
    private const MANUAL_CRITERIA = [
        '1.2.1' => [
            'name' => 'Audio-only and Video-only (Prerecorded)',
            'description' => 'Audio-only content has text transcription, video-only has audio or text alternative',
            'verification_guide' => 'Check that all audio-only content (podcasts, audio files) have a text transcription. Video-only content (animations without audio) must have an audio description or text alternative.',
        ],
        '1.2.2' => [
            'name' => 'Captions (Prerecorded)',
            'description' => 'Captions provided for prerecorded audio content in synchronized media',
            'verification_guide' => 'Watch all videos with sound on your site and verify they have synchronized captions. Captions must be accurate and include speaker identification when needed.',
        ],
        '1.2.3' => [
            'name' => 'Audio Description or Media Alternative',
            'description' => 'Audio description provided for prerecorded video content',
            'verification_guide' => 'Check videos containing important visual information not conveyed by audio. Ensure audio description or text transcript is available.',
        ],
        '1.3.3' => [
            'name' => 'Sensory Characteristics',
            'description' => 'Instructions do not rely solely on sensory characteristics',
            'verification_guide' => 'Review instructions that reference shape, color, size, location, or sound. Example: "Click the round button" should also say "Click the Submit button".',
        ],
        '1.4.1' => [
            'name' => 'Use of Color',
            'description' => 'Color is not the only visual means of conveying information',
            'verification_guide' => 'Check error messages, form validation, required fields, charts/graphs. Information must be conveyed by more than color alone (icons, text, patterns).',
        ],
        '2.2.1' => [
            'name' => 'Timing Adjustable',
            'description' => 'Time limits can be adjusted, extended, or disabled',
            'verification_guide' => 'Check session timeouts, cart expiration, auto-logout. Users must be able to extend time or have at least 20 hours. Exception: real-time events.',
        ],
        '2.3.1' => [
            'name' => 'Three Flashes or Below Threshold',
            'description' => 'No content flashes more than 3 times per second',
            'verification_guide' => 'Check animations, videos, GIFs for flashing content. Content must not flash more than 3 times per second or stay below flash thresholds.',
        ],
        '2.4.3' => [
            'name' => 'Focus Order',
            'description' => 'Focus order preserves meaning and operability',
            'verification_guide' => 'Navigate the entire site using Tab key only. Focus order should follow logical reading order (left to right, top to bottom in LTR languages).',
        ],
        '2.4.6' => [
            'name' => 'Headings and Labels',
            'description' => 'Headings and labels describe topic or purpose',
            'verification_guide' => 'Review all headings and form labels. They should clearly describe the content they introduce or the input they require.',
        ],
        '3.1.2' => [
            'name' => 'Language of Parts',
            'description' => 'Language of page parts is programmatically determined',
            'verification_guide' => 'Find text in languages other than the main page language. These must have lang attribute (e.g., <span lang="es">Hola</span>).',
        ],
        '3.2.1' => [
            'name' => 'On Focus',
            'description' => 'Focus does not cause unexpected context changes',
            'verification_guide' => 'Tab through all interactive elements. Moving focus should never automatically submit forms, open new windows, or change context unexpectedly.',
        ],
        '3.2.2' => [
            'name' => 'On Input',
            'description' => 'Input does not cause unexpected context changes',
            'verification_guide' => 'Test all form controls. Entering data should not automatically submit, navigate, or change context without warning. Use explicit submit buttons.',
        ],
        '3.3.1' => [
            'name' => 'Error Identification',
            'description' => 'Input errors are identified and described to the user',
            'verification_guide' => 'Submit forms with errors intentionally. Error messages must clearly identify which field has an error and describe the error in text.',
        ],
        '3.3.3' => [
            'name' => 'Error Suggestion',
            'description' => 'Error messages provide suggestions for correction',
            'verification_guide' => 'Trigger form errors. Messages should suggest how to fix the error (e.g., "Email must include @" not just "Invalid email").',
        ],
    ];

    /**
     * Mapping from scanner rule_id to WCAG criteria
     */
    private const RULE_TO_WCAG = [
        'image-alt' => '1.1.1',
        'label' => '1.3.1',
        'page-has-heading-one' => '1.3.1',
        'color-contrast' => '1.4.3',
        'meta-viewport' => '1.4.4',
        'tabindex' => '2.1.1',
        'focus-order-semantics' => '2.1.1',
        'skip-link' => '2.4.1',
        'bypass' => '2.4.1',
        'document-title' => '2.4.2',
        'link-name' => '2.4.4',
        'html-has-lang' => '3.1.1',
        'html-lang-valid' => '3.1.1',
        'input-button-name' => '3.3.2',
        'duplicate-id' => '4.1.1',
        'duplicate-id-active' => '4.1.1',
        'duplicate-id-aria' => '4.1.1',
        'button-name' => '4.1.2',
        'aria-valid-attr' => '4.1.2',
        'aria-valid-attr-value' => '4.1.2',
    ];

    public function __construct(
        private readonly Connection $connection,
        string $dbPrefix
    ) {
        $this->manualCheckTable = $dbPrefix . 'wepresta_eaa_manual_check';
        $this->issuesTable = $dbPrefix . 'wepresta_eaa_issues';
        $this->scansTable = $dbPrefix . 'wepresta_eaa_scans';
        $this->snapshotsTable = $dbPrefix . 'wepresta_eaa_snapshots';
        $this->imageTable = $dbPrefix . 'image';
        $this->imageLangTable = $dbPrefix . 'image_lang';
        $this->langTable = $dbPrefix . 'lang';
    }

    /**
     * Translate a string using PrestaShop translator
     */
    private function trans(string $key, array $params = [], string $domain = 'ModulesWeprestaeaaaccessibilitycheckerAdmin'): string
    {
        $translator = Context::getContext()->getTranslator();
        $language = Context::getContext()->language;

        return $translator->trans($key, $params, $domain, $language->locale);
    }

    /**
     * Multilang product image alt-text coverage based on ps_image_lang.
     *
     * "Complete" means: for every active language, the image has a non-empty legend.
     *
     * @return array{
     *   total_images:int,
     *   active_languages:int,
     *   complete_all_languages:int,
     *   incomplete_any_language:int,
     *   is_fully_complete:bool,
     *   languages: array<int, array{id_lang:int, iso_code:string, missing:int, filled:int}>
     * }
     */
    public function getProductImagesAltMultilangStatus(): array
    {
        try {
            $totalImages = (int) $this->connection->createQueryBuilder()
                ->select('COUNT(*)')
                ->from($this->imageTable, 'i')
                ->execute()
                ->fetchOne();

            $langs = $this->connection->createQueryBuilder()
                ->select('l.id_lang', 'l.iso_code')
                ->from($this->langTable, 'l')
                ->where('l.active = 1')
                ->orderBy('l.id_lang', 'ASC')
                ->execute()
                ->fetchAllAssociative();

            $langsCount = count($langs);

            // If no images or no active language, consider the status "complete" (nothing to fix).
            if ($totalImages === 0 || $langsCount === 0) {
                $languagesOut = [];
                foreach ($langs as $l) {
                    $languagesOut[] = [
                        'id_lang' => (int) $l['id_lang'],
                        'iso_code' => (string) $l['iso_code'],
                        'missing' => 0,
                        'filled' => $totalImages,
                    ];
                }

                return [
                    'total_images' => $totalImages,
                    'active_languages' => $langsCount,
                    'complete_all_languages' => $totalImages,
                    'incomplete_any_language' => 0,
                    'is_fully_complete' => true,
                    'languages' => $languagesOut,
                ];
            }

            // Count images that have a non-empty legend for EVERY active language.
            // Robust against missing rows in image_lang (treated as missing alt).
            $completeAll = (int) $this->connection->executeQuery(
                'SELECT COUNT(*)
                 FROM ' . $this->imageTable . ' i
                 WHERE NOT EXISTS (
                   SELECT 1
                   FROM ' . $this->langTable . ' l
                   WHERE l.active = 1
                     AND NOT EXISTS (
                       SELECT 1
                       FROM ' . $this->imageLangTable . ' il
                       WHERE il.id_image = i.id_image
                         AND il.id_lang = l.id_lang
                         AND il.legend IS NOT NULL
                         AND il.legend <> \'\'
                     )
                 )'
            )->fetchOne();

            $languagesOut = [];
            foreach ($langs as $l) {
                $langId = (int) $l['id_lang'];
                $filled = (int) $this->connection->executeQuery(
                    'SELECT COUNT(DISTINCT il.id_image)
                     FROM ' . $this->imageLangTable . ' il
                     WHERE il.id_lang = :lang
                       AND il.legend IS NOT NULL
                       AND il.legend <> \'\'',
                    ['lang' => $langId]
                )->fetchOne();

                $missing = max(0, $totalImages - $filled);

                $languagesOut[] = [
                    'id_lang' => $langId,
                    'iso_code' => (string) $l['iso_code'],
                    'missing' => $missing,
                    'filled' => $filled,
                ];
            }

            $incompleteAny = max(0, $totalImages - $completeAll);

            return [
                'total_images' => $totalImages,
                'active_languages' => $langsCount,
                'complete_all_languages' => $completeAll,
                'incomplete_any_language' => $incompleteAny,
                'is_fully_complete' => $incompleteAny === 0,
                'languages' => $languagesOut,
            ];
        } catch (\Exception $e) {
            return [
                'total_images' => 0,
                'active_languages' => 0,
                'complete_all_languages' => 0,
                'incomplete_any_language' => 0,
                'is_fully_complete' => true,
                'languages' => [],
            ];
        }
    }

    /**
     * Get the active snapshot ID
     */
    private function getActiveSnapshotId(): ?int
    {
        try {
            $result = $this->connection->createQueryBuilder()
                ->select('id_snapshot')
                ->from($this->snapshotsTable)
                ->where('is_active = 1')
                ->execute()
                ->fetchOne();

            return $result ? (int) $result : null;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get the active snapshot data
     */
    public function getActiveSnapshot(): ?array
    {
        try {
            $result = $this->connection->createQueryBuilder()
                ->select('*')
                ->from($this->snapshotsTable)
                ->where('is_active = 1')
                ->execute()
                ->fetchAssociative();

            return $result ?: null;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get snapshot history for chart
     */
    public function getSnapshotHistory(int $limit = 10): array
    {
        try {
            return $this->connection->createQueryBuilder()
                ->select('id_snapshot', 'label', 'avg_score', 'total_issues', 'total_pages', 'date_add')
                ->from($this->snapshotsTable)
                ->orderBy('date_add', 'ASC')
                ->setMaxResults($limit)
                ->execute()
                ->fetchAllAssociative();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get comparison between current and previous snapshot
     */
    public function getSnapshotComparison(): ?array
    {
        try {
            $snapshots = $this->connection->createQueryBuilder()
                ->select('*')
                ->from($this->snapshotsTable)
                ->orderBy('date_add', 'DESC')
                ->setMaxResults(2)
                ->execute()
                ->fetchAllAssociative();

            if (count($snapshots) < 2) {
                return null;
            }

            $current = $snapshots[0];
            $previous = $snapshots[1];

            return [
                'current' => $current,
                'previous' => $previous,
                'score_delta' => round((float) $current['avg_score'] - (float) $previous['avg_score'], 2),
                'issues_delta' => (int) $current['total_issues'] - (int) $previous['total_issues'],
                'trend' => $current['avg_score'] >= $previous['avg_score'] ? 'up' : 'down',
            ];
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get all automated criteria with their current status from scanner results
     */
    public function getAutomatedCriteria(): array
    {
        $issuesByRule = $this->getIssueCountsByRule();
        $criteria = [];

        foreach (self::AUTOMATED_CRITERIA as $wcag => $info) {
            $issueCount = 0;
            $affectedRules = [];

            foreach ($info['scanner_rules'] as $ruleId) {
                if (isset($issuesByRule[$ruleId])) {
                    $issueCount += (int) $issuesByRule[$ruleId]['count'];
                    $affectedRules[$ruleId] = (int) $issuesByRule[$ruleId]['count'];
                }
            }

            $status = 'pending';
            if ($this->hasScans()) {
                $status = $issueCount > 0 ? 'non_compliant' : 'compliant';
            }

            $criteria[$wcag] = array_merge($info, [
                'wcag' => $wcag,
                'type' => 'automated',
                'status' => $status,
                'issue_count' => $issueCount,
                'affected_rules' => $affectedRules,
            ]);
        }

        return $criteria;
    }

    /**
     * Get all manual criteria with their verification status
     */
    public function getManualCriteria(int $shopId = 1): array
    {
        $savedStatuses = $this->connection->createQueryBuilder()
            ->select('wcag_criterion', 'status', 'notes', 'verified_by', 'verified_at', 'date_upd')
            ->from($this->manualCheckTable)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->execute()
            ->fetchAllAssociativeIndexed();

        $criteria = [];

        foreach (self::MANUAL_CRITERIA as $wcag => $info) {
            $saved = $savedStatuses[$wcag] ?? null;

            $criteria[$wcag] = [
                'name' => $this->trans($info['name'], [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
                'description' => $this->trans($info['description'], [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
                'verification_guide' => $this->trans($info['verification_guide'], [], 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
                'wcag' => $wcag,
                'type' => 'manual',
                'status' => $saved['status'] ?? 'pending',
                'notes' => $saved['notes'] ?? '',
                'verified_by' => $saved['verified_by'] ?? null,
                'verified_at' => $saved['verified_at'] ?? null,
                'date_upd' => $saved['date_upd'] ?? null,
            ];
        }

        return $criteria;
    }

    /**
     * Get combined dashboard status (for backward compatibility)
     */
    public function getChecklistStatus(): array
    {
        return array_merge($this->getAutomatedCriteria(), $this->getManualCriteria());
    }

    /**
     * Update manual criterion status
     */
    public function updateManualStatus(
        string $wcagCriterion,
        string $status,
        ?string $notes = null,
        ?int $verifiedBy = null,
        int $shopId = 1
    ): bool {
        $existing = $this->connection->createQueryBuilder()
            ->select('id_manual_check')
            ->from($this->manualCheckTable)
            ->where('wcag_criterion = :criterion')
            ->andWhere('id_shop = :shop')
            ->setParameter('criterion', $wcagCriterion)
            ->setParameter('shop', $shopId)
            ->execute()
            ->fetchOne();

        $now = date('Y-m-d H:i:s');
        $data = [
            'status' => $status,
            'notes' => $notes,
            'date_upd' => $now,
        ];

        // Set verification info when status changes from pending
        if ($status !== 'pending' && $verifiedBy !== null) {
            $data['verified_by'] = $verifiedBy;
            $data['verified_at'] = $now;
        }

        if ($existing) {
            return (bool) $this->connection->update(
                $this->manualCheckTable,
                $data,
                ['wcag_criterion' => $wcagCriterion, 'id_shop' => $shopId]
            );
        }

        $data['wcag_criterion'] = $wcagCriterion;
        $data['id_shop'] = $shopId;
        $data['date_add'] = $now;

        return (bool) $this->connection->insert($this->manualCheckTable, $data);
    }


    /**
     * Calculate overall compliance percentage
     */
    public function getCompliancePercentage(int $shopId = 1): float
    {
        $automated = $this->getAutomatedCriteria();
        $manual = $this->getManualCriteria($shopId);

        $total = 0;
        $compliant = 0;

        foreach ($automated as $wcag => $criterion) {
            $total++;
            if ($criterion['status'] === 'compliant') {
                $compliant++;
            }
        }

        foreach ($manual as $criterion) {
            if ($criterion['status'] === 'not_applicable') {
                continue; // Exclude N/A from calculation
            }
            $total++;
            if ($criterion['status'] === 'compliant') {
                $compliant++;
            }
        }

        return $total > 0 ? round(($compliant / $total) * 100, 1) : 0;
    }

    /**
     * Get compliance breakdown statistics
     */
    public function getComplianceBreakdown(int $shopId = 1): array
    {
        $automated = $this->getAutomatedCriteria();
        $manual = $this->getManualCriteria($shopId);

        $stats = [
            'total' => 0,
            'compliant' => 0,
            'non_compliant' => 0,
            'pending' => 0,
            'not_applicable' => 0,
            'automated_total' => count($automated),
            'automated_compliant' => 0,
            'automated_issues' => 0,
            'manual_total' => count($manual),
            'manual_compliant' => 0,
            'manual_pending' => 0,
        ];

        foreach ($automated as $criterion) {
            $stats['total']++;
            if ($criterion['status'] === 'compliant') {
                $stats['compliant']++;
                $stats['automated_compliant']++;
            } elseif ($criterion['status'] === 'non_compliant') {
                $stats['non_compliant']++;
            } else {
                $stats['pending']++;
            }
            $stats['automated_issues'] += $criterion['issue_count'];
        }

        foreach ($manual as $criterion) {
            $stats['total']++;
            switch ($criterion['status']) {
                case 'compliant':
                    $stats['compliant']++;
                    $stats['manual_compliant']++;
                    break;
                case 'non_compliant':
                    $stats['non_compliant']++;
                    break;
                case 'not_applicable':
                    $stats['not_applicable']++;
                    break;
                default:
                    $stats['pending']++;
                    $stats['manual_pending']++;
            }
        }

        return $stats;
    }

    /**
     * Get issue counts grouped by scanner rule
     */
    private function getIssueCountsByRule(): array
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return [];
            }

            return $this->connection->createQueryBuilder()
                ->select('i.rule_id', 'COUNT(*) as count')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->setParameter('snapshot', $snapshotId)
                ->groupBy('i.rule_id')
                ->execute()
                ->fetchAllAssociativeIndexed();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Check if there are any scans in the active snapshot
     */
    private function hasScans(): bool
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return false;
            }

            $count = $this->connection->createQueryBuilder()
                ->select('COUNT(*)')
                ->from($this->scansTable)
                ->where('id_snapshot = :snapshot')
                ->setParameter('snapshot', $snapshotId)
                ->execute()
                ->fetchOne();

            return (int) $count > 0;
        } catch (\Exception $e) {
            return false;
        }
    }

    /**
     * Public wrapper used by controllers/templates to know if the dashboard
     * should be considered "initialized" (at least one scan exists).
     */
    public function hasScansForDashboard(): bool
    {
        return $this->hasScans();
    }

    /**
     * Get the date of the last scan from active snapshot
     */
    public function getLastScanDate(): ?string
    {
        try {
            $snapshot = $this->getActiveSnapshot();
            return $snapshot['date_add'] ?? null;
        } catch (\Exception $e) {
            return null;
        }
    }

    /**
     * Get issues for a specific WCAG criterion
     */
    public function getIssuesForCriterion(string $wcagCriterion): array
    {
        if (!isset(self::AUTOMATED_CRITERIA[$wcagCriterion])) {
            return [];
        }

        $snapshotId = $this->getActiveSnapshotId();
        if (!$snapshotId) {
            return [];
        }

        $rules = self::AUTOMATED_CRITERIA[$wcagCriterion]['scanner_rules'];

        try {
            return $this->connection->createQueryBuilder()
                ->select('i.*', 's.page_url', 's.page_type')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.rule_id IN (:rules)')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->setParameter('snapshot', $snapshotId)
                ->setParameter('rules', $rules, Connection::PARAM_STR_ARRAY)
                ->orderBy('i.severity', 'ASC')
                ->execute()
                ->fetchAllAssociative();
        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get total issue count from active snapshot
     */
    public function getTotalIssueCount(): int
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return 0;
            }

            $result = $this->connection->createQueryBuilder()
                ->select('COUNT(*)')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->setParameter('snapshot', $snapshotId)
                ->execute()
                ->fetchOne();

            return (int) $result;
        } catch (\Exception $e) {
            return 0;
        }
    }

    public function getImageAltIssueCount(): int
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return 0;
            }

            $result = $this->connection->createQueryBuilder()
                ->select('COUNT(*)')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->andWhere('i.rule_id = :ruleId')
                ->andWhere('i.message NOT LIKE :svgPattern')
                ->setParameter('snapshot', $snapshotId)
                ->setParameter('ruleId', 'image-alt')
                ->setParameter('svgPattern', '%.svg%')
                ->execute()
                ->fetchOne();

            return (int) $result;
        } catch (\Exception $e) {
            return 0;
        }
    }

    /**
     * Get WCAG criterion from rule ID
     */
    public function getWcagFromRule(string $ruleId): ?string
    {
        return self::RULE_TO_WCAG[$ruleId] ?? null;
    }

    /**
     * Get the current auto-fix state
     *
     * @return string 'no_scan' | 'disabled' | 'pending_rescan' | 'active'
     */
    public function getAutoFixState(): string
    {
        // State 0: No scan yet (priority)
        if (!$this->hasScans()) {
            return 'no_scan';
        }

        // Use Configuration class instead of direct DB query
        $autoFixEnabled = (bool) \Configuration::get('WEPRESTA_EAA_AUTO_FIX_ENABLED');

        if (!$autoFixEnabled) {
            return 'disabled';
        }

        $enabledAt = \Configuration::get('WEPRESTA_EAA_AUTO_FIX_ENABLED_AT');
        $lastScanAt = $this->getLastScanDate();

        // If enabled after the last scan, we need to rescan
        if ($enabledAt && $lastScanAt && strtotime($enabledAt) > strtotime($lastScanAt)) {
            return 'pending_rescan';
        }

        return 'active';
    }

    /**
     * Dashboard badge for the compliance score.
     *
     * @return array{text:string,color:string}
     */
    public function getScoreBadge(bool $hasScans, float $score): array
    {
        if (!$hasScans) {
            return ['text' => 'SCAN REQUIRED', 'color' => 'blue'];
        }

        if ($score < 30) {
            return ['text' => 'NEEDS ATTENTION', 'color' => 'red'];
        }
        if ($score < 60) {
            return ['text' => 'MAKING PROGRESS', 'color' => 'orange'];
        }
        if ($score < 90) {
            return ['text' => 'GOOD JOB', 'color' => 'yellow'];
        }
        if ($score >= 100) {
            return ['text' => 'FULLY COMPLIANT 🏆', 'color' => 'green'];
        }

        return ['text' => 'EXCELLENT 🏆', 'color' => 'green'];
    }

    /**
     * Progress bar color for the compliance score.
     */
    public function getProgressBarColor(bool $hasScans, float $score): string
    {
        if (!$hasScans) return '#d1d5db'; // gray
        if ($score < 30) return '#ef4444'; // red
        if ($score < 60) return '#f59e0b'; // orange
        if ($score < 90) return '#eab308'; // yellow
        return '#22c55e'; // green
    }

    /**
     * Compute the "What to do next" cards (always 3, except when fully completed).
     *
     * Each item:
     * - type: string (first_scan, enable_autofix, pending_rescan, issues_left, issues_resolved, fix_images, manual_checks, statement, export)
     * - icon: string (emoji)
     * - title/subtitle/description/button: strings (translated in Twig)
     * - color: string (blue|orange|red|purple|green)
     * - href: optional string
     * - button_id: optional string (for JS-driven actions)
     * - disabled: optional bool
     */
    public function getNextActions(int $shopId = 1): array
    {
        $hasScans = $this->hasScans();
        $issuesCount = $this->getTotalIssueCount();
        $imagesWithoutAlt = $this->getImageAltIssueCount();

        $manualCriteria = $this->getManualCriteria($shopId);
        $manualPending = 0;
        foreach ($manualCriteria as $criterion) {
            if (($criterion['status'] ?? 'pending') === 'pending') {
                $manualPending++;
            }
        }

        $statementPublished = false; // Not implemented yet in this module

        $autoFixEnabled = (bool) \Configuration::get('WEPRESTA_EAA_AUTO_FIX_ENABLED');
        $autoFixState = $this->getAutoFixState();

        $actions = [];

        // Card 1 is ALWAYS issues/scans related
        if (!$hasScans) {
            $actions[] = [
                'type' => 'first_scan',
                'icon' => '🔍',
                'title' => 'Run Your First Scan',
                'subtitle' => null,
                'description' => 'Analyze your store to detect accessibility issues',
                'button' => 'Start Scan',
                'color' => 'blue',
                'button_id' => 'btnStartFirstScan',
            ];
        } elseif ($issuesCount > 0 && !$autoFixEnabled) {
            $actions[] = [
                'type' => 'enable_autofix',
                'icon' => '⚡',
                'title' => 'Enable Auto-Fix',
                'subtitle' => '%count% issues detected',
                'subtitle_params' => ['%count%' => $issuesCount],
                'description' => 'Resolve ~90% instantly',
                'button' => 'Enable',
                'color' => 'orange',
                'button_id' => 'btnEnableAutoFix',
            ];
        } elseif ($autoFixState === 'pending_rescan') {
            $actions[] = [
                'type' => 'pending_rescan',
                'icon' => '🔄',
                'title' => 'Run New Scan',
                'subtitle' => 'Auto-fix enabled!',
                'description' => 'Scan to see updated results',
                'button' => 'Scan Now',
                'color' => 'orange',
                'button_id' => 'btnCardRescan',
            ];
        } elseif ($issuesCount > 0) {
            $actions[] = [
                'type' => 'issues_left',
                'icon' => '🔧',
                'title' => '%count% Issues Left',
                'title_params' => ['%count%' => $issuesCount],
                'subtitle' => null,
                'description' => 'Remaining issues need manual fixes',
                'button' => 'View Issues',
                'color' => 'red',
                'href' => null, // resolved in Twig via route
            ];
        } else {
            $actions[] = [
                'type' => 'issues_resolved',
                'icon' => '✅',
                'title' => '0 Issues',
                'subtitle' => 'All fixed!',
                'description' => $autoFixEnabled ? 'Auto-fix is keeping you safe' : 'Great job!',
                'button' => 'View Details',
                'color' => 'green',
                'href' => null, // resolved in Twig
            ];
        }

        // Other priority cards
        if ($hasScans && $imagesWithoutAlt > 0) {
            $actions[] = [
                'type' => 'fix_images',
                'icon' => '🖼️',
                'title' => 'Fix %count% Images',
                'title_params' => ['%count%' => $imagesWithoutAlt],
                'subtitle' => null,
                'description' => 'Add missing alt text descriptions',
                'button' => 'Open Editor',
                'color' => 'red',
                'href' => null, // resolved in Twig
            ];
        }

        if ($manualPending > 0) {
            $actions[] = [
                'type' => 'manual_checks',
                'icon' => '✋',
                'title' => '%count% Manual Checks',
                'title_params' => ['%count%' => $manualPending],
                'subtitle' => null,
                'description' => 'Criteria requiring human verification',
                'button' => 'Start Checking',
                'color' => 'blue',
                'href' => null, // resolved in Twig
            ];
        }



        return array_slice($actions, 0, 3);
    }

    /**
     * Estimated effort in hours (rounded to 1 decimal).
     * Returns null if it should not be displayed yet (no scans).
     */
    public function getEstimatedHours(int $shopId = 1): ?float
    {
        if (!$this->hasScans()) {
            return null;
        }

        $issuesCount = $this->getTotalIssueCount();

        $manualCriteria = $this->getManualCriteria($shopId);
        $manualPending = 0;
        foreach ($manualCriteria as $criterion) {
            if (($criterion['status'] ?? 'pending') === 'pending') {
                $manualPending++;
            }
        }

        $statementPublished = false; // Not implemented

        $totalMinutes = 0;
        $totalMinutes += $issuesCount * 2; // 2 min per remaining issue
        $totalMinutes += $manualPending * 10; // 10 min per manual check
        if (!$statementPublished) {
            $totalMinutes += 15;
        }

        return round($totalMinutes / 60, 1);
    }

    /**
     * Get auto-fix data for dashboard
     */
    public function getAutoFixData(): array
    {
        $autoFixEnabled = (bool) \Configuration::get('WEPRESTA_EAA_AUTO_FIX_ENABLED');
        $enabledAt = \Configuration::get('WEPRESTA_EAA_AUTO_FIX_ENABLED_AT');

        return [
            'enabled' => $autoFixEnabled,
            'state' => $this->getAutoFixState(),
            'enabled_at' => $enabledAt,
        ];
    }

    /**
     * Get all automated criteria definitions
     */
    public function getAutomatedCriteriaDefinitions(): array
    {
        return self::AUTOMATED_CRITERIA;
    }

    /**
     * Get all manual criteria definitions
     */
    public function getManualCriteriaDefinitions(): array
    {
        return self::MANUAL_CRITERIA;
    }

    /**
     * Get Top 3 Priority Actions based on issue count and severity
     * 
     * Priority is calculated by: count * severity_weight
     * Weights: critical=4, serious=3, moderate=2, minor=1
     */
    public function getTopPriorityActions(int $limit = 3): array
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return [];
            }

            // Get issues grouped by rule_id and severity
            $issues = $this->connection->createQueryBuilder()
                ->select('i.rule_id', 'i.severity', 'COUNT(*) as count')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->setParameter('snapshot', $snapshotId)
                ->groupBy('i.rule_id, i.severity')
                ->execute()
                ->fetchAllAssociative();

            if (empty($issues)) {
                return [];
            }

            // Severity weights for priority calculation
            $severityWeights = [
                'critical' => 4,
                'serious' => 3,
                'moderate' => 2,
                'minor' => 1,
            ];

            // Aggregate by rule_id
            $ruleStats = [];
            foreach ($issues as $issue) {
                $ruleId = $issue['rule_id'];
                $severity = $issue['severity'];
                $count = (int) $issue['count'];

                if (!isset($ruleStats[$ruleId])) {
                    $ruleStats[$ruleId] = [
                        'rule_id' => $ruleId,
                        'count' => 0,
                        'weighted_score' => 0,
                        'top_severity' => 'minor',
                    ];
                }

                $ruleStats[$ruleId]['count'] += $count;
                $ruleStats[$ruleId]['weighted_score'] += $count * ($severityWeights[$severity] ?? 1);

                // Keep track of the most severe issue type
                $currentWeight = $severityWeights[$ruleStats[$ruleId]['top_severity']] ?? 1;
                $newWeight = $severityWeights[$severity] ?? 1;
                if ($newWeight > $currentWeight) {
                    $ruleStats[$ruleId]['top_severity'] = $severity;
                }
            }

            // Sort by weighted score (descending)
            usort($ruleStats, fn($a, $b) => $b['weighted_score'] <=> $a['weighted_score']);

            // Take top N and enrich with metadata
            $topActions = [];
            $ruleDescriptions = [
                'image-alt' => 'Images without alternative text',
                'label' => 'Form fields without labels',
                'color-contrast' => 'Insufficient color contrast',
                'meta-viewport' => 'Viewport issues preventing zoom',
                'tabindex' => 'Incorrect keyboard navigation order',
                'document-title' => 'Missing or empty page title',
                'link-name' => 'Links with unclear purpose',
                'html-has-lang' => 'Missing language attribute',
                'html-lang-valid' => 'Invalid language code',
                'duplicate-id' => 'Duplicate element IDs',
                'duplicate-id-active' => 'Duplicate IDs on interactive elements',
                'duplicate-id-aria' => 'Duplicate ARIA IDs',
                'button-name' => 'Buttons without accessible names',
                'aria-valid-attr' => 'Invalid ARIA attributes',
                'aria-valid-attr-value' => 'Invalid ARIA attribute values',
                'input-button-name' => 'Input buttons without names',
                'skip-link' => 'Missing skip navigation link',
                'bypass' => 'No way to skip repetitive content',
                'page-has-heading-one' => 'Page missing main heading (h1)',
                'focus-order-semantics' => 'Focus order issues',
            ];

            foreach (array_slice($ruleStats, 0, $limit) as $rule) {
                $ruleId = $rule['rule_id'];
                $wcag = $this->getWcagFromRule($ruleId);

                $topActions[] = [
                    'rule_id' => $ruleId,
                    'wcag' => $wcag,
                    'count' => $rule['count'],
                    'severity' => $rule['top_severity'],
                    'description' => $ruleDescriptions[$ruleId] ?? 'Accessibility issue: ' . $ruleId,
                    'weighted_score' => $rule['weighted_score'],
                    'action_type' => $ruleId === 'image-alt' ? 'alt_editor' : 'view_issues',
                ];
            }

            return $topActions;

        } catch (\Exception $e) {
            return [];
        }
    }

    /**
     * Get score delta from previous snapshot
     */
    public function getScoreDelta(): ?array
    {
        $comparison = $this->getSnapshotComparison();
        if (!$comparison) {
            return null;
        }

        return [
            'current' => round((float) $comparison['current']['avg_score'], 1),
            'previous' => round((float) $comparison['previous']['avg_score'], 1),
            'delta' => round($comparison['score_delta'], 1),
            'previous_date' => $comparison['previous']['date_add'],
            'trend' => $comparison['trend'],
        ];
    }

    /**
     * Get Road to Compliance data
     * Returns issues by severity, manual checks pending, and estimated effort
     */
    public function getRoadToComplianceData(int $shopId = 1): array
    {
        $issuesBySeverity = $this->getIssuesBySeverity();
        $manualCriteria = $this->getManualCriteria($shopId);

        // Count pending manual checks
        $manualPending = 0;
        foreach ($manualCriteria as $criterion) {
            if ($criterion['status'] === 'pending') {
                $manualPending++;
            }
        }

        // Calculate total issues
        $totalIssues = array_sum(array_column($issuesBySeverity, 'count'));

        // Estimate effort in minutes
        // Issues: 2 minutes per issue
        // Manual checks: 10 minutes per criterion
        // Statement: 30 minutes
        $effortMinutes = ($totalIssues * 2) + ($manualPending * 10) + 30;
        $effortHours = ceil($effortMinutes / 60);

        // Cap at 20+ hours
        $effortDisplay = $effortHours > 20 ? '20+' : (string) $effortHours;

        return [
            'issues_total' => $totalIssues,
            'issues_by_severity' => $issuesBySeverity,
            'manual_pending' => $manualPending,
            'manual_total' => count($manualCriteria),
            'statement_status' => 'not_published', // TODO: Implement statement tracking
            'statement_date' => null,
            'effort_hours' => $effortDisplay,
            'effort_minutes' => $effortMinutes,
        ];
    }

    /**
     * Get issues count grouped by severity from active snapshot
     */
    public function getIssuesBySeverity(): array
    {
        try {
            $snapshotId = $this->getActiveSnapshotId();
            if (!$snapshotId) {
                return [
                    ['severity' => 'critical', 'count' => 0],
                    ['severity' => 'serious', 'count' => 0],
                    ['severity' => 'moderate', 'count' => 0],
                    ['severity' => 'minor', 'count' => 0],
                ];
            }

            $results = $this->connection->createQueryBuilder()
                ->select('i.severity', 'COUNT(*) as count')
                ->from($this->issuesTable, 'i')
                ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
                ->where('s.id_snapshot = :snapshot')
                ->andWhere('i.fixed = 0')
                ->andWhere('i.ignored = 0')
                ->setParameter('snapshot', $snapshotId)
                ->groupBy('i.severity')
                ->execute()
                ->fetchAllAssociative();

            // Ensure all severities are present
            $severities = [
                'critical' => 0,
                'serious' => 0,
                'moderate' => 0,
                'minor' => 0,
            ];

            foreach ($results as $row) {
                $severity = strtolower($row['severity']);
                if (isset($severities[$severity])) {
                    $severities[$severity] = (int) $row['count'];
                }
            }

            // Convert to array format
            $output = [];
            foreach ($severities as $severity => $count) {
                $output[] = [
                    'severity' => $severity,
                    'count' => $count,
                ];
            }

            return $output;

        } catch (\Exception $e) {
            return [
                ['severity' => 'critical', 'count' => 0],
                ['severity' => 'serious', 'count' => 0],
                ['severity' => 'moderate', 'count' => 0],
                ['severity' => 'minor', 'count' => 0],
            ];
        }
    }

    /**
     * Reset all module data (snapshots, scans, issues, manual criteria)
     * Uses TRUNCATE for speed and disables FK checks to avoid constraint issues
     */
    public function resetAllData(int $shopId = 1): bool
    {
        // Disable foreign key checks to allow truncating in any order
        $this->connection->exec('SET FOREIGN_KEY_CHECKS = 0');

        try {
            // Truncate issues table
            $this->truncateTableIfExists($this->issuesTable);
            
            // Truncate scans table
            $this->truncateTableIfExists($this->scansTable);

            // Truncate snapshots table
            $this->truncateTableIfExists($this->snapshotsTable);

            // Delete manual checks for this shop only
            $this->deleteFromTableIfExists($this->manualCheckTable, 'id_shop = :shop', ['shop' => $shopId]);

            return true;
        } finally {
            // Always re-enable foreign key checks
            $this->connection->exec('SET FOREIGN_KEY_CHECKS = 1');
        }
    }

    /**
     * Truncate table only if it exists
     */
    private function truncateTableIfExists(string $tableName): void
    {
        try {
            $this->connection->exec('TRUNCATE TABLE ' . $tableName);
        } catch (\Exception $e) {
            // Table doesn't exist, ignore
        }
    }

    /**
     * Delete from table only if it exists
     */
    private function deleteFromTableIfExists(string $tableName, string $where, array $params = []): void
    {
        try {
            $sql = 'DELETE FROM ' . $tableName . ' WHERE ' . $where;
            foreach ($params as $key => $value) {
                $sql = str_replace(':' . $key, $this->connection->quote((string) $value), $sql);
            }
            $this->connection->exec($sql);
        } catch (\Exception $e) {
            // Table doesn't exist, ignore
        }
    }
}
