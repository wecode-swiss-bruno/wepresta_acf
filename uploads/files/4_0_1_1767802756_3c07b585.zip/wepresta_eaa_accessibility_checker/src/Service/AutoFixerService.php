<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Service;

if (!defined('_PS_VERSION_')) {
    exit;
}

class AutoFixerService
{
    public function getSkipLinkHtml(): string
    {
        return '<a href="#main" class="wepresta-eaa-skip-link" accesskey="s">Aller au contenu principal</a>';
    }

    public function getFixesCss(): string
    {
        return <<<'CSS'
/* Skip link */
.wepresta-eaa-skip-link {
    position: absolute;
    top: -100px;
    left: 50%;
    transform: translateX(-50%);
    background: #005fcc;
    color: #fff;
    padding: 12px 24px;
    text-decoration: none;
    font-weight: 600;
    z-index: 100000;
    border-radius: 0 0 8px 8px;
    transition: top 0.2s ease;
}

.wepresta-eaa-skip-link:focus {
    top: 0;
    outline: 3px solid #ffd700;
    outline-offset: 2px;
}

/* Enhanced focus visibility */
*:focus-visible {
    outline: 3px solid #005fcc !important;
    outline-offset: 2px !important;
}

/* Ensure minimum touch target size (44x44px per WCAG 2.5.5) */
button, 
a, 
input[type="button"], 
input[type="submit"],
[role="button"] {
    min-height: 44px;
    min-width: 44px;
}

/* Reduce motion for users who prefer it */
@media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
        animation-duration: 0.01ms !important;
        animation-iteration-count: 1 !important;
        transition-duration: 0.01ms !important;
        scroll-behavior: auto !important;
    }
}
CSS;
    }
    public function getAriaEnhancements(): array
    {
        return [
            'nav' => ['role' => 'navigation', 'aria-label' => 'Navigation principale'],
            'main' => ['role' => 'main'],
            'aside' => ['role' => 'complementary'],
            'footer' => ['role' => 'contentinfo'],
            'header' => ['role' => 'banner'],
        ];
    }

    /**
     * Get list of known decorative image patterns
     * These should be marked with aria-hidden and empty alt
     */
    public function getDecorativeImagePatterns(): array
    {
        return [
            // blockreassurance module
            'blockreassurance' => [
                'selector' => '#block-reassurance img, .blockreassurance img, #block-reassurance svg, .blockreassurance svg',
                'description' => 'Icônes de réassurance (livraison, sécurité, etc.)',
                'module' => 'blockreassurance',
            ],
            // Social sharing icons
            'social' => [
                'selector' => '.social-sharing img, .ps-socialfollow img',
                'description' => 'Icônes de réseaux sociaux',
                'module' => 'ps_socialfollow',
            ],
            // Payment icons when label exists
            'payment' => [
                'selector' => '.payment-option img',
                'description' => 'Logos de moyens de paiement',
                'module' => 'ps_checkout',
            ],
            // Search icon
            'search' => [
                'selector' => '.search-widget img, .search-widget svg, #search_widget img',
                'description' => 'Icône de recherche',
                'module' => 'ps_searchbar',
            ],
        ];
    }

    /**
     * Get JavaScript to auto-fix accessibility issues on common PrestaShop modules
     */
    public function getModuleFixesJs(): string
    {
        return <<<'JS'
(function() {
    'use strict';

    // Wait for DOM ready AND jQuery ready (for blockreassurance compatibility)
    function initAccessibilityFixes() {
        fixDecorativeImages();
        fixBlockReassurance();
        fixSocialLinks();
        fixSearchForm();
        fixNewsletterForm();
        fixButtonsWithoutNames();
    }

    // executeQuery after DOMContentLoaded with multiple attempts for dynamic content
    document.addEventListener('DOMContentLoaded', function() {
        // Check if jQuery is available and if blockreassurance has already run
        if (typeof $ !== 'undefined') {
            // If jQuery ready has already fired, run immediately
            if ($.isReady) {
                setTimeout(initAccessibilityFixes, 100); // Small delay to ensure blockreassurance is done
                // Run again after more time for dynamic content
                setTimeout(initAccessibilityFixes, 1000);
                setTimeout(initAccessibilityFixes, 3000);
            } else {
                // Wait for jQuery ready
                $(document).ready(function() {
                    setTimeout(initAccessibilityFixes, 100); // Small delay after blockreassurance
                    // Run again after more time for dynamic content
                    setTimeout(initAccessibilityFixes, 1000);
                    setTimeout(initAccessibilityFixes, 3000);
                });
            }
        } else {
            // Fallback without jQuery
            initAccessibilityFixes();
            setTimeout(initAccessibilityFixes, 1000);
            setTimeout(initAccessibilityFixes, 3000);
        }
    });

    // Also run when page becomes visible (for SPA-like behavior)
    document.addEventListener('visibilitychange', function() {
        if (!document.hidden) {
            setTimeout(initAccessibilityFixes, 500);
        }
    });

    // Watch for dynamically added forms (AJAX content, modals, etc.)
    if (typeof MutationObserver !== 'undefined') {

        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    // Check if new form elements were added
                    var hasNewForms = false;
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) { // Element node
                            if (node.tagName === 'FORM' || node.querySelector('form')) {
                                hasNewForms = true;
                            }
                        }
                    });
                    if (hasNewForms) {
                        setTimeout(fixAllForms, 100);
                    }
                }
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });

    }

    // Also run after dynamic content loads (for any SVGs)
    if (typeof MutationObserver !== 'undefined') {
        var observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    // Check if new SVG elements were added
                    var hasNewSvg = false;
                    mutation.addedNodes.forEach(function(node) {
                        if (node.nodeType === 1) { // Element node
                            if (node.tagName === 'svg' || node.querySelector('svg')) {
                                hasNewSvg = true;
                            }
                        }
                    });
                    if (hasNewSvg) {
                        setTimeout(fixDecorativeImages, 10);
                    }
                }
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });

        // Fallback: Check periodically for SVGs that need fixing (in case MutationObserver misses them)
        var checkInterval = setInterval(function() {
            var allSvgs = document.querySelectorAll('svg');
            var needsFix = false;
            allSvgs.forEach(function(svg) {
                if (!svg.hasAttribute('aria-hidden') && !svg.hasAttribute('aria-label') && !svg.hasAttribute('aria-labelledby')) {
                    if (isLikelyDecorative(svg)) {
                        needsFix = true;
                    }
                }
            });
            if (needsFix) {
                fixDecorativeImages();
            }

            // Stop checking after 5 seconds
            if (performance.now() > 5000) {
                clearInterval(checkInterval);
            }
        }, 200);
    }

    /**
     * Fix decorative images from all modules
     * Uses heuristics to determine if SVGs are decorative
     */
    function fixDecorativeImages() {
        // Find all SVGs that might be decorative
        var allSvgs = document.querySelectorAll('svg');

        allSvgs.forEach(function(svg) {
            // Skip if already has accessibility attributes
            if (svg.hasAttribute('aria-hidden') || svg.hasAttribute('aria-label') || svg.hasAttribute('aria-labelledby')) {
                return;
            }

            // Heuristics to determine if SVG is decorative
            if (isLikelyDecorative(svg)) {
                svg.setAttribute('aria-hidden', 'true');
                svg.setAttribute('role', 'presentation');
                svg.setAttribute('focusable', 'false');
            }
        });

        // Also handle decorative images (legacy support)
        fixDecorativeImagesLegacy();
    }

    /**
     * Determine if an SVG is likely decorative based on context and heuristics
     */
    function isLikelyDecorative(svg) {
        // 1. SVG in known decorative contexts
        var decorativeContexts = [
            '.blockreassurance', '.blockreassurance_product', '#block-reassurance',
            '.social-sharing', '.ps-socialfollow',
            '.payment-option', '.carrier-logo', '.delivery-option',
            'button', '.btn', '[role="button"]',
            '.icon', '.decoration', '.decorative',
            'nav', '.navigation', '.menu',
            '.header', '.footer',
            '.breadcrumb', '.search', '.cart',
            '.wishlist', '.compare'
        ];

        for (var i = 0; i < decorativeContexts.length; i++) {
            var context = decorativeContexts[i];
            if (svg.closest(context)) {
                return true;
            }
        }

        // 2. SVG with decorative class names
        var decorativeClasses = ['icon', 'decoration', 'decorative', 'glyph', 'symbol', 'arrow', 'chevron'];
        for (var className of svg.classList) {
            if (decorativeClasses.some(function(dc) { return className.includes(dc); })) {
                return true;
            }
        }

        // 3. SVG in buttons/links without aria-label
        var interactiveParent = svg.closest('button, [role="button"], a, [role="link"]');
        if (interactiveParent) {
            // If parent has text or aria-label, SVG is decorative
            var hasText = interactiveParent.textContent.trim().length > 0;
            var hasAriaLabel = interactiveParent.hasAttribute('aria-label') || interactiveParent.hasAttribute('aria-labelledby');
            var hasTitle = interactiveParent.hasAttribute('title');

            if (hasText || hasAriaLabel || hasTitle) {
                return true;
            }

            // If SVG is the only content and parent has no accessible name, might be informative
            var otherContent = Array.from(interactiveParent.childNodes).filter(function(node) {
                return node !== svg &&
                    ((node.nodeType === 3 && node.textContent.trim()) || // Text nodes
                     (node.nodeType === 1 && node.tagName !== 'svg')); // Other elements
            });

            if (otherContent.length === 0) {
                // SVG is the only content - check if parent has accessible name
                if (!hasAriaLabel && !hasTitle) {
                    return false; // Might be informative, skip
                }
            }
        }

        // 4. Small SVGs (likely icons) - max 64px to be safe
        var rect = svg.getBoundingClientRect();
        if (rect.width > 0 && rect.height > 0 && rect.width <= 64 && rect.height <= 64) {
            return true;
        }

        // 5. SVG without meaningful semantic content
        var hasTitle = svg.querySelector('title');
        var hasDesc = svg.querySelector('desc');
        var hasText = svg.querySelector('text');

        if (!hasTitle && !hasDesc && !hasText) {
            // Check if replacing an img with alt text
            var img = svg.closest('img');
            if (img && img.hasAttribute('alt') && img.getAttribute('alt').trim()) {
                return true; // SVG replaces img with alt text
            }

            // Check if parent provides context
            var parent = svg.parentElement;
            if (parent && (parent.hasAttribute('aria-label') || parent.hasAttribute('aria-labelledby'))) {
                return true; // Parent provides context
            }

            // Assume decorative if no semantic content and small size
            if (rect.width <= 48 && rect.height <= 48) {
                return true;
            }
        }

        // Default: not decorative to be safe
        return false;
    }

    /**
     * Legacy support for decorative images (non-SVG)
     */
    function fixDecorativeImagesLegacy() {
        // Handle decorative images that might be replaced by SVGs
        var decorativeSelectors = [
            '.blockreassurance img.svg',
            '.blockreassurance_product img.svg',
            '.social-sharing img',
            '.ps-socialfollow img'
        ];

        decorativeSelectors.forEach(function(selector) {
            document.querySelectorAll(selector).forEach(function(img) {
                if (!img.hasAttribute('alt')) {
                    img.setAttribute('alt', '');
                }
                if (!img.hasAttribute('aria-hidden')) {
                    img.setAttribute('aria-hidden', 'true');
                }
            });
        });

        // Payment and carrier icons when they have text labels
        document.querySelectorAll('.payment-option img').forEach(function(img) {
            var label = img.closest('label');
            if (label && label.textContent.trim().length > 0 && !img.hasAttribute('alt')) {
                img.setAttribute('alt', '');
            }
        });

        document.querySelectorAll('.carrier-logo img, .delivery-option img').forEach(function(img) {
            var container = img.closest('.carrier-name, .delivery-option');
            if (container && container.textContent.trim().length > 0 && !img.hasAttribute('alt')) {
                img.setAttribute('alt', '');
            }
        });
    }

    /**
     * Fix blockreassurance module accessibility
     */
    function fixBlockReassurance() {
        var block = document.querySelector('#block-reassurance, .blockreassurance, .blockreassurance_product');
        if (!block) return;

        // Add appropriate ARIA role
        if (!block.hasAttribute('role')) {
            block.setAttribute('role', 'complementary');
            block.setAttribute('aria-label', 'Guarantees and reassurance');
        }

        // Ensure each reassurance item has proper structure
        block.querySelectorAll('.block-reassurance-item, li').forEach(function(item, index) {
            // The text content is the important part, icons are decorative
            var textEl = item.querySelector('span, p, .block-reassurance-text');
            if (textEl && !item.hasAttribute('aria-label')) {
                // Text is already readable, just ensure icons are hidden
                item.querySelectorAll('svg, img').forEach(function(icon) {
                    icon.setAttribute('aria-hidden', 'true');
                });
            }
        });
    }

    /**
     * Fix social links accessibility
     */
    function fixSocialLinks() {
        document.querySelectorAll('.social-sharing a, .ps-socialfollow a, [class*="social"] a').forEach(function(link) {
            // If link only contains an image/icon, add aria-label
            var hasText = link.textContent.trim().length > 0;
            var img = link.querySelector('img, svg, i');

            if (!hasText && img && !link.hasAttribute('aria-label')) {
                // Try to determine social network from class or href
                var href = link.getAttribute('href') || '';
                var className = link.className || '';
                var network = '';

                if (href.includes('facebook') || className.includes('facebook')) network = 'Facebook';
                else if (href.includes('twitter') || className.includes('twitter')) network = 'Twitter';
                else if (href.includes('instagram') || className.includes('instagram')) network = 'Instagram';
                else if (href.includes('youtube') || className.includes('youtube')) network = 'YouTube';
                else if (href.includes('pinterest') || className.includes('pinterest')) network = 'Pinterest';
                else if (href.includes('linkedin') || className.includes('linkedin')) network = 'LinkedIn';
                else if (href.includes('tiktok') || className.includes('tiktok')) network = 'TikTok';

                if (network) {
                    link.setAttribute('aria-label', 'Suivez-nous sur ' + network);
                    link.setAttribute('title', 'Suivez-nous sur ' + network);
                }
            }

            // Ensure external links open in new tab with proper attributes
            if (link.getAttribute('target') === '_blank') {
                if (!link.getAttribute('rel') || !link.getAttribute('rel').includes('noopener')) {
                    link.setAttribute('rel', 'noopener noreferrer');
                }
            }
        });
    }

    /**
     * Fix search form accessibility
     */
    function fixSearchForm() {
        document.querySelectorAll('form[action*="search"], .search-widget form, #search_widget form').forEach(function(form) {
            if (!form.hasAttribute('role')) {
                form.setAttribute('role', 'search');
            }

            var input = form.querySelector('input[type="text"], input[type="search"]');
            var button = form.querySelector('button, input[type="submit"]');

            if (input) {
                if (!input.hasAttribute('aria-label') && !input.id) {
                    input.setAttribute('aria-label', 'Rechercher');
                }
            }

            if (button) {
                if (!button.hasAttribute('aria-label') && !button.textContent.trim()) {
                    button.setAttribute('aria-label', 'Launch search');
                }
            }
        });
    }

    /**
     * Fix newsletter form accessibility
     */
    function fixNewsletterForm() {
        document.querySelectorAll('.block_newsletter form, .ps-emailsubscription form, [class*="newsletter"] form').forEach(function(form) {
            var input = form.querySelector('input[type="email"], input[type="text"]');
            var button = form.querySelector('button, input[type="submit"]');

            if (input) {
                if (!input.hasAttribute('aria-label') && !document.querySelector('label[for="' + input.id + '"]')) {
                    input.setAttribute('aria-label', 'Your email address');
                }
            }

            if (button) {
                if (!button.hasAttribute('aria-label') && !button.textContent.trim()) {
                    button.setAttribute('aria-label', 'Subscribe to newsletter');
                }
            }
        });
    }

    /**
     * Fix buttons without accessible names
     */
    function fixButtonsWithoutNames() {
        // Fix btn-close buttons
        document.querySelectorAll('button.btn-close').forEach(function(button) {
            if (button.hasAttribute('aria-label')) {
                return;
            }

            var ariaLabel = 'Close';
            if (button.closest('.toast')) {
                ariaLabel = 'Close notification';
            } else if (button.closest('.modal')) {
                ariaLabel = 'Close window';
            } else if (button.closest('.alert, [role="alert"]')) {
                ariaLabel = 'Close message';
            } else if (button.closest('.offcanvas')) {
                ariaLabel = 'Close menu';
            }

            button.setAttribute('aria-label', ariaLabel);
        });

        // Fix Bootstrap dismiss buttons (data-bs-dismiss, data-dismiss)
        document.querySelectorAll('button[data-bs-dismiss], button[data-dismiss]').forEach(function(button) {
            if (button.hasAttribute('aria-label') || button.textContent.trim()) {
                return;
            }

            var dismissType = button.getAttribute('data-bs-dismiss') || button.getAttribute('data-dismiss');
            var ariaLabel = 'Close';

            switch (dismissType) {
                case 'toast':
                    ariaLabel = 'Close notification';
                    break;
                case 'modal':
                    ariaLabel = 'Close window';
                    break;
                case 'alert':
                    ariaLabel = 'Close message';
                    break;
                case 'offcanvas':
                    ariaLabel = 'Close menu';
                    break;
            }

            button.setAttribute('aria-label', ariaLabel);
        });
    }
})();
JS;
    }
}
