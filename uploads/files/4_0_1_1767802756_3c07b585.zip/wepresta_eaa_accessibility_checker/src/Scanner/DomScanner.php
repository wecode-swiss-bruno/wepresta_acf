<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

declare(strict_types=1);

namespace Wepresta\EaaAccessibilityChecker\Scanner;

if (!defined('_PS_VERSION_')) {
    exit;
}

class DomScanner
{
    /**
     * Whether to ignore elements that are auto-fixed by module-fixes.js
     */
    private bool $ignoreAutoFixed = false;

    /**
     * Patterns for elements that are auto-fixed by JavaScript
     * These will be excluded from scan results when auto-fix is enabled
     */
    private const AUTO_FIXED_PATTERNS = [
        // blockreassurance module (decorative SVG icons)
        'images' => [
            'block-reassurance',
            'blockreassurance',
            'social-sharing',
            'ps-socialfollow',
            'payment-option',
            'carrier-logo',
            'delivery-option',
        ],
        // Links fixed with aria-label
        'links' => [
            'social-sharing',
            'ps-socialfollow',
        ],
        // Buttons that are auto-fixed by JavaScript
        'buttons' => [
            'search-widget',
            'search_widget',
        ],
        // Forms with role="search" or newsletter
        'forms' => [
            'search-widget',
            'search_widget',
            'block_newsletter',
            'ps-emailsubscription',
        ],
    ];

    /**
     * Enable or disable auto-fix awareness
     */
    public function setIgnoreAutoFixed(bool $ignore): self
    {
        $this->ignoreAutoFixed = $ignore;
        return $this;
    }

    public function scanHtml(string $html): array
    {
        $dom = new \DOMDocument();
        @$dom->loadHTML($html, LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD);
        $xpath = new \DOMXPath($dom);

        $issues = [];

        $issues = array_merge($issues, $this->checkMissingAltTexts($xpath));
        $issues = array_merge($issues, $this->checkMissingFormLabels($xpath));
        $issues = array_merge($issues, $this->checkMissingLanguage($dom));
        $issues = array_merge($issues, $this->checkEmptyLinks($xpath));
        $issues = array_merge($issues, $this->checkEmptyButtons($xpath));
        $issues = array_merge($issues, $this->checkMissingHeadings($xpath));
        $issues = array_merge($issues, $this->checkSkipLinks($xpath));

        return $issues;
    }

    /**
     * Check if an element is inside an auto-fixed container
     */
    private function isInAutoFixedContainer(\DOMElement $element, string $type): bool
    {
        if (!$this->ignoreAutoFixed) {
            return false;
        }

        $patterns = self::AUTO_FIXED_PATTERNS[$type] ?? [];
        if (empty($patterns)) {
            return false;
        }

        // Walk up the DOM tree looking for matching classes/IDs
        $current = $element;
        while ($current instanceof \DOMElement) {
            $classes = $current->getAttribute('class');
            $id = $current->getAttribute('id');
            
            foreach ($patterns as $pattern) {
                if (stripos($classes, $pattern) !== false || stripos($id, $pattern) !== false) {
                    return true;
                }
            }
            
            $current = $current->parentNode;
        }

        return false;
    }

    private function checkMissingAltTexts(\DOMXPath $xpath): array
    {
        $issues = [];
        $allImages = $xpath->query('//img');

        foreach ($allImages as $img) {
            // Skip images in auto-fixed containers (blockreassurance, social icons, etc.)
            if ($this->isInAutoFixedContainer($img, 'images')) {
                continue;
            }

            $src = $img->getAttribute('src');
            $alt = $img->getAttribute('alt');

            // Vérifier si l'attribut alt est complètement absent (pas juste vide)
            // alt="" est valide pour les images décoratives selon WCAG
            $hasAltAttribute = $img->hasAttribute('alt');
            $altIsMissing = !$hasAltAttribute;

            if ($altIsMissing) {
                $issues[] = [
                    'rule_id' => 'image-alt',
                    'severity' => 'critical',
                    'selector' => $this->buildReadableSelector($img),
                    'context' => $this->getElementContext($img),
                    'html_preview' => $this->getHtmlPreview($img),
                    'location_hint' => $this->getLocationHint($img),
                    'message' => 'Image missing alt text: ' . basename($src),
                ];
            }
        }

        return $issues;
    }

    private function checkMissingFormLabels(\DOMXPath $xpath): array
    {
        $issues = [];
        $inputs = $xpath->query('//input[@type!="hidden" and @type!="submit" and @type!="button" and @type!="image"]');

        foreach ($inputs as $input) {
            // Skip inputs in auto-fixed containers (search, newsletter forms)
            if ($this->isInAutoFixedContainer($input, 'forms')) {
                continue;
            }

            $id = $input->getAttribute('id');
            $name = $input->getAttribute('name');
            $type = $input->getAttribute('type');
            $ariaLabel = $input->getAttribute('aria-label');
            $ariaLabelledby = $input->getAttribute('aria-labelledby');

            // Skip if already has ARIA attributes
            if (!empty($ariaLabel) || !empty($ariaLabelledby)) {
                continue;
            }

            // Check for associated label by ID
            if (!empty($id)) {
                $labels = $xpath->query('//label[@for="' . $id . '"]');
                if ($labels->length > 0) {
                    continue; // Has valid label association
                }
            }

            // ========================================
            // SCALABLE FIX: Check for label by name
            // (JavaScript will add the missing ID)
            // ========================================
            if (!empty($name) && $this->ignoreAutoFixed) {
                // Normalize name for label lookup (e.g., "group[2]" -> "group_2")
                $normalizedName = preg_replace('/\[(\d+)\]/', '_$1', $name);

                // Check if there's a label that references the name directly
                $labelsByName = $xpath->query('//label[@for="' . $name . '"]');
                if ($labelsByName->length > 0) {
                    continue; // JavaScript will add the ID
                }

                // Check for normalized name (for array inputs like group[2])
                if ($normalizedName !== $name) {
                    $labelsByNormalizedName = $xpath->query('//label[@for="' . $normalizedName . '"]');
                    if ($labelsByNormalizedName->length > 0) {
                        continue;
                    }
                }

                // Check if input is inside a label element (implicit association)
                $parentLabel = $xpath->query('ancestor::label', $input);
                if ($parentLabel->length > 0) {
                    continue; // Implicit label association
                }

                // Special handling for honeypot fields (commonly named 'url')
                if ($name === 'url' && $type === 'text') {
                    continue; // Honeypot field - ignore accessibility checks
                }
            }

            // Report the issue
            $issues[] = [
                'rule_id' => 'label',
                'severity' => 'serious',
                'selector' => $this->buildReadableSelector($input),
                'context' => $this->getElementContext($input),
                'html_preview' => $this->getHtmlPreview($input),
                'location_hint' => $this->getLocationHint($input),
                'message' => empty($id) ? 'Form input missing label association' : 'Form input has no associated label',
            ];
        }

        // Also check textareas and selects
        $textareas = $xpath->query('//textarea');
        foreach ($textareas as $textarea) {
            if ($this->isInAutoFixedContainer($textarea, 'forms')) {
                continue;
            }

            $id = $textarea->getAttribute('id');
            $name = $textarea->getAttribute('name');
            $ariaLabel = $textarea->getAttribute('aria-label');

            if (!empty($ariaLabel)) {
                continue;
            }

            // Check by ID
            if (!empty($id)) {
                $labels = $xpath->query('//label[@for="' . $id . '"]');
                if ($labels->length > 0) {
                    continue;
                }
            }

            // Check by name (scalable fix)
            if (!empty($name) && $this->ignoreAutoFixed) {
                $labelsByName = $xpath->query('//label[@for="' . $name . '"]');
                if ($labelsByName->length > 0) {
                    continue;
                }
            }

            // Check if textarea is inside a label element (implicit association)
            $parentLabel = $xpath->query('ancestor::label', $textarea);
            if ($parentLabel->length > 0) {
                continue; // Implicit label association
            }

            $issues[] = [
                'rule_id' => 'label',
                'severity' => 'serious',
                'selector' => $this->buildReadableSelector($textarea),
                'context' => $this->getElementContext($textarea),
                'html_preview' => $this->getHtmlPreview($textarea),
                'location_hint' => $this->getLocationHint($textarea),
                'message' => 'Textarea missing label association',
            ];
        }

        return $issues;
    }

    private function checkMissingLanguage(\DOMDocument $dom): array
    {
        $html = $dom->getElementsByTagName('html')->item(0);
        if (!$html || !$html->hasAttribute('lang')) {
            return [[
                'rule_id' => 'html-has-lang',
                'severity' => 'serious',
                'selector' => $this->buildReadableSelector($html),
                'context' => 'Document root',
                'html_preview' => $this->getHtmlPreview($html),
                'location_hint' => 'html',
                'message' => 'HTML element missing lang attribute',
            ]];
        }
        return [];
    }

    private function checkEmptyLinks(\DOMXPath $xpath): array
    {
        $issues = [];
        $links = $xpath->query('//a[not(normalize-space()) and not(.//img[@alt])]');

        foreach ($links as $link) {
            // Skip links in auto-fixed containers (social sharing, etc.)
            if ($this->isInAutoFixedContainer($link, 'links')) {
                continue;
            }

            $href = $link->getAttribute('href');
            $ariaLabel = $link->getAttribute('aria-label');

            if (empty($ariaLabel)) {
                $issues[] = [
                    'rule_id' => 'link-name',
                    'severity' => 'serious',
                    'selector' => $this->buildReadableSelector($link),
                    'context' => $this->getElementContext($link),
                    'html_preview' => $this->getHtmlPreview($link),
                    'location_hint' => $this->getLocationHint($link),
                    'message' => 'Link has no accessible name',
                ];
            }
        }

        return $issues;
    }

    private function checkEmptyButtons(\DOMXPath $xpath): array
    {
        $issues = [];
        $buttons = $xpath->query('//button[not(normalize-space()) and not(.//img[@alt])]');

        foreach ($buttons as $button) {
            // Skip buttons in auto-fixed containers (search widget, etc.)
            if ($this->isInAutoFixedContainer($button, 'buttons')) {
                continue;
            }

            $ariaLabel = $button->getAttribute('aria-label');
            if (empty($ariaLabel)) {
                // ========================================
                // SCALABLE FIX: Skip buttons that JavaScript will fix
                // ========================================
                if ($this->ignoreAutoFixed) {
                    $classes = $button->getAttribute('class');
                    $dataBsDismiss = $button->getAttribute('data-bs-dismiss');
                    $dataDismiss = $button->getAttribute('data-dismiss');

                    // Skip buttons that JavaScript will automatically fix:
                    // - btn-close buttons
                    // - Bootstrap dismiss buttons (data-bs-dismiss, data-dismiss)
                    if (stripos($classes, 'btn-close') !== false ||
                        !empty($dataBsDismiss) || !empty($dataDismiss)) {
                        continue;
                    }
                }

                $issues[] = [
                    'rule_id' => 'button-name',
                    'severity' => 'serious',
                    'selector' => $this->buildReadableSelector($button),
                    'context' => $this->getElementContext($button),
                    'html_preview' => $this->getHtmlPreview($button),
                    'location_hint' => $this->getLocationHint($button),
                    'message' => 'Button has no accessible name',
                ];
            }
        }

        return $issues;
    }


    private function checkMissingHeadings(\DOMXPath $xpath): array
    {
        $h1s = $xpath->query('//h1');
        if ($h1s->length === 0) {
            return [[
                'rule_id' => 'page-has-heading-one',
                'severity' => 'moderate',
                'selector' => 'body',
                'context' => 'Page structure',
                'html_preview' => '<body>...</body>',
                'location_hint' => 'body',
                'message' => 'Page does not have a level-one heading',
            ]];
        }
        return [];
    }

    private function checkSkipLinks(\DOMXPath $xpath): array
    {
        // Check for skip links (including those added by the module)
        $skipLinks = $xpath->query('//a[contains(@href, "#main") or contains(@href, "#content") or contains(@class, "skip") or contains(@class, "wepresta-eaa-skip-link")]');
        if ($skipLinks->length === 0) {
            return [[
                'rule_id' => 'skip-link',
                'severity' => 'moderate',
                'selector' => 'body',
                'context' => 'Navigation accessibility',
                'html_preview' => '<body>...</body>',
                'location_hint' => 'body',
                'message' => 'Page does not have skip navigation link',
            ]];
        }
        return [];
    }

    private function getElementContext(\DOMElement $element): string
    {
        // Trouver le contexte (titre de section, paragraphe précédent, etc.)
        $context = '';

        // Chercher un heading proche
        $heading = $element->parentNode;
        while ($heading && !preg_match('/^h[1-6]$/', $heading->nodeName)) {
            $heading = $heading->parentNode;
        }

        if ($heading && $heading->textContent) {
            $headingText = trim($heading->textContent);
            if (strlen($headingText) > 50) {
                $headingText = substr($headingText, 0, 47) . '...';
            }
            $context = 'Près du titre : "' . htmlspecialchars($headingText) . '"';
        }

        // Si pas de heading, chercher du texte autour
        if (empty($context)) {
            $previousSibling = $element->previousSibling;
            while ($previousSibling && $previousSibling->nodeType !== XML_TEXT_NODE) {
                $previousSibling = $previousSibling->previousSibling;
            }

            if ($previousSibling && trim($previousSibling->textContent)) {
                $text = trim($previousSibling->textContent);
                if (strlen($text) > 30) {
                    $text = substr($text, -27) . '...';
                }
                $context = 'Après le texte : "' . htmlspecialchars($text) . '"';
            }
        }

        return $context;
    }

    private function buildReadableSelector(\DOMElement $element): string
    {
        // Créer un sélecteur plus lisible
        $tag = $element->nodeName;
        $id = $element->getAttribute('id');
        $classes = $element->getAttribute('class');
        $src = $element->getAttribute('src');
        $name = $element->getAttribute('name');
        $type = $element->getAttribute('type');

        $readable = $tag;

        if ($id) {
            $readable .= '#' . $id;
        }

        if ($classes) {
            $classList = explode(' ', $classes);
            $readable .= '.' . implode('.', array_slice($classList, 0, 2)); // Max 2 classes
        }

        // Ajouter des attributs discriminants
        if ($src && strlen($src) < 50) {
            $readable .= '[src="' . $src . '"]';
        } elseif ($name) {
            $readable .= '[name="' . $name . '"]';
        } elseif ($type) {
            $readable .= '[type="' . $type . '"]';
        }

        return $readable;
    }

    private function getHtmlPreview(\DOMElement $element): string
    {
        // Générer un aperçu du code HTML problématique
        $html = $element->ownerDocument->saveHTML($element);

        // Nettoyer un peu pour la lisibilité
        $html = preg_replace('/\s+/', ' ', $html);
        $html = preg_replace('/> </', '><', $html);

        return htmlspecialchars(trim($html));
    }

    private function getLocationHint(\DOMElement $element): string
    {
        // Donner une indication de position dans la hiérarchie
        $path = [];
        $current = $element;
        $depth = 0;

        while ($current && $depth < 4) {
            $tag = $current->nodeName;

            if ($current->getAttribute('id')) {
                $tag .= '#' . $current->getAttribute('id');
            } elseif ($current->getAttribute('class')) {
                $classes = explode(' ', $current->getAttribute('class'));
                $tag .= '.' . $classes[0];
            }

            array_unshift($path, $tag);
            $current = $current->parentNode;
            $depth++;
        }

        return 'Chemin : ' . implode(' > ', $path);
    }
}

