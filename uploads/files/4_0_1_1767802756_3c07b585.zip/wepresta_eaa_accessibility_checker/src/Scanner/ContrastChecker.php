<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Scanner;

if (!defined('_PS_VERSION_')) {
    exit;
}

class ContrastChecker
{
    private const WCAG_AA_NORMAL = 4.5;
    private const WCAG_AA_LARGE = 3.0;

    public function checkContrast(string $foreground, string $background): array
    {
        $fgLum = $this->getRelativeLuminance($foreground);
        $bgLum = $this->getRelativeLuminance($background);

        $ratio = $this->getContrastRatio($fgLum, $bgLum);

        return [
            'ratio' => round($ratio, 2),
            'passes_normal' => $ratio >= self::WCAG_AA_NORMAL,
            'passes_large' => $ratio >= self::WCAG_AA_LARGE,
        ];
    }

    private function getContrastRatio(float $l1, float $l2): float
    {
        $lighter = max($l1, $l2);
        $darker = min($l1, $l2);

        return ($lighter + 0.05) / ($darker + 0.05);
    }

    private function getRelativeLuminance(string $hexColor): float
    {
        $rgb = $this->hexToRgb($hexColor);

        $r = $this->adjustGamma($rgb['r'] / 255);
        $g = $this->adjustGamma($rgb['g'] / 255);
        $b = $this->adjustGamma($rgb['b'] / 255);

        return 0.2126 * $r + 0.7152 * $g + 0.0722 * $b;
    }

    private function adjustGamma(float $value): float
    {
        return $value <= 0.03928
            ? $value / 12.92
            : pow(($value + 0.055) / 1.055, 2.4);
    }

    private function hexToRgb(string $hex): array
    {
        $hex = ltrim($hex, '#');

        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }

        return [
            'r' => hexdec(substr($hex, 0, 2)),
            'g' => hexdec(substr($hex, 2, 2)),
            'b' => hexdec(substr($hex, 4, 2)),
        ];
    }

    public function suggestAccessibleColor(string $background, string $currentForeground): string
    {
        $result = $this->checkContrast($currentForeground, $background);

        if ($result['passes_normal']) {
            return $currentForeground;
        }

        $bgLum = $this->getRelativeLuminance($background);

        // If background is dark, suggest white; if light, suggest black
        if ($bgLum < 0.5) {
            return '#FFFFFF';
        }

        return '#000000';
    }
}
