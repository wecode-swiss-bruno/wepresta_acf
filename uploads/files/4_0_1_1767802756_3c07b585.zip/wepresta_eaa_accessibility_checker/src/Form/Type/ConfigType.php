<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Form\Type;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\FormBuilderInterface;

class ConfigType extends TranslatorAwareType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('auto_fix_enabled', SwitchType::class, [
                'label' => $this->trans('Enable automatic accessibility fixes', 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
                'help' => $this->trans('Automatically fixes common accessibility issues on your store: skip links for keyboard navigation, decorative images from modules (blockreassurance, social sharing), buttons without accessible names, search forms, newsletter forms, and more. These fixes are applied via JavaScript and HTML when the page loads. When enabled, the scanner will also exclude these auto-fixed elements from scan results.', 'ModulesWeprestaeaaaccessibilitycheckerAdmin'),
                'required' => false,
            ]);
    }
}
