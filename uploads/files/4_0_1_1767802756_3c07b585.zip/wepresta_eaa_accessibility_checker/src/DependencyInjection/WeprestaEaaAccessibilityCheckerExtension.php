<?php
/**
 * WeprestaEaaAccessibilityCheckerExtension.php
 *
 * @author     WePresta
 * @copyright  2024 WePresta
 * @license    https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * @package    Wepresta\EaaAccessibilityChecker\DependencyInjection
 */

namespace Wepresta\EaaAccessibilityChecker\DependencyInjection;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\DependencyInjection\Extension\Extension;

/*
 * IMPORTANT: Register the autoloader at file-level (before class definition).
 * This ensures the autoloader is registered as soon as PHP parses this file,
 * which happens BEFORE Symfony tries to instantiate the controllers.
 *
 * This is critical for compatibility between PrestaShop 8 and 9.
 */
(static function () {
    static $registered = false;
    if ($registered) {
        return;
    }

    $modulePath = dirname(__DIR__, 2);

    // Load Composer autoloader if available
    $vendorAutoload = $modulePath . '/vendor/autoload.php';
    if (file_exists($vendorAutoload)) {
        require_once $vendorAutoload;
        $registered = true;
        return;
    }

    // Fallback: load module autoloader
    $moduleAutoload = $modulePath . '/autoload.php';
    if (file_exists($moduleAutoload)) {
        require_once $moduleAutoload;
    }

    $registered = true;
})();

/**
 * Symfony DI Extension for the WePresta EAA Accessibility Checker Module.
 *
 * The autoloader is registered at file-level above to ensure
 * it's available before any controller classes are parsed.
 *
 * This class must be named following the pattern:
 * {ModuleNameCamelCase}Extension
 *
 * The naming convention is important for PrestaShop to auto-discover the extension.
 */
class WeprestaEaaAccessibilityCheckerExtension extends Extension
{
    /**
     * {@inheritdoc}
     */
    public function load(array $configs, ContainerBuilder $container): void
    {
        // Services are loaded from config/services.yml and config/admin/services.yml
        // This method can be left empty as PrestaShop handles the loading
    }
}

