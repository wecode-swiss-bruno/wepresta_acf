<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Centralized helper for WCAG rules and accessibility criteria metadata.
 * All rule definitions should be sourced from this class.
 */
class AccessibilityRuleHelper
{
    /**
     * Severity order weights for sorting (higher = more severe)
     */
    public const SEVERITY_WEIGHTS = [
        'critical' => 4,
        'serious' => 3,
        'moderate' => 2,
        'minor' => 1,
    ];

    /**
     * Complete rule definitions with all metadata
     */
    private const RULES = [
        'image-alt' => [
            'label' => 'Images without alternative text',
            'title' => 'Images must have alternative text',
            'description' => 'All images must have an alt attribute that describes the image content or function.',
            'wcag' => '1.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 1.1.1 Non-text Content (Level A)',
            'severity' => 'critical',
            'auto_fixable' => false,
            'action_type' => 'alt_editor',
            'tip' => 'Use the Alt Text Editor to fix all images in one place.',
            'why_important' => 'Screen reader users cannot see images. Without alt text, they miss important information or don\'t understand the purpose of the image.',
            'how_to_fix' => [
                'Add descriptive alt text for informative images',
                'Use alt="" (empty) for purely decorative images',
                'For complex images (charts, graphs), provide a longer description nearby',
                'Don\'t start with "Image of..." - the user already knows it\'s an image',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<img src="product.jpg">', 'type' => 'bad'],
                ['label' => 'Good (informative)', 'code' => '<img src="product.jpg" alt="Red leather handbag with gold clasp">', 'type' => 'good'],
                ['label' => 'Good (decorative)', 'code' => '<img src="decoration.png" alt="">', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'W3C Images Tutorial', 'url' => 'https://www.w3.org/WAI/tutorials/images/'],
                ['title' => 'Alt Decision Tree', 'url' => 'https://www.w3.org/WAI/tutorials/images/decision-tree/'],
            ],
        ],
        'link-name' => [
            'label' => 'Links with non-descriptive text',
            'title' => 'Links must have accessible names',
            'description' => 'All links must have text or an accessible name that describes where they go.',
            'wcag' => '2.4.4',
            'wcag_criteria' => 'WCAG 2.1 - 2.4.4 Link Purpose (Level A)',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Screen reader users often navigate by links. Without descriptive text, they can\'t understand where a link leads.',
            'how_to_fix' => [
                'Add descriptive link text',
                'Avoid generic text like "Click here" or "Read more"',
                'For image links, use alt text on the image',
                'Use aria-label for icon-only links',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<a href="/products"><i class="icon-arrow"></i></a>', 'type' => 'bad'],
                ['label' => 'Bad (generic)', 'code' => '<a href="/products">Click here</a>', 'type' => 'bad'],
                ['label' => 'Good', 'code' => '<a href="/products">View all products</a>', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Link Purpose', 'url' => 'https://www.w3.org/WAI/WCAG21/Understanding/link-purpose-in-context.html'],
            ],
        ],
        'label' => [
            'label' => 'Form inputs without labels',
            'title' => 'Form inputs must have labels',
            'description' => 'All form inputs must have associated labels that describe what information is expected.',
            'wcag' => '3.3.2',
            'wcag_criteria' => 'WCAG 2.1 - 1.3.1 Info and Relationships (Level A)',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'You can automatically add ARIA labels to fix most of these issues.',
            'why_important' => 'Screen reader users need labels to understand what to enter in form fields. Without them, forms are unusable.',
            'how_to_fix' => [
                'Add a <label> element with for="input-id"',
                'Or wrap the input inside the label element',
                'Use aria-label as a last resort',
                'Placeholder is NOT a substitute for a label',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<input type="email" placeholder="Email">', 'type' => 'bad'],
                ['label' => 'Good (for attribute)', 'code' => "<label for=\"email\">Email</label>\n<input type=\"email\" id=\"email\">", 'type' => 'good'],
                ['label' => 'Good (wrapped)', 'code' => '<label>Email <input type="email"></label>', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Form Labels', 'url' => 'https://www.w3.org/WAI/tutorials/forms/labels/'],
            ],
        ],
        'color-contrast' => [
            'label' => 'Insufficient color contrast',
            'title' => 'Text must have sufficient color contrast',
            'description' => 'Text must have a contrast ratio of at least 4.5:1 against its background (3:1 for large text).',
            'wcag' => '1.4.3',
            'wcag_criteria' => 'WCAG 2.1 - 1.4.3 Contrast (Minimum) (Level AA)',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Users with low vision or color blindness may not be able to read text with insufficient contrast.',
            'how_to_fix' => [
                'Use a contrast checker tool to verify ratios',
                'Increase the darkness of text or lightness of background',
                'Avoid light gray text on white backgrounds',
                'Large text (18pt+ or 14pt+ bold) only needs 3:1 ratio',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<p style="color: #999; background: #fff;">Low contrast text</p>', 'type' => 'bad'],
                ['label' => 'Good', 'code' => '<p style="color: #333; background: #fff;">High contrast text</p>', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Contrast Checker', 'url' => 'https://webaim.org/resources/contrastchecker/'],
            ],
        ],
        'html-has-lang' => [
            'label' => 'Missing document language',
            'title' => 'Page must have a language defined',
            'description' => 'The HTML element must have a valid lang attribute.',
            'wcag' => '3.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 3.1.1 Language of Page (Level A)',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'This can be automatically fixed by configuring the language in PrestaShop settings.',
            'why_important' => 'Screen readers use the language attribute to pronounce content correctly. Without it, content may be mispronounced.',
            'how_to_fix' => [
                'Add lang attribute to the <html> element',
                'Use valid ISO language codes (en, fr, de, etc.)',
                'Match the primary language of the page content',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<html>', 'type' => 'bad'],
                ['label' => 'Good (English)', 'code' => '<html lang="en">', 'type' => 'good'],
                ['label' => 'Good (French)', 'code' => '<html lang="fr">', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Language Attribute', 'url' => 'https://www.w3.org/International/questions/qa-html-language-declarations'],
            ],
        ],
        'html-lang-valid' => [
            'label' => 'Invalid document language',
            'title' => 'Language code must be valid',
            'description' => 'The lang attribute must contain a valid language code.',
            'wcag' => '3.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 3.1.1 Language of Page (Level A)',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => null,
            'why_important' => 'Invalid language codes prevent screen readers from correctly pronouncing content.',
            'how_to_fix' => [
                'Use valid ISO 639-1 language codes',
                'Common codes: en, fr, de, es, it, pt, nl',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'document-title' => [
            'label' => 'Missing page titles',
            'title' => 'Pages must have descriptive titles',
            'description' => 'Each page must have a unique and descriptive title element.',
            'wcag' => '2.4.2',
            'wcag_criteria' => 'WCAG 2.1 - 2.4.2 Page Titled (Level A)',
            'severity' => 'serious',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Page titles help users understand where they are and are announced by screen readers.',
            'how_to_fix' => [
                'Add a descriptive <title> element in the head',
                'Make titles unique for each page',
                'Include the page purpose and site name',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'skip-link' => [
            'label' => 'Missing skip links',
            'title' => 'Page should have a skip navigation link',
            'description' => 'A skip link allows keyboard users to bypass repetitive navigation.',
            'wcag' => '2.4.1',
            'wcag_criteria' => 'WCAG 2.1 - 2.4.1 Bypass Blocks (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => true,
            'action_type' => 'settings',
            'tip' => 'Enable skip links in the module settings to fix this automatically.',
            'why_important' => 'Keyboard users must tab through every link in navigation before reaching main content. Skip links let them jump directly to content.',
            'how_to_fix' => [
                'Add a skip link as the first focusable element',
                'Link it to the main content area with id="main-content"',
                'Make it visible on focus (can be visually hidden otherwise)',
            ],
            'code_examples' => [
                ['label' => 'Good', 'code' => "<a href=\"#main-content\" class=\"skip-link\">Skip to content</a>\n...\n<main id=\"main-content\">", 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Skip Links', 'url' => 'https://www.w3.org/WAI/WCAG21/Techniques/general/G1'],
            ],
        ],
        'bypass' => [
            'label' => 'No way to bypass blocks',
            'title' => 'Provide a way to bypass repetitive content',
            'description' => 'Users must be able to skip repetitive content blocks.',
            'wcag' => '2.4.1',
            'wcag_criteria' => 'WCAG 2.1 - 2.4.1 Bypass Blocks (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => true,
            'action_type' => 'settings',
            'tip' => 'Enable skip links in the module settings to fix this automatically.',
            'why_important' => 'Keyboard users must tab through every link in navigation before reaching main content.',
            'how_to_fix' => [
                'Add skip links',
                'Use proper heading structure',
                'Use ARIA landmarks',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'aria-valid-attr' => [
            'label' => 'Invalid ARIA attributes',
            'title' => 'ARIA attributes must be valid',
            'description' => 'ARIA attributes used must be recognized ARIA attribute names.',
            'wcag' => '4.1.2',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.2 Name, Role, Value (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Invalid ARIA attributes are ignored by assistive technologies.',
            'how_to_fix' => [
                'Check ARIA attribute spelling',
                'Use only valid ARIA attributes',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'aria-valid-attr-value' => [
            'label' => 'Invalid ARIA attribute values',
            'title' => 'ARIA attribute values must be valid',
            'description' => 'ARIA attributes must have valid values.',
            'wcag' => '4.1.2',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.2 Name, Role, Value (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Invalid ARIA values can cause assistive technologies to malfunction.',
            'how_to_fix' => [
                'Check ARIA attribute value requirements',
                'Use only valid values for each attribute',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'button-name' => [
            'label' => 'Buttons without accessible names',
            'title' => 'Buttons must have accessible names',
            'description' => 'All buttons must have text content or an accessible name that describes their purpose.',
            'wcag' => '4.1.2',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.2 Name, Role, Value (Level A)',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => 'You can automatically add ARIA labels to fix most of these issues.',
            'why_important' => 'Screen reader users hear button names announced. Without a name, they don\'t know what the button does.',
            'how_to_fix' => [
                'Add visible text inside the button',
                'Use aria-label for icon-only buttons',
                'Use aria-labelledby to reference visible text elsewhere',
                'Ensure the accessible name describes the action',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<button type="button"><i class="icon-close"></i></button>', 'type' => 'bad'],
                ['label' => 'Good (text)', 'code' => '<button type="button">Close</button>', 'type' => 'good'],
                ['label' => 'Good (aria-label)', 'code' => '<button type="button" aria-label="Close dialog"><i class="icon-close"></i></button>', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Button Accessible Name', 'url' => 'https://www.w3.org/WAI/ARIA/apg/practices/names-and-descriptions/'],
            ],
        ],
        'duplicate-id' => [
            'label' => 'Duplicate element IDs',
            'title' => 'Element IDs must be unique',
            'description' => 'The id attribute value must be unique within the document.',
            'wcag' => '4.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.1 Parsing (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Duplicate IDs can cause assistive technologies to malfunction.',
            'how_to_fix' => [
                'Ensure each ID is unique on the page',
                'Remove duplicate IDs or make them unique',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'duplicate-id-active' => [
            'label' => 'Duplicate IDs on interactive elements',
            'title' => 'Interactive element IDs must be unique',
            'description' => 'IDs on focusable elements must be unique.',
            'wcag' => '4.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.1 Parsing (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Duplicate IDs on interactive elements break form labels and ARIA references.',
            'how_to_fix' => [
                'Make IDs unique on interactive elements',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'duplicate-id-aria' => [
            'label' => 'Duplicate ARIA IDs',
            'title' => 'ARIA IDs must be unique',
            'description' => 'IDs used in ARIA relationships must be unique.',
            'wcag' => '4.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.1 Parsing (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Duplicate IDs break ARIA relationships like aria-labelledby.',
            'how_to_fix' => [
                'Make IDs unique when used with ARIA attributes',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'page-has-heading-one' => [
            'label' => 'Missing heading structure',
            'title' => 'Page must have a main heading (H1)',
            'description' => 'Each page should have exactly one H1 heading that describes the page content.',
            'wcag' => '1.3.1',
            'wcag_criteria' => 'WCAG 2.1 - 1.3.1 Info and Relationships (Level A)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Screen reader users use headings to navigate and understand page structure. The H1 tells them what the page is about.',
            'how_to_fix' => [
                'Add a single H1 heading at the start of main content',
                'Make sure the H1 describes the page purpose',
                'Don\'t skip heading levels (H1 → H2 → H3)',
                'Don\'t use multiple H1 elements on a single page',
            ],
            'code_examples' => [
                ['label' => 'Bad', 'code' => '<div class="title">Product Page</div>', 'type' => 'bad'],
                ['label' => 'Good', 'code' => '<h1>Summer Collection Dresses</h1>', 'type' => 'good'],
            ],
            'resources' => [
                ['title' => 'Headings', 'url' => 'https://www.w3.org/WAI/tutorials/page-structure/headings/'],
            ],
        ],
        'meta-viewport' => [
            'label' => 'Viewport prevents zooming',
            'title' => 'Viewport must not prevent zooming',
            'description' => 'The meta viewport must not disable user scaling.',
            'wcag' => '1.4.4',
            'wcag_criteria' => 'WCAG 2.1 - 1.4.4 Resize Text (Level AA)',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Users with low vision need to zoom content.',
            'how_to_fix' => [
                'Remove user-scalable=no from viewport',
                'Remove maximum-scale=1.0 from viewport',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'tabindex' => [
            'label' => 'Incorrect tabindex values',
            'title' => 'Tabindex values must be correct',
            'description' => 'Tabindex values greater than 0 should be avoided.',
            'wcag' => '2.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 2.1.1 Keyboard (Level A)',
            'severity' => 'minor',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Positive tabindex values create confusing focus order.',
            'how_to_fix' => [
                'Use tabindex="0" for focusable elements',
                'Use tabindex="-1" for programmatic focus only',
                'Avoid positive tabindex values',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'focus-order-semantics' => [
            'label' => 'Focus order issues',
            'title' => 'Focus order must be logical',
            'description' => 'Focus order must follow a logical sequence.',
            'wcag' => '2.1.1',
            'wcag_criteria' => 'WCAG 2.1 - 2.4.3 Focus Order (Level A)',
            'severity' => 'minor',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'Illogical focus order confuses keyboard users.',
            'how_to_fix' => [
                'Ensure DOM order matches visual order',
                'Use CSS for visual positioning, not tabindex',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
        'input-button-name' => [
            'label' => 'Input buttons without names',
            'title' => 'Input buttons must have accessible names',
            'description' => 'Input buttons must have a value or accessible name.',
            'wcag' => '3.3.2',
            'wcag_criteria' => 'WCAG 2.1 - 4.1.2 Name, Role, Value (Level A)',
            'severity' => 'serious',
            'auto_fixable' => true,
            'action_type' => 'auto_fix',
            'tip' => null,
            'why_important' => 'Screen readers need to announce button purpose.',
            'how_to_fix' => [
                'Add value attribute to input buttons',
                'Use aria-label if needed',
            ],
            'code_examples' => [],
            'resources' => [],
        ],
    ];

    /**
     * Mapping from scanner rule_id to WCAG criteria
     */
    private const RULE_TO_WCAG = [
        'image-alt' => '1.1.1',
        'label' => '1.3.1',
        'page-has-heading-one' => '1.3.1',
        'color-contrast' => '1.4.3',
        'meta-viewport' => '1.4.4',
        'tabindex' => '2.1.1',
        'focus-order-semantics' => '2.1.1',
        'skip-link' => '2.4.1',
        'bypass' => '2.4.1',
        'document-title' => '2.4.2',
        'link-name' => '2.4.4',
        'html-has-lang' => '3.1.1',
        'html-lang-valid' => '3.1.1',
        'input-button-name' => '3.3.2',
        'duplicate-id' => '4.1.1',
        'duplicate-id-active' => '4.1.1',
        'duplicate-id-aria' => '4.1.1',
        'button-name' => '4.1.2',
        'aria-valid-attr' => '4.1.2',
        'aria-valid-attr-value' => '4.1.2',
    ];

    /**
     * Get all rules
     */
    public function getAllRules(): array
    {
        return self::RULES;
    }

    /**
     * Get a specific rule by ID
     */
    public function getRule(string $ruleId): ?array
    {
        return self::RULES[$ruleId] ?? null;
    }

    /**
     * Get rule or default for unknown rules
     */
    public function getRuleOrDefault(string $ruleId): array
    {
        if (isset(self::RULES[$ruleId])) {
            return self::RULES[$ruleId];
        }

        return [
            'label' => $this->humanizeRuleId($ruleId),
            'title' => ucfirst(str_replace('-', ' ', $ruleId)),
            'description' => 'Accessibility issue detected',
            'wcag' => null,
            'wcag_criteria' => 'WCAG 2.1',
            'severity' => 'moderate',
            'auto_fixable' => false,
            'action_type' => 'view_details',
            'tip' => null,
            'why_important' => 'This affects accessibility for some users.',
            'how_to_fix' => ['Review the element and ensure it meets accessibility standards.'],
            'code_examples' => [],
            'resources' => [
                ['title' => 'WCAG Guidelines', 'url' => 'https://www.w3.org/WAI/WCAG21/quickref/'],
            ],
        ];
    }

    /**
     * Get rule title
     */
    public function getRuleTitle(string $ruleId): string
    {
        return self::RULES[$ruleId]['title'] ?? ucfirst(str_replace('-', ' ', $ruleId));
    }

    /**
     * Get rule label (short)
     */
    public function getRuleLabel(string $ruleId): string
    {
        return self::RULES[$ruleId]['label'] ?? $this->humanizeRuleId($ruleId);
    }

    /**
     * Get rule description
     */
    public function getRuleDescription(string $ruleId): string
    {
        return self::RULES[$ruleId]['description'] ?? '';
    }

    /**
     * Get solutions for a rule
     */
    public function getRuleSolutions(string $ruleId): array
    {
        return self::RULES[$ruleId]['how_to_fix'] ?? [];
    }

    /**
     * Get help URL for a rule
     */
    public function getRuleHelpUrl(string $ruleId): string
    {
        $resources = self::RULES[$ruleId]['resources'] ?? [];
        return $resources[0]['url'] ?? '#';
    }

    /**
     * Get WCAG criterion from rule ID
     */
    public function getWcagFromRule(string $ruleId): ?string
    {
        return self::RULE_TO_WCAG[$ruleId] ?? null;
    }

    /**
     * Get all rule to WCAG mappings
     */
    public function getRuleToWcagMapping(): array
    {
        return self::RULE_TO_WCAG;
    }

    /**
     * Get severity weight for a severity level
     */
    public function getSeverityWeight(string $severity): int
    {
        return self::SEVERITY_WEIGHTS[$severity] ?? 1;
    }

    /**
     * Convert rule_id to human-readable label
     */
    private function humanizeRuleId(string $ruleId): string
    {
        return ucfirst(str_replace(['-', '_'], ' ', $ruleId));
    }
}
