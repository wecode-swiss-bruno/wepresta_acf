<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Install;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Db;
use Module;

class Installer
{
    private const HOOKS = [
        'displayHeader',
        'displayBackOfficeHeader',
        'actionFrontControllerSetMedia',
        'actionAdminControllerSetMedia',
        'actionObjectProductUpdateAfter',
        'actionObjectCmsUpdateAfter',
    ];

    public function __construct(
        private readonly Module $module
    ) {
    }

    public function install(): bool
    {
        return $this->installDatabase()
            && $this->registerHooks();
        // Tab installation disabled for MVP
        // && (new TabInstaller($this->module))->install();
    }

    public function uninstall(): bool
    {
        $this->uninstallDatabase();
        (new TabInstaller($this->module))->uninstall();
        return true;
    }

    private function registerHooks(): bool
    {
        foreach (self::HOOKS as $hook) {
            if (!$this->module->registerHook($hook)) {
                return false;
            }
        }
        return true;
    }

    private function installDatabase(): bool
    {
        $sqlFile = dirname(__DIR__, 2) . '/sql/install.sql';
        if (!file_exists($sqlFile)) {
            return true;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = preg_split('/;\s*[\r\n]+/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }

        return true;
    }

    private function uninstallDatabase(): bool
    {
        $sqlFile = dirname(__DIR__, 2) . '/sql/uninstall.sql';
        if (!file_exists($sqlFile)) {
            return true;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = preg_split('/;\s*[\r\n]+/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                Db::getInstance()->execute($query);
            }
        }

        return true;
    }
}
