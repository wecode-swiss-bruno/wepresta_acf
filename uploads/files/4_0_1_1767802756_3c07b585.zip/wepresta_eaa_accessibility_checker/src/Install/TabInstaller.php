<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Install;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Language;
use Module;
use Tab;

class TabInstaller
{
    private const TAB_CLASS = 'AdminWeprestaEaaAccessibility';
    private const TAB_ROUTE_NAME = 'wepresta_eaa_dashboard';

    public function __construct(
        private readonly Module $module
    ) {
    }

    public function install(): bool
    {
        if ((int) Tab::getIdFromClassName(self::TAB_CLASS) > 0) {
            return true;
        }

        $tab = new Tab();
        $tab->active = 1;
        $tab->class_name = self::TAB_CLASS;
        $tab->route_name = self::TAB_ROUTE_NAME;
        $tab->name = [];

        foreach (Language::getLanguages(false) as $lang) {
            $tab->name[(int) $lang['id_lang']] = 'EAA Accessibility Checker Pro';
        }

        $tab->id_parent = 0;
        $tab->module = $this->module->name;

        return (bool) $tab->add();
    }

    public function uninstall(): bool
    {
        $id = (int) Tab::getIdFromClassName(self::TAB_CLASS);
        if ($id <= 0) {
            return true;
        }
        $tab = new Tab($id);
        return (bool) $tab->delete();
    }
}
