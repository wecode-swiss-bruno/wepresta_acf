<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

namespace Wepresta\EaaAccessibilityChecker\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;

class ScanRepository
{
    private string $tableName;

    public function __construct(
        private readonly Connection $connection,
        string $dbPrefix
    ) {
        $this->tableName = $dbPrefix . 'wepresta_eaa_scans';
    }

    /**
     * Save a new scan
     */
    public function save(array $data): int
    {
        $insertData = [
            'page_url' => $data['page_url'],
            'page_type' => $data['page_type'],
            'score' => $data['score'],
            'issues_count' => $data['issues_count'],
            'date_add' => date('Y-m-d H:i:s'),
        ];

        // Add snapshot if provided
        if (isset($data['id_snapshot'])) {
            $insertData['id_snapshot'] = $data['id_snapshot'];
        }

        $this->connection->insert($this->tableName, $insertData);

        return (int) $this->connection->lastInsertId();
    }

    /**
     * Find scans by snapshot ID
     */
    public function findBySnapshot(int $snapshotId, int $limit = 10, int $offset = 0): array
    {
        $qb = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->orderBy('date_add', 'DESC')
            ->setMaxResults($limit);

        if ($offset > 0) {
            $qb->setFirstResult($offset);
        }

        return $qb->execute()->fetchAllAssociative();
    }

    /**
     * Count scans in a snapshot
     */
    public function countBySnapshot(int $snapshotId): int
    {
        $result = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->tableName)
            ->where('id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->execute()
            ->fetchOne();

        return (int) $result;
    }

    /**
     * Get average score for a snapshot
     */
    public function getAverageScoreBySnapshot(int $snapshotId): float
    {
        $result = $this->connection->createQueryBuilder()
            ->select('AVG(score) as avg_score')
            ->from($this->tableName)
            ->where('id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->execute()
            ->fetchOne();

        return (float) ($result ?? 0);
    }

    /**
     * Get scores by page type for a snapshot
     */
    public function getScoresByPageTypeAndSnapshot(int $snapshotId): array
    {
        return $this->connection->createQueryBuilder()
            ->select('page_type', 'AVG(score) as avg_score', 'COUNT(*) as scan_count')
            ->from($this->tableName)
            ->where('id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->groupBy('page_type')
            ->orderBy('avg_score', 'ASC')
            ->execute()
            ->fetchAllAssociative();
    }

    /**
     * Count all scans
     */
    public function count(): int
    {
        $result = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->tableName)
            ->execute()
            ->fetchOne();

        return (int) $result;
    }

    /**
     * Find scan by ID
     */
    public function findById(int $id): ?array
    {
        $result = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_scan = :id')
            ->setParameter('id', $id)
            ->execute()
            ->fetchAssociative();

        return $result ?: null;
    }

    /**
     * Delete all scans
     */
    public function deleteAll(): int
    {
        return (int) $this->connection->exec('DELETE FROM ' . $this->tableName);
    }

    /**
     * Delete scan by ID
     */
    public function deleteById(int $id): bool
    {
        return $this->connection->delete($this->tableName, ['id_scan' => $id]) > 0;
    }

    /**
     * Delete scans by snapshot ID
     */
    public function deleteBySnapshot(int $snapshotId): int
    {
        return $this->connection->delete($this->tableName, ['id_snapshot' => $snapshotId]);
    }
}
