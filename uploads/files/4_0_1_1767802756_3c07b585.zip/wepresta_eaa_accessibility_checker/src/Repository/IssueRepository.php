<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

namespace Wepresta\EaaAccessibilityChecker\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;

class IssueRepository
{
    private string $tableName;
    private string $scansTable;

    public function __construct(
        private readonly Connection $connection,
        string $dbPrefix
    ) {
        $this->tableName = $dbPrefix . 'wepresta_eaa_issues';
        $this->scansTable = $dbPrefix . 'wepresta_eaa_scans';
    }

    public function save(array $data): int
    {
        $this->connection->insert($this->tableName, [
            'id_scan' => $data['id_scan'],
            'rule_id' => $data['rule_id'],
            'severity' => $data['severity'],
            'selector' => $data['selector'] ?? null,
            'message' => $data['message'] ?? null,
            'fixed' => $data['fixed'] ?? 0,
            'date_add' => date('Y-m-d H:i:s'),
        ]);

        return (int) $this->connection->lastInsertId();
    }

    public function saveBatch(int $scanId, array $issues): void
    {
        foreach ($issues as $issue) {
            $this->save([
                'id_scan' => $scanId,
                'rule_id' => $issue['rule_id'],
                'severity' => $issue['severity'],
                'selector' => $issue['selector'] ?? null,
                'message' => $issue['message'] ?? null,
            ]);
        }
    }

    public function findByScanId(int $scanId): array
    {
        return $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_scan = :scanId')
            ->setParameter('scanId', $scanId)
            ->orderBy('severity', 'ASC')
            ->execute()
            ->fetchAllAssociative();
    }

    /**
     * Count issues by severity for a specific snapshot
     */
    public function countBySeverityAndSnapshot(int $snapshotId): array
    {
        return $this->connection->createQueryBuilder()
            ->select('i.severity', 'COUNT(*) as count')
            ->from($this->tableName, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('s.id_snapshot = :snapshot')
            ->andWhere('i.fixed = 0')
            ->andWhere('i.ignored = 0')
            ->setParameter('snapshot', $snapshotId)
            ->groupBy('i.severity')
            ->execute()
            ->fetchAllAssociative();
    }

    public function markAsFixed(int $issueId): bool
    {
        return (bool) $this->connection->update(
            $this->tableName,
            ['fixed' => 1],
            ['id_issue' => $issueId]
        );
    }

    public function deleteAll(): int
    {
        return (int) $this->connection->exec('DELETE FROM ' . $this->tableName);
    }

    public function deleteByScanId(int $scanId): int
    {
        return $this->connection->delete($this->tableName, ['id_scan' => $scanId]);
    }
}
