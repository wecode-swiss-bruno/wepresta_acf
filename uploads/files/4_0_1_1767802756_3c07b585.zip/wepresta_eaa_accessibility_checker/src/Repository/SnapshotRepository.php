<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;

/**
 * Repository for managing scan snapshots
 * 
 * A snapshot represents a complete scan session of the site.
 * Only one snapshot is "active" at a time - it contains the current state.
 * Old snapshots are kept for historical comparison.
 */
class SnapshotRepository
{
    private string $tableName;
    private string $scansTable;
    private string $issuesTable;

    public function __construct(
        private readonly Connection $connection,
        string $dbPrefix
    ) {
        $this->tableName = $dbPrefix . 'wepresta_eaa_snapshots';
        $this->scansTable = $dbPrefix . 'wepresta_eaa_scans';
        $this->issuesTable = $dbPrefix . 'wepresta_eaa_issues';
    }

    /**
     * Create a new snapshot and make it active
     * Deactivates all previous snapshots
     */
    public function createNew(?string $label = null, int $shopId = 1): int
    {
        // Deactivate all existing snapshots for this shop
        $this->connection->update(
            $this->tableName,
            ['is_active' => 0],
            ['is_active' => 1, 'id_shop' => $shopId]
        );

        // Create new active snapshot
        $this->connection->insert($this->tableName, [
            'label' => $label,
            'total_pages' => 0,
            'total_issues' => 0,
            'avg_score' => 0,
            'is_active' => 1,
            'id_shop' => $shopId,
            'date_add' => date('Y-m-d H:i:s'),
        ]);

        return (int) $this->connection->lastInsertId();
    }

    /**
     * Get the currently active snapshot
     */
    public function getActive(int $shopId = 1): ?array
    {
        $result = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('is_active = 1')
            ->andWhere('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->execute()
            ->fetchAssociative();

        return $result ?: null;
    }

    /**
     * Get snapshot by ID
     */
    public function findById(int $id): ?array
    {
        $result = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_snapshot = :id')
            ->setParameter('id', $id)
            ->execute()
            ->fetchAssociative();

        return $result ?: null;
    }

    /**
     * Get all snapshots for history (newest first)
     */
    public function getHistory(int $shopId = 1, int $limit = 10): array
    {
        return $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->orderBy('date_add', 'DESC')
            ->setMaxResults($limit)
            ->execute()
            ->fetchAllAssociative();
    }

    /**
     * Update snapshot statistics after scan completion
     */
    public function updateStats(int $snapshotId): void
    {
        // Calculate stats from scans
        $stats = $this->connection->createQueryBuilder()
            ->select(
                'COUNT(DISTINCT s.id_scan) as total_pages',
                'COALESCE(SUM(s.issues_count), 0) as total_issues',
                'COALESCE(AVG(s.score), 0) as avg_score'
            )
            ->from($this->scansTable, 's')
            ->where('s.id_snapshot = :snapshot')
            ->setParameter('snapshot', $snapshotId)
            ->execute()
            ->fetchAssociative();

        // Calculate issues by severity
        $severityStats = $this->connection->createQueryBuilder()
            ->select('i.severity', 'COUNT(*) as count')
            ->from($this->issuesTable, 'i')
            ->join('i', $this->scansTable, 's', 'i.id_scan = s.id_scan')
            ->where('s.id_snapshot = :snapshot')
            ->andWhere('i.fixed = 0')
            ->andWhere('i.ignored = 0')
            ->setParameter('snapshot', $snapshotId)
            ->groupBy('i.severity')
            ->execute()
            ->fetchAllAssociative();

        $severityData = [];
        foreach ($severityStats as $row) {
            $severityData[$row['severity']] = (int) $row['count'];
        }

        // Update snapshot
        $this->connection->update(
            $this->tableName,
            [
                'total_pages' => (int) $stats['total_pages'],
                'total_issues' => (int) $stats['total_issues'],
                'avg_score' => round((float) $stats['avg_score'], 2),
                'issues_by_severity' => json_encode($severityData),
            ],
            ['id_snapshot' => $snapshotId]
        );
    }

    /**
     * Get score evolution for chart (last N snapshots)
     */
    public function getScoreHistory(int $shopId = 1, int $limit = 10): array
    {
        return $this->connection->createQueryBuilder()
            ->select('id_snapshot', 'label', 'avg_score', 'total_issues', 'total_pages', 'date_add')
            ->from($this->tableName)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->orderBy('date_add', 'ASC')
            ->setMaxResults($limit)
            ->execute()
            ->fetchAllAssociative();
    }

    /**
     * Get comparison between current and previous snapshot
     */
    public function getComparison(int $shopId = 1): ?array
    {
        $snapshots = $this->connection->createQueryBuilder()
            ->select('*')
            ->from($this->tableName)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->orderBy('date_add', 'DESC')
            ->setMaxResults(2)
            ->execute()
            ->fetchAllAssociative();

        if (count($snapshots) < 2) {
            return null;
        }

        $current = $snapshots[0];
        $previous = $snapshots[1];

        return [
            'current' => $current,
            'previous' => $previous,
            'score_delta' => round((float) $current['avg_score'] - (float) $previous['avg_score'], 2),
            'issues_delta' => (int) $current['total_issues'] - (int) $previous['total_issues'],
            'trend' => $current['avg_score'] >= $previous['avg_score'] ? 'up' : 'down',
        ];
    }

    /**
     * Delete old snapshots keeping only the last N
     */
    public function cleanupOld(int $keepCount = 10, int $shopId = 1): int
    {
        // Get IDs to keep
        $keepIds = $this->connection->createQueryBuilder()
            ->select('id_snapshot')
            ->from($this->tableName)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->orderBy('date_add', 'DESC')
            ->setMaxResults($keepCount)
            ->execute()
            ->fetchFirstColumn();

        if (empty($keepIds)) {
            return 0;
        }

        // Delete old snapshots (cascade will delete scans and issues)
        $placeholders = implode(',', array_fill(0, count($keepIds), '?'));
        return (int) $this->connection->executeQuery(
            "DELETE FROM {$this->tableName} WHERE id_shop = ? AND id_snapshot NOT IN ({$placeholders})",
            array_merge([$shopId], $keepIds)
        )->rowCount();
    }

    /**
     * Check if there's an active snapshot
     */
    public function hasActive(int $shopId = 1): bool
    {
        $count = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->tableName)
            ->where('is_active = 1')
            ->andWhere('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->execute()
            ->fetchOne();

        return (int) $count > 0;
    }

    /**
     * Get snapshot count
     */
    public function count(int $shopId = 1): int
    {
        $result = $this->connection->createQueryBuilder()
            ->select('COUNT(*)')
            ->from($this->tableName)
            ->where('id_shop = :shop')
            ->setParameter('shop', $shopId)
            ->execute()
            ->fetchOne();

        return (int) $result;
    }

    /**
     * Delete all snapshots (for reset functionality)
     */
    public function deleteAll(int $shopId = 1): int
    {
        return $this->connection->delete($this->tableName, ['id_shop' => $shopId]);
    }
}
