<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Service\AltEditorService;
use Language;
use Configuration;

class AltEditorController extends AbstractAdminController
{
    public function __construct(
        private readonly AltEditorService $altEditorService
    ) {
    }

    /**
     * Main page
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function indexAction(): Response
    {
        // Get languages
        $languages = Language::getLanguages(true);
        $defaultLangId = (int) Configuration::get('PS_LANG_DEFAULT');

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/alt-editor.html.twig', [
            'languages' => $languages,
            'default_lang_id' => $defaultLangId,
        ]);
    }

    /**
     * API: Get images list
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function getImagesAction(Request $request): JsonResponse
    {
        $langId = (int) $request->query->get('lang', Configuration::get('PS_LANG_DEFAULT'));
        $status = $request->query->get('status', 'all');
        $search = $request->query->get('search', '');
        $page = (int) $request->query->get('page', 1);
        $perPage = (int) $request->query->get('per_page', 20);

        try {
            $data = $this->altEditorService->getImages($langId, 'products', $status, $search, $page, $perPage);
            $stats = $this->altEditorService->getStats($langId);

            return new JsonResponse([
                'success' => true,
                'data' => array_merge($data, ['stats' => $stats]),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Failed to load images: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Save single alt text
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function saveAction(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $type = $data['type'] ?? '';
        $id = (int) ($data['id'] ?? 0);
        $langId = (int) ($data['lang_id'] ?? 0);
        $altText = $data['alt_text'] ?? '';

        if (!$type || !$id || !$langId) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Missing required parameters',
            ], 400);
        }

        // Validate alt text length (PrestaShop limit is 128 for legend, but we'll use 125 to be safe)
        if (strlen($altText) > 125) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Alt text exceeds maximum length of 125 characters',
            ], 400);
        }

        try {
            $success = $this->altEditorService->saveAltText($type, $id, $langId, $altText);

            return new JsonResponse([
                'success' => $success,
                'message' => $success ? 'Alt text saved successfully' : 'Failed to save alt text',
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Failed to save alt text: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Bulk save alt texts
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function bulkSaveAction(Request $request): JsonResponse
    {
        $data = json_decode($request->getContent(), true);

        $items = $data['items'] ?? [];
        $langId = (int) ($data['lang_id'] ?? 0);
        $action = $data['action'] ?? 'custom'; // 'custom' or 'use_name'
        $altText = $data['alt_text'] ?? '';

        if (empty($items) || !$langId) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Missing required parameters',
            ], 400);
        }

        // Validate bulk alt text length
        if ($action === 'custom' && strlen($altText) > 125) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Alt text exceeds maximum length of 125 characters',
            ], 400);
        }

        try {
            $updatedCount = $this->altEditorService->bulkSaveAltText($items, $langId, $action, $altText);

            return new JsonResponse([
                'success' => true,
                'message' => "{$updatedCount} images updated successfully",
                'updated_count' => $updatedCount,
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Failed to update images: ' . $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Get stats
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function statsAction(Request $request): JsonResponse
    {
        $langId = (int) $request->query->get('lang', Configuration::get('PS_LANG_DEFAULT'));

        try {
            $stats = $this->altEditorService->getStats($langId);

            return new JsonResponse([
                'success' => true,
                'data' => $stats,
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'message' => 'Failed to load stats: ' . $e->getMessage(),
            ], 500);
        }
    }
}
