<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Service\ConfigService;
use Wepresta\EaaAccessibilityChecker\Service\DashboardService;
use Wepresta\EaaAccessibilityChecker\Service\ScanService;
use Tools;

class DashboardController extends AbstractAdminController
{
    public function __construct(
        private readonly DashboardService $dashboardService,
        private readonly ScanService $scanService,
        private readonly ConfigService $configService
    ) {
    }

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function index(Request $request): Response
    {
        $context = Context::getContext();
        $shopId = (int) $context->shop->id;
        $employeeId = (int) $context->employee->id;

        // Core metrics
        $compliance = $this->dashboardService->getCompliancePercentage($shopId);
        $breakdown = $this->dashboardService->getComplianceBreakdown($shopId);
        $lastScanDate = $this->dashboardService->getLastScanDate();
        $totalIssues = $this->dashboardService->getTotalIssueCount();
        $imageAltIssues = $this->dashboardService->getImageAltIssueCount();
        $productImagesAltMultilang = $this->dashboardService->getProductImagesAltMultilangStatus();
        $hasScans = $this->dashboardService->hasScansForDashboard();
        $scoreBadge = $this->dashboardService->getScoreBadge($hasScans, $compliance);
        $progressBarColor = $this->dashboardService->getProgressBarColor($hasScans, $compliance);
        $nextActions = $this->dashboardService->getNextActions($shopId);
        $estimatedHours = $this->dashboardService->getEstimatedHours($shopId);

        // Score delta from previous scan
        $scoreDelta = $this->dashboardService->getScoreDelta();

        // Top 3 priority actions
        $topPriorityActions = $this->dashboardService->getTopPriorityActions(3);

        // Road to Compliance data
        $roadToCompliance = $this->dashboardService->getRoadToComplianceData($shopId);

        // Auto-fix data
        $autoFixData = $this->dashboardService->getAutoFixData();

        // Get dashboard stats (page performance, score history)
        $dashboardStats = $this->scanService->getDashboardStats();

        // Latest 5 scans only (simplified, no pagination)
        $latestScans = $this->scanService->getLatestScans(5);

        // Get active snapshot info
        $activeSnapshot = $this->dashboardService->getActiveSnapshot();
        $snapshotHistory = $this->dashboardService->getSnapshotHistory(30);

        // Auto-scan configuration (for tools section)
        $autoScanConfig = $this->configService->getAutoScanConfiguration();

        // Score evolution message (uses latest 2 snapshots)
        $scoreEvolution = $this->getScoreEvolutionSummary($snapshotHistory);

        // Get shop URL for scanning
        $shopUrl = Tools::getShopDomainSsl(true, true) . '/';

        // Build list of scannable pages
        $scannablePages = $this->getScannablePages();

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/dashboard.html.twig', [
            'hasScans' => $hasScans,
            'compliance' => $compliance,
            'breakdown' => $breakdown,
            'lastScanDate' => $lastScanDate,
            'totalIssues' => $totalIssues,
            'imageAltIssues' => $imageAltIssues,
            'productImagesAltMultilang' => $productImagesAltMultilang,
            'scoreDelta' => $scoreDelta,
            'topPriorityActions' => $topPriorityActions,
            'roadToCompliance' => $roadToCompliance,
            'autoFix' => $autoFixData,
            'scoreBadge' => $scoreBadge,
            'progressBarColor' => $progressBarColor,
            'nextActions' => $nextActions,
            'estimatedHours' => $estimatedHours,
            'autoScanConfig' => $autoScanConfig,
            'scoreEvolution' => $scoreEvolution,
            'employeeId' => $employeeId,
            'shopUrl' => $shopUrl,
            'scannablePages' => $scannablePages,
            // Dashboard stats
            'pagePerformance' => $dashboardStats['scores_by_page_type'] ?? [],
            'scoreHistory' => $dashboardStats['score_history'] ?? [],
            'averageScore' => $dashboardStats['average_score'] ?? 0,
            // Latest scans (simplified - 5 items only)
            'latestScans' => $latestScans,
            // Snapshot info for history
            'activeSnapshot' => $activeSnapshot,
            'snapshotHistory' => $snapshotHistory,
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->_t('Accessibility Dashboard', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
        ]);
    }

    /**
     * @param array<int, array<string, mixed>> $snapshotHistory
     * @return array{type:string,percent:?float}
     */
    private function getScoreEvolutionSummary(array $snapshotHistory): array
    {
        if (count($snapshotHistory) < 2) {
            return ['type' => 'insufficient', 'percent' => null];
        }

        $last = $snapshotHistory[count($snapshotHistory) - 1] ?? null;
        $prev = $snapshotHistory[count($snapshotHistory) - 2] ?? null;

        $lastScore = $last ? (float) ($last['avg_score'] ?? 0) : 0.0;
        $prevScore = $prev ? (float) ($prev['avg_score'] ?? 0) : 0.0;

        $delta = round($lastScore - $prevScore, 1);
        if (abs($delta) < 0.1) {
            return ['type' => 'stable', 'percent' => 0.0];
        }

        if ($delta > 0) {
            return ['type' => 'up', 'percent' => abs($delta)];
        }

        return ['type' => 'down', 'percent' => abs($delta)];
    }

    /**
     * Manual verification checklist page
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function checklist(Request $request): Response
    {
        $context = Context::getContext();
        $shopId = (int) $context->shop->id;

        // Core metrics
        $compliance = $this->dashboardService->getCompliancePercentage($shopId);
        $breakdown = $this->dashboardService->getComplianceBreakdown($shopId);
        $lastScanDate = $this->dashboardService->getLastScanDate();
        $totalIssues = $this->dashboardService->getTotalIssueCount();

        // Get criteria
        $automatedCriteria = $this->dashboardService->getAutomatedCriteria();
        $manualCriteria = $this->dashboardService->getManualCriteria($shopId);

        // Get dashboard stats
        $dashboardStats = $this->scanService->getDashboardStats();

        // Pagination for scans
        $scansPage = max(1, (int) $request->query->get('scans_page', 1));
        $scansPerPage = 10;
        $scansPaginated = $this->scanService->getPaginatedScans($scansPage, $scansPerPage);

        // Get shop URL for scanning
        $shopUrl = Tools::getShopDomainSsl(true, true) . '/';

        // Build list of scannable pages
        $scannablePages = $this->getScannablePages();

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/checklist.html.twig', [
            'compliance' => $compliance,
            'breakdown' => $breakdown,
            'lastScanDate' => $lastScanDate,
            'totalIssues' => $totalIssues,
            'automatedCriteria' => $automatedCriteria,
            'manualCriteria' => $manualCriteria,
            'shopUrl' => $shopUrl,
            'scannablePages' => $scannablePages,
            // Dashboard stats
            'pagePerformance' => $dashboardStats['scores_by_page_type'] ?? [],
            'scoreHistory' => $dashboardStats['score_history'] ?? [],
            // Scans with pagination
            'latestScans' => $scansPaginated['scans'],
            'scansPagination' => [
                'current' => $scansPage,
                'total' => $scansPaginated['total_pages'],
                'count' => $scansPaginated['total_count'],
                'perPage' => $scansPerPage,
            ],
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->_t('WCAG Checklist', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
        ]);
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function updateManual(Request $request): JsonResponse
    {
        try {
            $data = json_decode($request->getContent(), true) ?? [];

            $wcagCriterion = $data['wcag_criterion'] ?? null;
            $status = $data['status'] ?? null;
            $notes = $data['notes'] ?? null;

            if (!$wcagCriterion || !$status) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'wcag_criterion and status are required',
                ], 400);
            }

            $validStatuses = ['pending', 'compliant', 'non_compliant', 'not_applicable'];
            if (!in_array($status, $validStatuses)) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'Invalid status',
                ], 400);
            }

            $context = Context::getContext();
            $shopId = (int) $context->shop->id;
            $employeeId = (int) $context->employee->id;

            $this->dashboardService->updateManualStatus(
                $wcagCriterion,
                $status,
                $notes,
                $employeeId,
                $shopId
            );

            $breakdown = $this->dashboardService->getComplianceBreakdown($shopId);

            return new JsonResponse([
                'success' => true,
                'compliance' => $this->dashboardService->getCompliancePercentage($shopId),
                'breakdown' => $breakdown,
                'verified_at' => date('Y-m-d H:i:s'),
                'verified_by' => $employeeId,
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Reset all module data (scans, issues, manual criteria)
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function reset(Request $request): JsonResponse
    {
        try {
            $context = Context::getContext();
            $shopId = (int) $context->shop->id;

            $this->dashboardService->resetAllData($shopId);

            return new JsonResponse([
                'success' => true,
                'message' => $this->_t('All accessibility data has been reset successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $this->_t('Error resetting data: %error%', ['%error%' => $e->getMessage()], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ], 500);
        }
    }

    /**
     * Get issues for a specific WCAG criterion (for modal/detail view)
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function criterionIssues(Request $request, string $wcag): JsonResponse
    {
        try {
            $issues = $this->dashboardService->getIssuesForCriterion($wcag);

            return new JsonResponse([
                'success' => true,
                'wcag' => $wcag,
                'issues' => $issues,
                'count' => count($issues),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get list of scannable pages from the shop
     */
    private function getScannablePages(): array
    {
        $context = Context::getContext();
        $link = $context->link;
        $langId = (int) $context->language->id;

        $pages = [];

        // Homepage - always included
        $pages[] = [
            'id' => 'home',
            'url' => $link->getPageLink('index'),
            'type' => 'home',
            'label' => $this->_t('Homepage', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            'icon' => 'home',
            'recommended' => true,
        ];

        // Cart page
        $pages[] = [
            'id' => 'cart',
            'url' => $link->getPageLink('cart'),
            'type' => 'checkout',
            'label' => $this->_t('Cart', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            'icon' => 'shopping_cart',
            'recommended' => true,
        ];

        // Contact page
        $pages[] = [
            'id' => 'contact',
            'url' => $link->getPageLink('contact'),
            'type' => 'cms',
            'label' => $this->_t('Contact', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            'icon' => 'mail',
            'recommended' => true,
        ];

        // Login page
        $pages[] = [
            'id' => 'login',
            'url' => $link->getPageLink('authentication'),
            'type' => 'other',
            'label' => $this->_t('Login', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            'icon' => 'login',
            'recommended' => false,
        ];

        // Get some categories
        $categories = \Category::getCategories($langId, true, false);
        $catCount = 0;
        foreach ($categories as $category) {
            if ($catCount >= 3) {
                break;
            }
            if ((int) $category['id_category'] <= 2) {
                continue; // Skip root and home categories
            }
            $pages[] = [
                'id' => 'category_' . $category['id_category'],
                'url' => $link->getCategoryLink((int) $category['id_category']),
                'type' => 'category',
                'label' => $category['name'],
                'icon' => 'folder',
                'recommended' => $catCount === 0,
            ];
            $catCount++;
        }

        // Get some products
        $products = \Product::getProducts($langId, 0, 3, 'id_product', 'ASC', false, true);
        $prodCount = 0;
        foreach ($products as $product) {
            $pages[] = [
                'id' => 'product_' . $product['id_product'],
                'url' => $link->getProductLink((int) $product['id_product']),
                'type' => 'product',
                'label' => $product['name'],
                'icon' => 'inventory_2',
                'recommended' => $prodCount === 0,
            ];
            $prodCount++;
        }

        // Get CMS pages
        $cmsPages = \CMS::getCMSPages($langId);
        $cmsCount = 0;
        foreach ($cmsPages as $cmsPage) {
            if ($cmsCount >= 2) {
                break;
            }
            $pages[] = [
                'id' => 'cms_' . $cmsPage['id_cms'],
                'url' => $link->getCMSLink((int) $cmsPage['id_cms']),
                'type' => 'cms',
                'label' => $cmsPage['meta_title'],
                'icon' => 'article',
                'recommended' => false,
            ];
            $cmsCount++;
        }

        return $pages;
    }

    /**
     * Get or update auto-scan configuration
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function autoScanConfig(Request $request): JsonResponse
    {
        try {
            if ($request->isMethod('GET')) {
                $config = $this->configService->getAutoScanConfiguration();

                // Pre-fill email with current employee email if not set
                if (empty($config['email'])) {
                    $context = Context::getContext();
                    $employee = $context->employee;
                    $config['email'] = $employee->email ?? '';
                }

                return new JsonResponse([
                    'success' => true,
                    'config' => $config,
                ]);
            }

            if ($request->isMethod('POST')) {
                $data = json_decode($request->getContent(), true) ?? [];

                // Validate email if notifications are enabled
                if (($data['notificationsEnabled'] ?? false) && empty($data['email'])) {
                    return new JsonResponse([
                        'success' => false,
                        'error' => 'Email address is required when notifications are enabled',
                    ], 400);
                }

                // Validate email format
                if (($data['notificationsEnabled'] ?? false) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                    return new JsonResponse([
                        'success' => false,
                        'error' => 'Invalid email address format',
                    ], 400);
                }

                $this->configService->saveAutoScanConfiguration($data);

                return new JsonResponse([
                    'success' => true,
                    'message' => $this->_t('Auto-scan configuration saved successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
                ]);
            }

            return new JsonResponse([
                'success' => false,
                'error' => 'Method not allowed',
            ], 405);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
