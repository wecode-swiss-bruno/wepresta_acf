<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Service\IssuesService;
use Wepresta\EaaAccessibilityChecker\Service\ConfigService;

/**
 * Controller for the 3-level Issues navigation
 */
class IssuesController extends AbstractAdminController
{
    public function __construct(
        private readonly IssuesService $issuesService,
        private readonly ConfigService $configService
    ) {
    }

    /**
     * Level 1: Issues overview (grouped by type)
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function index(Request $request): Response
    {
        // Get filters from request
        $severityFilter = $request->query->get('severity', 'all');
        $pageTypeFilter = $request->query->get('page_type', 'all');
        $statusFilter = $request->query->get('status', 'open');

        // Get issues summary
        $summary = $this->issuesService->getIssuesSummary(
            $severityFilter !== 'all' ? $severityFilter : null,
            $pageTypeFilter !== 'all' ? $pageTypeFilter : null,
            $statusFilter
        );

        // Check if auto-fix is enabled to show tip box
        $autoFixEnabled = (bool) $this->configService->get('auto_fix_enabled');

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/issues.html.twig', [
            'summary' => $summary,
            'filters' => [
                'severity' => $severityFilter,
                'page_type' => $pageTypeFilter,
                'status' => $statusFilter,
            ],
            'autoFixEnabled' => $autoFixEnabled,
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->_t('Issues to Fix', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
        ]);
    }

    /**
     * Level 2: Issues by type (grouped by page type)
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function byType(Request $request, string $type): Response
    {
        $groupBy = $request->query->get('group_by', 'page_type');
        $page = max(1, (int) $request->query->get('page', 1));
        $statusFilter = $request->query->get('status', 'open');

        $issuesData = $this->issuesService->getIssuesByType(
            $type,
            $groupBy,
            $page,
            20,
            $statusFilter
        );

        // Get type metadata for display
        $typeMetadata = $this->issuesService->getIssueTypeMetadata($type);

        // Check if auto-fix is enabled to show tip box
        $autoFixEnabled = (bool) $this->configService->get('auto_fix_enabled');

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/issue_type.html.twig', [
            'issuesData' => $issuesData,
            'type' => $type,
            'typeMetadata' => $typeMetadata,
            'groupBy' => $groupBy,
            'statusFilter' => $statusFilter,
            'autoFixEnabled' => $autoFixEnabled,
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $issuesData['label'] ?? $type,
        ]);
    }

    /**
     * API: Get issues summary (Level 1 data)
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function apiSummary(Request $request): JsonResponse
    {
        try {
            $severityFilter = $request->query->get('severity');
            $pageTypeFilter = $request->query->get('page_type');
            $statusFilter = $request->query->get('status', 'open');

            $summary = $this->issuesService->getIssuesSummary(
                $severityFilter,
                $pageTypeFilter,
                $statusFilter
            );

            return new JsonResponse([
                'success' => true,
                'data' => $summary,
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Get issues by type (Level 2 data)
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function apiByType(Request $request, string $type): JsonResponse
    {
        try {
            $groupBy = $request->query->get('group_by', 'page_type');
            $page = max(1, (int) $request->query->get('page', 1));
            $perPage = min(50, max(10, (int) $request->query->get('per_page', 20)));
            $statusFilter = $request->query->get('status', 'open');

            $issuesData = $this->issuesService->getIssuesByType(
                $type,
                $groupBy,
                $page,
                $perPage,
                $statusFilter
            );

            return new JsonResponse([
                'success' => true,
                'data' => $issuesData,
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Bulk update issue status (Mark as Fixed, Ignore, Reopen)
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function apiBulkAction(Request $request): JsonResponse
    {
        try {
            $data = json_decode($request->getContent(), true) ?? [];

            $issueIds = $data['issue_ids'] ?? [];
            $action = $data['action'] ?? null;

            if (empty($issueIds)) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'No issue IDs provided',
                ], 400);
            }

            if (!in_array($action, ['fixed', 'ignored', 'open'])) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'Invalid action. Use: fixed, ignored, or open',
                ], 400);
            }

            $result = $this->issuesService->bulkUpdateStatus($issueIds, $action);

            if ($result['success']) {
                return new JsonResponse([
                    'success' => true,
                    'count' => $result['count'],
                    'message' => $result['message'],
                ]);
            }

            return new JsonResponse([
                'success' => false,
                'error' => $result['message'],
            ], 400);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Mark single issue as fixed
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function apiMarkFixed(Request $request, int $issueId): JsonResponse
    {
        try {
            $result = $this->issuesService->bulkUpdateStatus([$issueId], 'fixed');

            return new JsonResponse([
                'success' => $result['success'],
                'message' => $result['message'],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * API: Mark single issue as ignored
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function apiIgnore(Request $request, int $issueId): JsonResponse
    {
        try {
            $result = $this->issuesService->bulkUpdateStatus([$issueId], 'ignored');

            return new JsonResponse([
                'success' => $result['success'],
                'message' => $result['message'],
            ]);

        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
