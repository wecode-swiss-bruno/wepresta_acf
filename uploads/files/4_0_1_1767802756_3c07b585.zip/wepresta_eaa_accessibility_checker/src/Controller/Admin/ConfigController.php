<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Form\Type\ConfigType;
use Wepresta\EaaAccessibilityChecker\Service\ConfigService;
use Wepresta\EaaAccessibilityChecker\Service\DashboardService;

class ConfigController extends AbstractAdminController
{
    public function __construct(
        private readonly ConfigService $configService,
        private readonly DashboardService $dashboardService
    ) {
    }

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function index(Request $request): Response
    {
        $form = $this->createForm(ConfigType::class, $this->configService->getConfiguration());
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->configService->saveConfiguration($form->getData());
            $this->addFlash('success', $this->_t('Settings saved successfully.', [], 'Admin.Notifications.Success'));

            return $this->redirectToRoute('wepresta_eaa_config');
        }

        // Build AJAX URL for reset action using legacy controller
        $context = Context::getContext();
        $resetAjaxUrl = $context->link->getAdminLink('AdminWeprestaEaaAccessibility', true, [], [
            'ajax' => 1,
            'action' => 'resetAllData',
        ]);

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/config.html.twig', [
            'form' => $form->createView(),
            'resetAjaxUrl' => $resetAjaxUrl,
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => $this->_t('EAA Accessibility Checker', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
        ]);
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function toggleAutoFix(Request $request): JsonResponse
    {
        try {
            $data = json_decode($request->getContent(), true) ?? [];
            $enabled = (bool) ($data['enabled'] ?? false);

            // Get current config and update auto-fix settings
            $currentConfig = $this->configService->getConfiguration();
            $currentConfig['auto_fix_enabled'] = $enabled;
            $currentConfig['auto_fix_enabled_at'] = $enabled ? date('Y-m-d H:i:s') : null;

            $this->configService->saveConfiguration($currentConfig);

            return new JsonResponse([
                'success' => true,
                'auto_fix' => $this->dashboardService->getAutoFixData(),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
