<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Context;
use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Service\AccessibilityStatementService;

class AccessibilityStatementController extends AbstractAdminController
{
    public function __construct(
        private readonly AccessibilityStatementService $statementService
    ) {}

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function index(Request $request): Response
    {
        $context = Context::getContext();
        $shopId = (int) $context->shop->id;
        $selectedLangId = $request->query->getInt('lang', (int) $context->language->id);

        $statements = $this->statementService->getAllStatements($shopId);
        $currentStatement = $this->statementService->getStatement($shopId, $selectedLangId);
        $customTranslations = $this->statementService->getCustomTranslation($shopId, $selectedLangId);

        // Get available languages
        $languages = \Language::getLanguages(true, $shopId);

        // Generate module link for front controller
        $link = $context->link;
        $moduleLink = $link->getModuleLink('wepresta_eaa_accessibility_checker', 'accessibilitystatement', [], true);

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/accessibility_statement.html.twig', [
            'statements' => $statements,
            'currentStatement' => $currentStatement,
            'customTranslations' => $customTranslations,
            'languages' => $languages,
            'selectedLangId' => $selectedLangId,
            'moduleLink' => $moduleLink,
            'layoutTitle' => $this->_t('Accessibility Statement', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            'help_link' => false,
            'enableSidebar' => true,
        ]);
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function generate(Request $request): JsonResponse
    {
        try {
            $context = Context::getContext();
            $shopId = (int) $context->shop->id;
            $langId = $request->request->getInt('lang_id', (int) $context->language->id);

            $statement = $this->statementService->generateStatement($shopId, $langId);

            return new JsonResponse([
                'success' => true,
                'statement' => $statement,
                'message' => $this->_t('Accessibility statement generated successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function saveTranslation(Request $request): JsonResponse
    {
        try {
            $context = Context::getContext();
            $shopId = (int) $context->shop->id;
            $langId = $request->request->getInt('lang_id');
            $translations = $request->request->get('translations', []);

            $this->statementService->saveCustomTranslation($shopId, $langId, $translations);

            return new JsonResponse([
                'success' => true,
                'message' => $this->_t('Custom translations saved successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function togglePublished(Request $request): JsonResponse
    {
        try {
            $context = Context::getContext();
            $shopId = (int) $context->shop->id;
            $langId = $request->request->getInt('lang_id');
            $published = (bool) $request->request->getInt('published');

            $this->statementService->togglePublished($shopId, $langId, $published);

            return new JsonResponse([
                'success' => true,
                'message' => $published
                    ? $this->_t('Accessibility statement published successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin')
                    : $this->_t('Accessibility statement unpublished successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('delete', request.get('_legacy_controller'))")]
    public function delete(Request $request): JsonResponse
    {
        try {
            $context = Context::getContext();
            $shopId = (int) $context->shop->id;
            $langId = $request->request->getInt('lang_id');

            $this->statementService->deleteStatement($shopId, $langId);

            return new JsonResponse([
                'success' => true,
                'message' => $this->_t('Accessibility statement deleted successfully.', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin'),
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
