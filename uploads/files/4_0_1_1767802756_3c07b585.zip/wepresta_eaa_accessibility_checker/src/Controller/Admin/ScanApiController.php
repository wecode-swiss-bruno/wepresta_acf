<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Wepresta\EaaAccessibilityChecker\Service\ScanService;

class ScanApiController extends AbstractAdminController
{
    public function __construct(
        private readonly ScanService $scanService
    ) {
    }

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function results(): JsonResponse
    {
        try {
            $stats = $this->scanService->getDashboardStats();
            $latestScans = $this->scanService->getLatestScans(20);
            $activeSnapshot = $this->scanService->getActiveSnapshot();

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'stats' => $stats,
                    'scans' => $latestScans,
                    'snapshot' => $activeSnapshot,
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Start a new scan session (creates a new snapshot)
     * Call this before scanning multiple pages
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function startSession(Request $request): JsonResponse
    {
        try {
            $data = json_decode($request->getContent(), true) ?? [];
            $label = $data['label'] ?? 'Scan du ' . date('d/m/Y H:i');

            $snapshotId = $this->scanService->startNewScanSession($label);

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'snapshot_id' => $snapshotId,
                    'message' => 'Scan session started',
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Finish the current scan session (updates snapshot stats)
     * Call this after scanning all pages
     */
    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function finishSession(): JsonResponse
    {
        try {
            $this->scanService->finishScanSession();
            $snapshot = $this->scanService->getActiveSnapshot();

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'snapshot' => $snapshot,
                    'message' => 'Scan session finished',
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get snapshot history
     */
    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function history(): JsonResponse
    {
        try {
            $history = $this->scanService->getSnapshotHistory(10);
            $comparison = $this->scanService->getSnapshotComparison();

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'history' => $history,
                    'comparison' => $comparison,
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('update', request.get('_legacy_controller'))")]
    public function run(Request $request): JsonResponse
    {
        try {
            $data = json_decode($request->getContent(), true) ?? [];

            $url = $data['url'] ?? null;
            $pageType = $data['page_type'] ?? 'other';
            $axeResults = $data['axe_results'] ?? null;

            if (!$url) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'URL is required',
                ], 400);
            }

            if ($axeResults) {
                $result = $this->scanService->processAxeResults($axeResults, $url, $pageType);
            } else {
                $result = $this->scanService->scanUrl($url, $pageType);
            }

            return new JsonResponse([
                'success' => true,
                'data' => $result,
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function details(int $scanId): JsonResponse
    {
        try {
            $scan = $this->scanService->getScanDetails($scanId);

            if (!$scan) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'Scan not found',
                ], 404);
            }

            return new JsonResponse([
                'success' => true,
                'data' => $scan,
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('delete', request.get('_legacy_controller'))")]
    public function clearAll(): JsonResponse
    {
        try {
            $deletedCount = $this->scanService->clearAllScans();

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'deleted_count' => $deletedCount,
                    'message' => 'All scans have been cleared',
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }

    #[AdminSecurity("is_granted('delete', request.get('_legacy_controller'))")]
    public function delete(int $scanId): JsonResponse
    {
        try {
            $deleted = $this->scanService->deleteScan($scanId);

            if (!$deleted) {
                return new JsonResponse([
                    'success' => false,
                    'error' => 'Scan not found or could not be deleted',
                ], 404);
            }

            return new JsonResponse([
                'success' => true,
                'data' => [
                    'message' => 'Scan has been deleted successfully',
                    'scan_id' => $scanId,
                ],
            ]);
        } catch (\Exception $e) {
            return new JsonResponse([
                'success' => false,
                'error' => $e->getMessage(),
            ], 500);
        }
    }
}
