<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */


namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Security\Attribute\AdminSecurity;
use Symfony\Component\HttpFoundation\Response;
use Wepresta\EaaAccessibilityChecker\Service\ScanService;

class ScanDetailsController extends AbstractAdminController
{
    public function __construct(
        private readonly ScanService $scanService
    ) {}

    #[AdminSecurity("is_granted('read', request.get('_legacy_controller'))")]
    public function index(int $scanId): Response
    {
        $scan = $this->scanService->getScanDetails($scanId);

        if (!$scan) {
            throw $this->createNotFoundException('Scan not found');
        }

        // Enrichir et grouper les issues
        $issueGroups = $this->processIssues($scan['issues'] ?? []);

        // Calculer les statistiques
        $stats = $this->calculateStats($issueGroups);

        return $this->render('@Modules/wepresta_eaa_accessibility_checker/views/templates/admin/scan_details.html.twig', [
            'scan' => $scan,
            'issueGroups' => $issueGroups,
            'stats' => $stats,
            'help_link' => false,
            'enableSidebar' => true,
            'layoutTitle' => sprintf('Scan Details - %s', $scan['page_url']),
        ]);
    }

    /**
     * Traite et groupe les issues de manière intelligente
     */
    private function processIssues(array $issues): array
    {
        $grouped = [];

        foreach ($issues as $issue) {
            $ruleId = $issue['rule_id'] ?? 'unknown';
            $ruleInfo = $this->getWcagRuleInfo($ruleId);

            // Créer une entrée enrichie
            $enrichedIssue = [
                'id' => $issue['id_issue'] ?? null,
                'severity' => $issue['severity'] ?? 'moderate',
                'selector' => $issue['selector'] ?? '',
                'html_preview' => $this->formatHtmlPreview($issue['html_preview'] ?? $issue['selector'] ?? ''),
                'message' => $issue['message'] ?? '',
                'element_info' => $this->getElementInfo($issue),
            ];

            // Grouper par règle WCAG
            if (!isset($grouped[$ruleId])) {
                $grouped[$ruleId] = [
                    'rule_id' => $ruleId,
                    'title' => $ruleInfo['title'],
                    'description' => $ruleInfo['description'],
                    'wcag_criteria' => $ruleInfo['wcag_criteria'],
                    'severity' => $ruleInfo['severity'],
                    'why_important' => $ruleInfo['why_important'],
                    'how_to_fix' => $ruleInfo['how_to_fix'],
                    'code_examples' => $ruleInfo['code_examples'],
                    'resources' => $ruleInfo['resources'],
                    'issues' => [],
                    'count' => 0,
                ];
            }

            $grouped[$ruleId]['issues'][] = $enrichedIssue;
            $grouped[$ruleId]['count']++;
        }

        // Trier par sévérité puis par nombre d'issues
        uasort($grouped, function ($a, $b) {
            $severityOrder = ['critical' => 0, 'serious' => 1, 'moderate' => 2, 'minor' => 3];
            $aSev = $severityOrder[$a['severity']] ?? 4;
            $bSev = $severityOrder[$b['severity']] ?? 4;

            if ($aSev !== $bSev) {
                return $aSev - $bSev;
            }

            return $b['count'] - $a['count'];
        });

        return $grouped;
    }

    /**
     * Formate le HTML pour un affichage lisible
     */
    private function formatHtmlPreview(string $html): string
    {
        $decoded = htmlspecialchars_decode($html);
        // Limiter la longueur
        if (strlen($decoded) > 500) {
            $decoded = substr($decoded, 0, 500) . '...';
        }
        return $decoded;
    }

    /**
     * Extrait des informations utiles sur l'élément
     */
    private function getElementInfo(array $issue): array
    {
        $selector = $issue['selector'] ?? '';
        $html = htmlspecialchars_decode($issue['html_preview'] ?? '');

        $info = [
            'tag' => 'unknown',
            'id' => null,
            'classes' => [],
            'attributes' => [],
        ];

        // D'abord essayer d'extraire depuis le HTML
        if (preg_match('/<([a-zA-Z][a-zA-Z0-9]*)/i', $html, $m)) {
            $info['tag'] = strtolower($m[1]);
        }

        // Si pas de tag trouvé dans le HTML, essayer depuis le sélecteur CSS
        if ($info['tag'] === 'unknown' && !empty($selector)) {
            $info = $this->parseSelector($selector);
        }

        // Compléter avec les infos du HTML si disponibles
        if (!empty($html) && strpos($html, '<') !== false) {
            // Extraire l'ID depuis HTML
            if (preg_match('/id=["\']([^"\']+)["\']/', $html, $m)) {
                $info['id'] = $m[1];
            }

            // Extraire les classes depuis HTML (compléter celles du sélecteur)
            if (preg_match('/class=["\']([^"\']+)["\']/', $html, $m)) {
                $htmlClasses = array_filter(preg_split('/\s+/', $m[1]));
                $info['classes'] = array_unique(array_merge($info['classes'], $htmlClasses));
            }

            // Extraire les attributs importants depuis HTML
            $importantAttrs = ['src', 'href', 'alt', 'title', 'aria-label', 'role', 'type', 'name'];
            foreach ($importantAttrs as $attr) {
                if (preg_match("/{$attr}=[\"']([^\"']*)[\"']/i", $html, $m)) {
                    $info['attributes'][$attr] = $m[1];
                }
            }
        }

        return $info;
    }

    /**
     * Parse un sélecteur CSS pour extraire tag, id, classes et attributs
     * Ex: button.btn-close.me-2[type="button"] => tag=button, classes=[btn-close, me-2], attributes=[type=>button]
     */
    private function parseSelector(string $selector): array
    {
        $info = [
            'tag' => 'unknown',
            'id' => null,
            'classes' => [],
            'attributes' => [],
        ];

        // Nettoyer le sélecteur (prendre le dernier élément si c'est un chemin)
        if (strpos($selector, ' > ') !== false) {
            $parts = explode(' > ', $selector);
            $selector = end($parts);
        } elseif (strpos($selector, ' ') !== false) {
            $parts = explode(' ', $selector);
            $selector = end($parts);
        }

        // Extraire le tag (au début, avant tout . # ou [)
        if (preg_match('/^([a-zA-Z][a-zA-Z0-9]*)/i', $selector, $m)) {
            $info['tag'] = strtolower($m[1]);
        }

        // Extraire l'ID (#id)
        if (preg_match('/#([a-zA-Z0-9_-]+)/', $selector, $m)) {
            $info['id'] = $m[1];
        }

        // Extraire les classes (.class1.class2)
        if (preg_match_all('/\.([a-zA-Z0-9_-]+)/', $selector, $matches)) {
            $info['classes'] = $matches[1];
        }

        // Extraire les attributs ([attr="value"])
        if (preg_match_all('/\[([a-zA-Z-]+)(?:=["\']?([^"\'\]]*)["\']?)?\]/', $selector, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $attrName = $match[1];
                $attrValue = $match[2] ?? '';
                $info['attributes'][$attrName] = $attrValue;
            }
        }

        return $info;
    }

    /**
     * Calcule les statistiques du scan
     */
    private function calculateStats(array $issueGroups): array
    {
        $stats = [
            'total' => 0,
            'by_severity' => [
                'critical' => 0,
                'serious' => 0,
                'moderate' => 0,
                'minor' => 0,
            ],
            'rules_affected' => count($issueGroups),
        ];

        foreach ($issueGroups as $group) {
            $stats['total'] += $group['count'];
            $severity = $group['severity'];
            if (isset($stats['by_severity'][$severity])) {
                $stats['by_severity'][$severity] += $group['count'];
            }
        }

        return $stats;
    }

    /**
     * Retourne les informations complètes sur une règle WCAG
     */
    private function getWcagRuleInfo(string $ruleId): array
    {
        $rules = [
            'image-alt' => [
                'title' => 'Images must have alternative text',
                'description' => 'All images must have an alt attribute that describes the image content or function.',
                'wcag_criteria' => 'WCAG 2.1 - 1.1.1 Non-text Content (Level A)',
                'severity' => 'critical',
                'why_important' => 'Screen reader users cannot see images. Without alt text, they miss important information or don\'t understand the purpose of the image.',
                'how_to_fix' => [
                    'Add descriptive alt text for informative images',
                    'Use alt="" (empty) for purely decorative images',
                    'For complex images (charts, graphs), provide a longer description nearby',
                    'Don\'t start with "Image of..." - the user already knows it\'s an image',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<img src="product.jpg">', 'type' => 'bad'],
                    ['label' => 'Good (informative)', 'code' => '<img src="product.jpg" alt="Red leather handbag with gold clasp">', 'type' => 'good'],
                    ['label' => 'Good (decorative)', 'code' => '<img src="decoration.png" alt="">', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'W3C Images Tutorial', 'url' => 'https://www.w3.org/WAI/tutorials/images/'],
                    ['title' => 'Alt Decision Tree', 'url' => 'https://www.w3.org/WAI/tutorials/images/decision-tree/'],
                ],
            ],
            'button-name' => [
                'title' => 'Buttons must have accessible names',
                'description' => 'All buttons must have text content or an accessible name that describes their purpose.',
                'wcag_criteria' => 'WCAG 2.1 - 4.1.2 Name, Role, Value (Level A)',
                'severity' => 'serious',
                'why_important' => 'Screen reader users hear button names announced. Without a name, they don\'t know what the button does.',
                'how_to_fix' => [
                    'Add visible text inside the button',
                    'Use aria-label for icon-only buttons',
                    'Use aria-labelledby to reference visible text elsewhere',
                    'Ensure the accessible name describes the action',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<button type="button"><i class="icon-close"></i></button>', 'type' => 'bad'],
                    ['label' => 'Good (text)', 'code' => '<button type="button">Close</button>', 'type' => 'good'],
                    ['label' => 'Good (aria-label)', 'code' => '<button type="button" aria-label="Close dialog"><i class="icon-close"></i></button>', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Button Accessible Name', 'url' => 'https://www.w3.org/WAI/ARIA/apg/practices/names-and-descriptions/'],
                ],
            ],
            'link-name' => [
                'title' => 'Links must have accessible names',
                'description' => 'All links must have text or an accessible name that describes where they go.',
                'wcag_criteria' => 'WCAG 2.1 - 2.4.4 Link Purpose (Level A)',
                'severity' => 'serious',
                'why_important' => 'Screen reader users often navigate by links. Without descriptive text, they can\'t understand where a link leads.',
                'how_to_fix' => [
                    'Add descriptive link text',
                    'Avoid generic text like "Click here" or "Read more"',
                    'For image links, use alt text on the image',
                    'Use aria-label for icon-only links',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<a href="/products"><i class="icon-arrow"></i></a>', 'type' => 'bad'],
                    ['label' => 'Bad (generic)', 'code' => '<a href="/products">Click here</a>', 'type' => 'bad'],
                    ['label' => 'Good', 'code' => '<a href="/products">View all products</a>', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Link Purpose', 'url' => 'https://www.w3.org/WAI/WCAG21/Understanding/link-purpose-in-context.html'],
                ],
            ],
            'label' => [
                'title' => 'Form inputs must have labels',
                'description' => 'All form inputs must have associated labels that describe what information is expected.',
                'wcag_criteria' => 'WCAG 2.1 - 1.3.1 Info and Relationships (Level A)',
                'severity' => 'critical',
                'why_important' => 'Screen reader users need labels to understand what to enter in form fields. Without them, forms are unusable.',
                'how_to_fix' => [
                    'Add a <label> element with for="input-id"',
                    'Or wrap the input inside the label element',
                    'Use aria-label as a last resort',
                    'Placeholder is NOT a substitute for a label',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<input type="email" placeholder="Email">', 'type' => 'bad'],
                    ['label' => 'Good (for attribute)', 'code' => "<label for=\"email\">Email</label>\n<input type=\"email\" id=\"email\">", 'type' => 'good'],
                    ['label' => 'Good (wrapped)', 'code' => '<label>Email <input type="email"></label>', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Form Labels', 'url' => 'https://www.w3.org/WAI/tutorials/forms/labels/'],
                ],
            ],
            'html-has-lang' => [
                'title' => 'Page must have a language defined',
                'description' => 'The HTML element must have a valid lang attribute.',
                'wcag_criteria' => 'WCAG 2.1 - 3.1.1 Language of Page (Level A)',
                'severity' => 'serious',
                'why_important' => 'Screen readers use the language attribute to pronounce content correctly. Without it, content may be mispronounced.',
                'how_to_fix' => [
                    'Add lang attribute to the <html> element',
                    'Use valid ISO language codes (en, fr, de, etc.)',
                    'Match the primary language of the page content',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<html>', 'type' => 'bad'],
                    ['label' => 'Good (English)', 'code' => '<html lang="en">', 'type' => 'good'],
                    ['label' => 'Good (French)', 'code' => '<html lang="fr">', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Language Attribute', 'url' => 'https://www.w3.org/International/questions/qa-html-language-declarations'],
                ],
            ],
            'page-has-heading-one' => [
                'title' => 'Page must have a main heading (H1)',
                'description' => 'Each page should have exactly one H1 heading that describes the page content.',
                'wcag_criteria' => 'WCAG 2.1 - 1.3.1 Info and Relationships (Level A)',
                'severity' => 'moderate',
                'why_important' => 'Screen reader users use headings to navigate and understand page structure. The H1 tells them what the page is about.',
                'how_to_fix' => [
                    'Add a single H1 heading at the start of main content',
                    'Make sure the H1 describes the page purpose',
                    'Don\'t skip heading levels (H1 → H2 → H3)',
                    'Don\'t use multiple H1 elements on a single page',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<div class="title">Product Page</div>', 'type' => 'bad'],
                    ['label' => 'Good', 'code' => '<h1>Summer Collection Dresses</h1>', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Headings', 'url' => 'https://www.w3.org/WAI/tutorials/page-structure/headings/'],
                ],
            ],
            'skip-link' => [
                'title' => 'Page should have a skip navigation link',
                'description' => 'A skip link allows keyboard users to bypass repetitive navigation.',
                'wcag_criteria' => 'WCAG 2.1 - 2.4.1 Bypass Blocks (Level A)',
                'severity' => 'moderate',
                'why_important' => 'Keyboard users must tab through every link in navigation before reaching main content. Skip links let them jump directly to content.',
                'how_to_fix' => [
                    'Add a skip link as the first focusable element',
                    'Link it to the main content area with id="main-content"',
                    'Make it visible on focus (can be visually hidden otherwise)',
                ],
                'code_examples' => [
                    ['label' => 'Good', 'code' => "<a href=\"#main-content\" class=\"skip-link\">Skip to content</a>\n...\n<main id=\"main-content\">", 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Skip Links', 'url' => 'https://www.w3.org/WAI/WCAG21/Techniques/general/G1'],
                ],
            ],
            'color-contrast' => [
                'title' => 'Text must have sufficient color contrast',
                'description' => 'Text must have a contrast ratio of at least 4.5:1 against its background (3:1 for large text).',
                'wcag_criteria' => 'WCAG 2.1 - 1.4.3 Contrast (Minimum) (Level AA)',
                'severity' => 'serious',
                'why_important' => 'Users with low vision or color blindness may not be able to read text with insufficient contrast.',
                'how_to_fix' => [
                    'Use a contrast checker tool to verify ratios',
                    'Increase the darkness of text or lightness of background',
                    'Avoid light gray text on white backgrounds',
                    'Large text (18pt+ or 14pt+ bold) only needs 3:1 ratio',
                ],
                'code_examples' => [
                    ['label' => 'Bad', 'code' => '<p style="color: #999; background: #fff;">Low contrast text</p>', 'type' => 'bad'],
                    ['label' => 'Good', 'code' => '<p style="color: #333; background: #fff;">High contrast text</p>', 'type' => 'good'],
                ],
                'resources' => [
                    ['title' => 'Contrast Checker', 'url' => 'https://webaim.org/resources/contrastchecker/'],
                ],
            ],
        ];

        return $rules[$ruleId] ?? [
            'title' => ucfirst(str_replace('-', ' ', $ruleId)),
            'description' => 'Accessibility issue detected',
            'wcag_criteria' => 'WCAG 2.1',
            'severity' => 'moderate',
            'why_important' => 'This affects accessibility for some users.',
            'how_to_fix' => ['Review the element and ensure it meets accessibility standards.'],
            'code_examples' => [],
            'resources' => [
                ['title' => 'WCAG Guidelines', 'url' => 'https://www.w3.org/WAI/WCAG21/quickref/'],
            ],
        ];
    }
}
