<?php
/**
 * AbstractAdminController.php
 *
 * @author     WePresta
 * @copyright  2024 WePresta
 * @license    https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 * @package    Wepresta\EaaAccessibilityChecker\Controller\Admin
 */

namespace Wepresta\EaaAccessibilityChecker\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */



use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\JsonResponse;

/**
 * Abstract controller compatible with all PS 8.x and 9.x versions.
 *
 * Uses FrameworkBundleAdminController as base (available in all PS 8+ versions)
 * and provides a custom translation method that bypasses the problematic
 * Symfony translator service locator.
 */
abstract class AbstractAdminController extends FrameworkBundleAdminController
{
    /**
     * Ensure the module autoloader is loaded before controller instantiation.
     */
    public static function ensureAutoloaderLoaded(): void
    {
        static $autoloaderLoaded = false;
        if ($autoloaderLoaded) {
            return;
        }

        $vendorAutoload = dirname(__DIR__, 3) . '/vendor/autoload.php';
        if (file_exists($vendorAutoload)) {
            require_once $vendorAutoload;
        }

        $autoloaderLoaded = true;
    }

    /**
     * Constructor - ensures autoloader is loaded.
     */
    public function __construct()
    {
        self::ensureAutoloaderLoaded();
        parent::__construct();
    }

    private static ?\Module $moduleInstance = null;

    /**
     * Compatibility helper for JSON responses.
     */
    protected function ajaxDie($payload): JsonResponse
    {
        if ($payload instanceof JsonResponse) {
            return $payload;
        }

        if (is_string($payload)) {
            return new JsonResponse($payload, 200, [], true);
        }

        return new JsonResponse($payload);
    }

    /**
     * Get the module instance for translations.
     */
    private function getModuleInstance(): \Module
    {
        if (self::$moduleInstance === null) {
            self::$moduleInstance = \Module::getInstanceByName('wepresta_eaa_accessibility_checker');
        }

        return self::$moduleInstance;
    }

    /**
     * Translation method that works on ALL PrestaShop versions.
     * 
     * Uses the module's native l() method instead of Symfony's translator
     * to avoid service locator issues.
     *
     * @param string $id The string to translate
     * @param array $parameters Replacement parameters (sprintf style: %s, or named: %name%)
     * @param string|null $domain Translation domain (ignored, kept for signature compatibility)
     * @return string Translated string
     */
    protected function _t(string $id, array $parameters = [], ?string $domain = null): string
    {
        $module = $this->getModuleInstance();
        
        // Use module's l() method for translation
        // @phpstan-ignore-next-line
        $translated = $module->l($id);
        
        // Handle parameter replacement
        if (!empty($parameters)) {
            // Support both sprintf style (%s) and named parameters (%name%)
            foreach ($parameters as $key => $value) {
                if (is_string($key)) {
                    $translated = str_replace($key, (string) $value, $translated);
                }
            }
            
            // If there are still %s or %d patterns, use sprintf
            if (preg_match('/%[sd]/', $translated)) {
                $translated = sprintf($translated, ...array_values($parameters));
            }
        }
        
        return $translated;
    }
}
