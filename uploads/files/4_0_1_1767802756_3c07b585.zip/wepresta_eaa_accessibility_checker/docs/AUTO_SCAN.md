# Configuration des Scans Automatiques

Ce guide explique comment configurer et utiliser la fonctionnalité de scans automatiques d'accessibilité.

## 📋 Vue d'ensemble

Les scans automatiques permettent de surveiller continuellement la conformité d'accessibilité de votre boutique selon un calendrier personnalisé. Ils détectent automatiquement les nouveaux problèmes et peuvent envoyer des rapports par email.

## ⚙️ Configuration via l'interface

### Accès à la configuration

1. Connectez-vous au back-office PrestaShop
2. Allez dans **Modules > Module Manager**
3. Trouvez **EAA Accessibility Checker**
4. Cliquez sur **Configurer** ou accédez au dashboard
5. Dans la section **Quick Actions**, cliquez sur **Schedule Auto-Scan**
6. Cliquez sur **Configure**

### Paramètres disponibles

#### 🔄 Fréquence
- **Quotidienne** : Scan tous les jours
- **Hebdomadaire** : Scan une fois par semaine (choisissez le jour)
- **Mensuelle** : Scan une fois par mois (choisissez le jour du mois)

#### 🕐 Heure d'exécution
- Choisissez l'heure (0h à 23h) où le scan doit s'exécuter
- **Conseil** : Préférez les heures creuses (ex: 3h du matin) pour éviter l'impact sur les performances

#### 📅 Jour (selon fréquence)
- **Hebdomadaire** : Lundi, Mardi, Mercredi, Jeudi, Vendredi, Samedi, Dimanche
- **Mensuelle** : Jour du mois (1 à 28)

#### 📧 Notifications email
- Cochez pour recevoir un rapport automatique
- L'email de l'employé connecté est pré-rempli
- Le rapport est envoyé après chaque scan réussi

## 🖥️ Configuration serveur (obligatoire)

### Prérequis
Votre hébergement doit permettre l'exécution de tâches cron (cron jobs).

### Commande cron à ajouter

Votre hébergeur doit ajouter cette ligne à la configuration cron :

```bash
# Exemple pour exécution quotidienne à 3h du matin
0 3 * * * /usr/bin/php /chemin/vers/prestashop/modules/wepresta_eaa_accessibility_checker/cron.php
```

### Exemples de configuration

```bash
# Tous les jours à 3h du matin
0 3 * * * /usr/bin/php /home/user/public_html/modules/wepresta_eaa_accessibility_checker/cron.php

# Tous les lundis à 2h du matin
0 2 * * 1 /usr/bin/php /var/www/prestashop/modules/wepresta_eaa_accessibility_checker/cron.php

# Le 1er de chaque mois à 4h du matin
0 4 1 * * /usr/bin/php /usr/local/www/modules/wepresta_eaa_accessibility_checker/cron.php
```

### Comment obtenir le chemin correct

Le chemin doit pointer vers le fichier `cron.php` du module. Exemples :

- **cPanel/DirectAdmin** : `/home/username/public_html/modules/wepresta_eaa_accessibility_checker/cron.php`
- **Plesk** : `/var/www/vhosts/domain.com/httpdocs/modules/wepresta_eaa_accessibility_checker/cron.php`
- **Serveur dédié** : `/var/www/html/prestashop/modules/wepresta_eaa_accessibility_checker/cron.php`

Demandez à votre hébergeur si vous n'êtes pas sûr du chemin.

## 🔍 Fonctionnement automatique

### Quand le scan s'exécute

Le script cron vérifie automatiquement :
- ✅ Si les scans automatiques sont activés
- ✅ Si c'est le bon moment selon la fréquence configurée
- ✅ Si c'est la bonne heure

### Pages scannées

Le scan automatique analyse ces pages par défaut :
- 🏠 Page d'accueil
- 🛒 Page panier
- 📞 Page contact
- 📁 3 premières catégories
- 📦 3 premiers produits
- 📄 2 premières pages CMS

### Résultats

Après chaque scan :
- 📊 Score de conformité mis à jour
- 🐛 Nouveaux problèmes détectés
- 📈 Historique enrichi
- 📧 Email envoyé si activé

## 📧 Rapport par email

### Contenu du rapport

```
Objet : [Votre Boutique] Rapport de scan d'accessibilité - 15 déc. 2024

Résultats du scan :
- Score de conformité : 87%
- Nouveaux problèmes détectés : 3
- Pages scannées avec succès : 8
- Pages en échec de scan : 0

Voir le rapport complet : [lien vers dashboard]
```

### Fréquence d'envoi

- Un email par scan réussi
- Seulement si les notifications sont activées
- Même si aucun nouveau problème n'est détecté

## 🚨 Dépannage

### Le cron ne s'exécute pas

1. **Vérifiez la configuration cron** auprès de votre hébergeur
2. **Testez manuellement** : `php cron.php` depuis le serveur
3. **Vérifiez les logs** : `modules/wepresta_eaa_accessibility_checker/logs/cron.log`
4. **Permissions** : Assurez-vous que PHP peut écrire dans le dossier logs

### Erreur "Command not found"

Votre hébergeur utilise peut-être un autre chemin PHP :
```bash
# Essayez ces alternatives :
/usr/local/bin/php
/opt/cpanel/ea-php74/root/usr/bin/php
/usr/bin/php7.4
```

### Pas de rapport email

1. Vérifiez que les notifications sont activées
2. Vérifiez l'adresse email configurée
3. Vérifiez les logs d'erreur PHP/mail du serveur

### Scan trop lent

- Réduisez la fréquence (hebdomadaire au lieu de quotidienne)
- Choisissez une heure creuse
- Contactez votre hébergeur pour les limites de ressources

## 🔧 Support technique

Si vous rencontrez des problèmes :

1. **Vérifiez les logs** : `logs/cron.log`
2. **Testez manuellement** le script cron
3. **Vérifiez la configuration** dans PrestaShop
4. **Contactez le support** avec les logs d'erreur

## 💡 Conseils d'optimisation

- **Fréquence** : Commencez par hebdomadaire pour tester
- **Heure** : 2h-4h du matin (trafic faible)
- **Notifications** : Activez pour rester informé
- **Monitoring** : Vérifiez régulièrement le dashboard

---

*Dernière mise à jour : Décembre 2024*
