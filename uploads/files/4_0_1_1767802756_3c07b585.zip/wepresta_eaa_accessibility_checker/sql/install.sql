-- =========================================================================
-- WEPRESTA EAA ACCESSIBILITY CHECKER - DATABASE TABLES
-- =========================================================================

-- Snapshots table: stores scan sessions (each full scan creates one snapshot)
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_snapshots` (
  `id_snapshot` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `label` VARCHAR(100) DEFAULT NULL,
  `total_pages` SMALLINT UNSIGNED DEFAULT 0,
  `total_issues` SMALLINT UNSIGNED DEFAULT 0,
  `issues_by_severity` TEXT DEFAULT NULL,
  `avg_score` DECIMAL(5,2) DEFAULT 0,
  `is_active` TINYINT(1) DEFAULT 0,
  `id_shop` INT UNSIGNED DEFAULT 1,
  `date_add` DATETIME NOT NULL,
  INDEX `idx_active` (`is_active`),
  INDEX `idx_shop` (`id_shop`),
  INDEX `idx_date` (`date_add`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Scans table: stores accessibility scan results per page
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_scans` (
  `id_scan` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `id_snapshot` INT UNSIGNED DEFAULT NULL,
  `page_url` VARCHAR(512) NOT NULL,
  `page_type` ENUM('home','category','product','cms','checkout','other') NOT NULL DEFAULT 'other',
  `score` TINYINT UNSIGNED DEFAULT 0,
  `issues_count` SMALLINT UNSIGNED DEFAULT 0,
  `date_add` DATETIME NOT NULL,
  INDEX `idx_snapshot` (`id_snapshot`),
  INDEX `idx_page_type` (`page_type`),
  INDEX `idx_date` (`date_add`),
  FOREIGN KEY (`id_snapshot`) REFERENCES `PREFIX_wepresta_eaa_snapshots`(`id_snapshot`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Issues table: stores individual accessibility issues found during scans
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_issues` (
  `id_issue` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `id_scan` INT UNSIGNED NOT NULL,
  `rule_id` VARCHAR(64) NOT NULL,
  `severity` ENUM('critical','serious','moderate','minor') NOT NULL DEFAULT 'moderate',
  `selector` VARCHAR(512),
  `message` TEXT,
  `fixed` TINYINT(1) DEFAULT 0,
  `ignored` TINYINT(1) DEFAULT 0,
  `date_add` DATETIME NOT NULL,
  INDEX `idx_scan` (`id_scan`),
  INDEX `idx_severity` (`severity`),
  INDEX `idx_rule` (`rule_id`),
  INDEX `idx_fixed` (`fixed`),
  INDEX `idx_ignored` (`ignored`),
  FOREIGN KEY (`id_scan`) REFERENCES `PREFIX_wepresta_eaa_scans`(`id_scan`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Manual checks table: stores manual WCAG verification statuses
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_manual_check` (
  `id_manual_check` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  `wcag_criterion` VARCHAR(10) NOT NULL,
  `status` ENUM('pending','compliant','non_compliant','not_applicable') DEFAULT 'pending',
  `notes` TEXT,
  `verification_guide` TEXT,
  `verified_by` INT UNSIGNED DEFAULT NULL,
  `verified_at` DATETIME DEFAULT NULL,
  `id_shop` INT UNSIGNED DEFAULT 1,
  `date_add` DATETIME NOT NULL,
  `date_upd` DATETIME,
  UNIQUE KEY `idx_criterion_shop` (`wcag_criterion`, `id_shop`),
  INDEX `idx_status` (`status`),
  INDEX `idx_shop` (`id_shop`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Accessibility statements table: stores generated accessibility statements per language
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_statements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_shop` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `shop_name` varchar(255) NOT NULL,
  `shop_url` varchar(255) NOT NULL,
  `generated_at` datetime NOT NULL,
  `compliance_score` decimal(5,2) NOT NULL,
  `last_audit_date` datetime DEFAULT NULL,
  `total_issues` int(11) NOT NULL DEFAULT 0,
  `contact_email` varchar(255) DEFAULT NULL,
  `contact_phone` varchar(32) DEFAULT NULL,
  `content` longtext NOT NULL,
  `published` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `id_shop` (`id_shop`),
  KEY `id_lang` (`id_lang`),
  KEY `generated_at` (`generated_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Accessibility statement translations table: stores custom translations per language
CREATE TABLE IF NOT EXISTS `PREFIX_wepresta_eaa_statement_translations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_shop` int(11) NOT NULL,
  `id_lang` int(11) NOT NULL,
  `translations` longtext NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_shop_lang` (`id_shop`, `id_lang`),
  KEY `id_lang` (`id_lang`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Default module configuration
INSERT IGNORE INTO `PREFIX_configuration` (`id_shop_group`, `id_shop`, `name`, `value`, `date_add`, `date_upd`) VALUES
(NULL, NULL, 'WEPRESTA_EAA_AUTO_FIX_ENABLED', '0', NOW(), NOW()),
(NULL, NULL, 'WEPRESTA_EAA_AUTO_FIX_ENABLED_AT', NULL, NOW(), NOW());
