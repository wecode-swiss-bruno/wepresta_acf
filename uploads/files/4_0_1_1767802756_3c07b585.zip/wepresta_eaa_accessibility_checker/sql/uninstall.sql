-- =========================================================================
-- WEPRESTA EAA ACCESSIBILITY CHECKER - UNINSTALL
-- =========================================================================

-- Disable foreign key checks to allow table drops
SET FOREIGN_KEY_CHECKS = 0;

-- Drop tables in correct order (respecting FK constraints)
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_issues`;
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_scans`;
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_snapshots`;
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_manual_check`;
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_statements`;
DROP TABLE IF EXISTS `PREFIX_wepresta_eaa_statement_translations`;

-- Re-enable foreign key checks
SET FOREIGN_KEY_CHECKS = 1;

-- Remove configuration
DELETE FROM `PREFIX_configuration` WHERE `name` LIKE 'WEPRESTA_EAA_%';
