<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

// Load module autoloader - use vendor autoload directly
$vendorAutoload = __DIR__ . '/vendor/autoload.php';
if (file_exists($vendorAutoload)) {
    require_once $vendorAutoload;
}

use Wepresta\EaaAccessibilityChecker\DependencyInjection\WeprestaEaaAccessibilityCheckerExtension;

class Wepresta_Eaa_Accessibility_Checker extends Module
{
    private const CONFIG_PREFIX = 'WEPRESTA_EAA_';

    private const HOOKS = [
        'displayHeader',
        'actionFrontControllerSetMedia',
        'actionAdminControllerSetMedia',
    ];

    public function __construct()
    {
        $this->name = 'wepresta_eaa_accessibility_checker';
        $this->tab = 'administration';
        $this->version = '1.0.1';
        $this->author = 'WePresta';
        $this->need_instance = 0;
        $this->ps_versions_compliancy = [
            'min' => '8.0.0',
            'max' => '9.99.99',
        ];
        $this->module_key = '8c73f0d3b43bdfa692b39859f96c6a70';
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->trans('EAA Accessibility Checker Pro', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin');
        $this->description = $this->trans('European Accessibility Act compliance checker for PrestaShop', [], 'Modules.Weprestaeaaaccessibilitychecker.Admin');
    }

    public function install(): bool
    {
        $result = parent::install()
            && $this->registerHooks()
            && $this->installDatabase()
            && $this->installNpmDependencies();

        if ($result) {
            $this->clearSymfonyCache();
        }

        return $result;
    }

    public function uninstall(): bool
    {
        return $this->uninstallDatabase()
            && $this->deleteConfiguration()
            && parent::uninstall();
    }

    private function registerHooks(): bool
    {
        foreach (self::HOOKS as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }
        return true;
    }

    public function isUsingNewTranslationSystem(): bool
    {
        return true;
    }

    /**
     * Get the Symfony DI extension for this module.
     * 
     * This method returns the Extension class that PrestaShop will use
     * to load the module's services and controllers.
     * 
     * The Extension class is located in src/DependencyInjection/ and ensures
     * the autoloader is registered before Symfony parses the container.
     * 
     * @return WeprestaEaaAccessibilityCheckerExtension
     */
    public function getContainerExtension(): WeprestaEaaAccessibilityCheckerExtension
    {
        return new WeprestaEaaAccessibilityCheckerExtension();
    }

    /**
     * Get the configuration URL for this module.
     * Redirects to legacy controller which will handle Symfony routing.
     */
    private function getConfigUrl(): string
    {
        try {
            // Use legacy controller URL - it will redirect to Symfony routes
            return $this->context->link->getAdminLink('AdminWeprestaEaaAccessibility');
        } catch (\Throwable $e) {
            // Fallback if link generation fails
        }

        // Fallback: return empty string to show configuration form
        return '';
    }

    public function getContent(): string
    {
         // Ensure Symfony cache is cleared for proper route registration
         $this->ensureTabsRegistered();

         $target = (string) $this->getConfigUrl();

         // If we can't build a target, show fallback
         if ($target === '') {
             // Check if we already tried to clear cache (prevent infinite loop)
             $retryParam = (int) Tools::getValue('_pl_retry', 0);

             if ($retryParam < 1) {
                 // Clear cache using PrestaShop's native method
                 if (method_exists(\Tools::class, 'clearSf2Cache')) {
                     \Tools::clearSf2Cache();
                 }

                 // Redirect to self with retry param to force cache rebuild
                 $retryUrl = $this->context->link->getAdminLink('AdminModules', true, [], [
                     'configure' => $this->name,
                     '_pl_retry' => 1,
                 ]);

                 Tools::redirectAdmin($retryUrl);
                 return ''; // This line won't be reached due to redirect, but needed for type safety
             }

             // Already retried - show fallback
             $cacheUrl = '';
             try {
                 $cacheUrl = $this->context->link->getAdminLink('AdminPerformance');
             } catch (\Throwable $e) {
                 // ignore
             }
         }

         // Redirect to legacy controller which will handle Symfony routing
         Tools::redirectAdmin($target);
         return ''; // This line won't be reached due to redirect, but needed for type safety
    }

    /**
     * Clear Symfony cache to register module routes
     */
    private function clearSymfonyCache(): void
    {
        try {
            if (class_exists(\Tools::class) && method_exists(\Tools::class, 'clearSf2Cache')) {
                \Tools::clearSf2Cache();
            }
            if (class_exists(\Tab::class) && method_exists(\Tab::class, 'resetStaticCache')) {
                \Tab::resetStaticCache();
            }
        } catch (\Throwable $e) {
            // Ignore errors
        }
    }

    /**
     * Hook: displayHeader - Add skip links and auto-fix JavaScript
     */
    public function hookDisplayHeader(array $params): string
    {
        $output = '';

        // Auto-fix: Add skip links and JavaScript fixes
        if (Configuration::get(self::CONFIG_PREFIX . 'AUTO_FIX_ENABLED')) {
            // Create configuration for accessibility fixes
            $moduleFixesConfig = [
                'skipLinks' => [
                    'enabled' => true
                ],
                'autoFixes' => [
                    'missingAlt' => true,
                    'contrast' => true,
                    'focus' => true
                ]
            ];

            // Use Smarty template with configuration
            $this->context->smarty->assign([
                'module_fixes_config' => json_encode($moduleFixesConfig),
                'module_path' => $this->_path
            ]);

            $output = $this->fetch('module:wepresta_eaa_accessibility_checker/views/templates/hook/skip-links.tpl');
        }

        return $output;
    }

    /**
     * Hook: actionFrontControllerSetMedia - Register front assets
     */
    public function hookActionFrontControllerSetMedia(array $params): void
    {
        $modulePath = $this->_path;

        // Load CSS and JS for auto-fixes
        if (Configuration::get(self::CONFIG_PREFIX . 'AUTO_FIX_ENABLED')) {
            $this->context->controller->registerStylesheet(
                'wepresta-eaa-front',
                $modulePath . 'views/css/fixes.css',
                ['media' => 'all', 'priority' => 200]
            );

            $this->context->controller->registerJavascript(
                'wepresta-eaa-accessibility-fixes',
                $modulePath . 'views/js/accessibility-fixes.js',
                ['position' => 'bottom', 'priority' => 200]
            );
        }
    }


    /**
     * Hook: actionAdminControllerSetMedia - Register admin assets
     */
    public function hookActionAdminControllerSetMedia(array $params): void
    {
        // Only register assets if controller supports it (legacy controllers)
        if ($this->supportsAssetRegistration()) {
            $this->registerLegacyAssets();
        }
    }

    /**
     * Check if current controller supports asset registration
     */
    private function supportsAssetRegistration(): bool
    {
        return $this->context->controller instanceof AdminController
            && method_exists($this->context->controller, 'registerStylesheet')
            && method_exists($this->context->controller, 'registerJavascript')
            && !$this->context->controller instanceof \PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
    }

    /**
     * Register assets for legacy controllers
     */
    private function registerLegacyAssets(): void
    {
        $modulePath = $this->_path;

        // Load admin CSS
        $this->context->controller->registerStylesheet(
            'wepresta-eaa-admin',
            $modulePath . 'views/css/admins.css',
            ['media' => 'all', 'priority' => 200]
        );

        // Load admin JavaScript
        $this->context->controller->registerJavascript(
            'wepresta-eaa-admin',
            $modulePath . 'views/js/admin.js',
            ['position' => 'bottom', 'priority' => 200]
        );
    }


    private function installDatabase(): bool
    {
        $sqlFile = dirname(__FILE__) . '/sql/install.sql';
        if (!file_exists($sqlFile)) {
            return true;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = preg_split('/;\s*[\r\n]+/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                if (!Db::getInstance()->execute($query)) {
                    return false;
                }
            }
        }

        return true;
    }

    private function installNpmDependencies(): bool
    {
        $packageJsonPath = $this->getLocalPath() . 'package.json';
        
        // Vérifier si package.json existe
        if (!file_exists($packageJsonPath)) {
            // Pas de dépendances npm, continuer
            return true;
        }
        
        // Vérifier si npm est disponible
        $npmCommand = 'npm --version 2>&1';
        exec($npmCommand, $output, $returnCode);
        
        if ($returnCode !== 0) {
            // npm n'est pas installé sur le serveur
            $this->_errors[] = $this->trans(
                'npm is not installed on this server. Please install Node.js and npm to use all features of this module.',
                [],
                'Modules.Weprestaeaaaccessibilitychecker.Admin'
            );
            // Ne pas bloquer l'installation pour autant
            return true;
        }
        
        // Exécuter npm install
        $installCommand = 'cd ' . escapeshellarg(dirname($packageJsonPath)) . ' && npm install 2>&1';
        exec($installCommand, $output, $returnCode);
        
        if ($returnCode !== 0) {
            $this->_errors[] = $this->trans(
                'Failed to install npm dependencies. You may need to run "npm install" manually in the module directory.',
                [],
                'Modules.Weprestaeaaaccessibilitychecker.Admin'
            );
            // Ne pas bloquer l'installation
            return true;
        }
        
        return true;
    }

    private function uninstallDatabase(): bool
    {
        $sqlFile = dirname(__FILE__) . '/sql/uninstall.sql';
        if (!file_exists($sqlFile)) {
            return true;
        }

        $sql = file_get_contents($sqlFile);
        $sql = str_replace('PREFIX_', _DB_PREFIX_, $sql);
        $queries = preg_split('/;\s*[\r\n]+/', $sql);

        foreach ($queries as $query) {
            $query = trim($query);
            if (!empty($query)) {
                Db::getInstance()->execute($query);
            }
        }

        return true;
    }

    private function deleteConfiguration(): bool
    {
        Configuration::deleteByName(self::CONFIG_PREFIX . 'AUTO_FIX_ENABLED');
        return true;
    }

    /**
     * Ensure Symfony cache is cleared for proper route registration.
     * Tabs are not used in this module - only Symfony routes.
     */
    private function ensureTabsRegistered(): void
    {
        try {
            // Clear Symfony cache to ensure routes are properly registered
            if (class_exists(\Tools::class) && method_exists(\Tools::class, 'clearSf2Cache')) {
                \Tools::clearSf2Cache();
            }
        } catch (\Throwable $e) {
            // ignore
        }
    }

}
