<?php
/**
 * Copyright since 2024 WePresta
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Academic Free License 3.0 (AFL-3.0)
 * that is bundled with this package in the file LICENSE.md.
 *
 * @author    WePresta <mail@wepresta.shop>
 * @copyright Since 2024 WePresta
 * @license   https://opensource.org/licenses/AFL-3.0 Academic Free License 3.0 (AFL-3.0)
 */

if (!defined('_PS_VERSION_')) {
    exit;
}
/**
 * Bootstrap file loaded by Symfony when importing service definitions.
 *
 * Purpose: ensure the module autoloader (Composer PSR-4) is registered
 * before Symfony tries to reflect/instantiate services (controllers, event subscribers, etc.).
 * 
 * This file is imported by both config/services.yml and config/admin/services.yml
 * to ensure proper autoloading for both PrestaShop 8 and 9.
 */

$modulePath = dirname(__DIR__);

$composerAutoload = $modulePath . '/vendor/autoload.php';
$moduleAutoload = $modulePath . '/autoload.php';

// When the container is being compiled, _PS_VERSION_ may not be defined yet.
// Some module files may rely on it, so we define a safe placeholder.
if (!defined('_PS_VERSION_')) {
    define('_PS_VERSION_', '0.0.0');
}

// Load Composer autoloader first (preferred)
if (is_file($composerAutoload)) {
    require_once $composerAutoload;
}

// Load module autoloader as fallback
if (is_file($moduleAutoload)) {
    require_once $moduleAutoload;
}
