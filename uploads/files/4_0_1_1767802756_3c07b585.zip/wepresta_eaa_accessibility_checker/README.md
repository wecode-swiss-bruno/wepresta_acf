# EAA Accessibility Checker

Module PrestaShop 8+ pour la conformité à l'European Accessibility Act (EAA) et WCAG 2.1 AA.

## Fonctionnalités

### Audit & Diagnostic
- Scanner hybride WCAG (axe-core JS + validation PHP)
- Dashboard de conformité avec scores par section
- Historique des scans avec évolution dans le temps
- Détection : contraste, alt manquants, labels, navigation clavier

### Corrections automatiques
- Skip links (liens d'évitement)
- Focus visible renforcé
- Minimum touch target (44x44px)
- Support `prefers-reduced-motion`

### Widget Quick Fix (visiteurs)
- Taille de police ajustable
- Modes de contraste (normal, élevé, inversé)
- Espacement du texte
- Désactivation des animations
- Raccourci clavier Alt+A

### Outils marchand
- Checklist EAA interactive (25 critères WCAG 2.1 AA)
- Éditeur d'alt text en masse
- Génération automatique depuis noms produits
- Scans automatiques programmables

### Scans automatiques

Le module permet de programmer des scans d'accessibilité automatiques selon un calendrier personnalisé.

#### Configuration

1. Accéder au dashboard du module
2. Cliquer sur "Schedule Auto-Scan" > "Configure"
3. Configurer :
   - **Fréquence** : Quotidienne / Hebdomadaire / Mensuelle
   - **Heure** : Heure d'exécution (0h-23h)
   - **Jour** : Jour de semaine (hebdomadaire) ou du mois (mensuel)
   - **Notifications** : Email de rapport automatique

#### Configuration serveur requise

Pour que les scans automatiques fonctionnent, votre hébergeur doit configurer un cron job :

```bash
# Exemple : exécution quotidienne à 3h du matin
0 3 * * * /usr/bin/php /chemin/vers/prestashop/modules/wepresta_eaa_accessibility_checker/cron.php
```

**⚠️ Important :** Remplacez `/chemin/vers/prestashop` par le chemin absolu réel de votre installation PrestaShop.

#### Dépannage : "le scan ne fetch pas les URLs"

Le scan récupère le HTML des pages **depuis le serveur** (PHP). Si le serveur ne peut pas faire de requêtes HTTP/HTTPS sortantes, les pages ne seront pas scannées.

- **Pré-requis PHP** (au moins un des deux) :
  - `ext-curl` (recommandé)
  - ou `allow_url_fopen=On`
- **Réseau / sécurité** :
  - autoriser les connexions sortantes HTTPS vers le domaine de la boutique (ou le domaine scanné)
  - si la boutique est protégée (basic auth, firewall, maintenance, Cloudflare "challenge"), il faut **whitelister** le serveur ou désactiver la protection pendant le scan


#### Fonctionnement automatique

Une fois configuré :
- ✅ Le script vérifie automatiquement la fréquence configurée
- ✅ Il scanne les pages importantes (accueil, produits, catégories, contact)
- ✅ Il envoie un rapport par email si activé
- ✅ Il met à jour le dashboard avec les nouveaux résultats

#### Pages scannées automatiquement

- Page d'accueil
- Page panier
- Page contact
- 3 premières catégories
- 3 premiers produits
- Pages CMS (2 maximum)

#### Rapport email

Le rapport automatique contient :
- Score de conformité actuel
- Nombre de nouveaux problèmes détectés
- Pages scannées avec succès/échouées
- Lien direct vers le dashboard complet

## Installation

```bash
cd modules/wepresta_eaa_accessibility_checker
composer install
npm install
npm run build
```

## Configuration

1. Installer le module via le back-office PrestaShop
2. Accéder à la configuration via le menu module
3. Activer les fonctionnalités souhaitées :
   - Widget accessibilité (front)
   - Corrections automatiques
   - Skip links
   - Focus visible renforcé

## Architecture

```
src/
├── Controller/Admin/    # Contrôleurs Symfony
├── Service/             # Services métier
├── Repository/          # Accès données DBAL
├── Scanner/             # Validation WCAG PHP
├── Hook/                # Dispatcher hooks
└── Install/             # Installation module

views/js/src/
├── admin/               # Vue 3 dashboard
├── front/               # Alpine.js widget
└── scanner/             # axe-core scanner
```

## Développement

```bash
# Mode watch
npm run watch

# Build production
npm run build
```

## License

AFL-3.0
